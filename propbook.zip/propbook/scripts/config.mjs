// Everything sport-specific lives here: where data comes from, which players
// to include, which stats to compute, and which sportsbook markets map to them.

// ---------- helpers used by stat definitions ----------
// `raw` is a flat object of numbers pulled from a provider's game log row.
const pick = (raw, ...keys) => {
  for (const k of keys) {
    const v = raw[k];
    if (v !== undefined && v !== null && !Number.isNaN(v)) return v;
  }
  return null;
};
const sum = (...vals) => {
  if (vals.every((v) => v === null)) return null;
  return vals.reduce((a, v) => a + (v ?? 0), 0);
};

// ---------- basketball (ESPN game logs: NBA + WNBA) ----------
const bb = {
  pts: (r) => pick(r, 'points', 'PTS'),
  reb: (r) => pick(r, 'totalRebounds', 'rebounds', 'REB'),
  ast: (r) => pick(r, 'assists', 'AST'),
  fg3m: (r) => pick(r, 'threePointFieldGoalsMade', '3PT'),
  fg3a: (r) => pick(r, 'threePointFieldGoalsAttempted', '3PT_att'),
  fgm: (r) => pick(r, 'fieldGoalsMade', 'FG'),
  fga: (r) => pick(r, 'fieldGoalsAttempted', 'FG_att'),
  ftm: (r) => pick(r, 'freeThrowsMade', 'FT'),
  fta: (r) => pick(r, 'freeThrowsAttempted', 'FT_att'),
  stl: (r) => pick(r, 'steals', 'STL'),
  blk: (r) => pick(r, 'blocks', 'BLK'),
  tov: (r) => pick(r, 'turnovers', 'TO'),
  min: (r) => pick(r, 'minutes', 'MIN'),
};

const BASKETBALL_STATS = [
  { key: 'pts', label: 'Points', from: bb.pts },
  { key: 'reb', label: 'Rebounds', from: bb.reb },
  { key: 'ast', label: 'Assists', from: bb.ast },
  { key: 'fg3m', label: '3-pointers made', from: bb.fg3m },
  { key: 'pra', label: 'Pts + Reb + Ast', from: (r) => sum(bb.pts(r), bb.reb(r), bb.ast(r)) },
  { key: 'pr', label: 'Pts + Reb', from: (r) => sum(bb.pts(r), bb.reb(r)) },
  { key: 'pa', label: 'Pts + Ast', from: (r) => sum(bb.pts(r), bb.ast(r)) },
  { key: 'ra', label: 'Reb + Ast', from: (r) => sum(bb.reb(r), bb.ast(r)) },
  { key: 'stl', label: 'Steals', from: bb.stl },
  { key: 'blk', label: 'Blocks', from: bb.blk },
  { key: 'stocks', label: 'Steals + Blocks', from: (r) => sum(bb.stl(r), bb.blk(r)) },
  { key: 'tov', label: 'Turnovers', from: bb.tov },
  { key: 'fgm', label: 'Field goals made', from: bb.fgm },
  { key: 'fga', label: 'Field goal attempts', from: bb.fga },
  { key: 'fg3a', label: '3-point attempts', from: bb.fg3a },
  { key: 'ftm', label: 'Free throws made', from: bb.ftm },
  { key: 'min', label: 'Minutes', from: bb.min },
];

const BASKETBALL_MARKETS = {
  player_points: 'pts',
  player_rebounds: 'reb',
  player_assists: 'ast',
  player_threes: 'fg3m',
  player_points_rebounds_assists: 'pra',
  player_points_rebounds: 'pr',
  player_points_assists: 'pa',
  player_rebounds_assists: 'ra',
  player_steals: 'stl',
  player_blocks: 'blk',
  player_blocks_steals: 'stocks',
  player_turnovers: 'tov',
};

// ---------- football (ESPN game logs: NFL + college) ----------
const fb = {
  cmp: (r) => pick(r, 'completions'),
  passAtt: (r) => pick(r, 'passingAttempts'),
  passYds: (r) => pick(r, 'passingYards'),
  passTd: (r) => pick(r, 'passingTouchdowns'),
  int: (r) => pick(r, 'interceptions'),
  passLng: (r) => pick(r, 'longPassing'),
  rushAtt: (r) => pick(r, 'rushingAttempts'),
  rushYds: (r) => pick(r, 'rushingYards'),
  rushTd: (r) => pick(r, 'rushingTouchdowns'),
  rushLng: (r) => pick(r, 'longRushing'),
  rec: (r) => pick(r, 'receptions'),
  tgt: (r) => pick(r, 'receivingTargets'),
  recYds: (r) => pick(r, 'receivingYards'),
  recTd: (r) => pick(r, 'receivingTouchdowns'),
  recLng: (r) => pick(r, 'longReception'),
  tkl: (r) => pick(r, 'totalTackles'),
  solo: (r) => pick(r, 'soloTackles'),
  sacks: (r) => pick(r, 'sacks'),
  pd: (r) => pick(r, 'passesDefended'),
  fgm: (r) => pick(r, 'fieldGoalsMade'),
  xpm: (r) => pick(r, 'extraPointsMade'),
  kpts: (r) => pick(r, 'totalKickingPoints', 'kickingPoints'),
};

// role: which players a stat applies to. off = QB/RB/WR/TE, def = defense, k = kickers
const FOOTBALL_STATS = [
  { key: 'passYds', label: 'Passing yards', role: 'off', from: fb.passYds },
  { key: 'passTd', label: 'Passing TDs', role: 'off', from: fb.passTd },
  { key: 'cmp', label: 'Completions', role: 'off', from: fb.cmp },
  { key: 'passAtt', label: 'Pass attempts', role: 'off', from: fb.passAtt },
  { key: 'int', label: 'Interceptions thrown', role: 'off', from: fb.int },
  { key: 'passLng', label: 'Longest completion', role: 'off', from: fb.passLng },
  { key: 'rushYds', label: 'Rushing yards', role: 'off', from: fb.rushYds },
  { key: 'rushAtt', label: 'Rush attempts', role: 'off', from: fb.rushAtt },
  { key: 'rushLng', label: 'Longest rush', role: 'off', from: fb.rushLng },
  { key: 'rec', label: 'Receptions', role: 'off', from: fb.rec },
  { key: 'tgt', label: 'Targets', role: 'off', from: fb.tgt },
  { key: 'recYds', label: 'Receiving yards', role: 'off', from: fb.recYds },
  { key: 'recLng', label: 'Longest reception', role: 'off', from: fb.recLng },
  { key: 'rushRecYds', label: 'Rush + Rec yards', role: 'off', from: (r) => sum(fb.rushYds(r), fb.recYds(r)) },
  { key: 'passRushYds', label: 'Pass + Rush yards', role: 'off', from: (r) => sum(fb.passYds(r), fb.rushYds(r)) },
  { key: 'tds', label: 'Rush + Rec TDs', role: 'off', from: (r) => sum(fb.rushTd(r), fb.recTd(r)) },
  { key: 'tkl', label: 'Tackles + assists', role: 'def', from: fb.tkl },
  { key: 'solo', label: 'Solo tackles', role: 'def', from: fb.solo },
  { key: 'sacks', label: 'Sacks', role: 'def', from: fb.sacks },
  { key: 'defInt', label: 'Interceptions', role: 'def', from: fb.int },
  { key: 'pd', label: 'Passes defended', role: 'def', from: fb.pd },
  { key: 'fgm', label: 'Field goals made', role: 'k', from: fb.fgm },
  { key: 'xpm', label: 'Extra points made', role: 'k', from: fb.xpm },
  { key: 'kpts', label: 'Kicking points', role: 'k', from: fb.kpts },
];

const FOOTBALL_MARKETS = {
  player_pass_yds: 'passYds',
  player_pass_tds: 'passTd',
  player_pass_completions: 'cmp',
  player_pass_attempts: 'passAtt',
  player_pass_interceptions: 'int',
  player_pass_longest_completion: 'passLng',
  player_rush_yds: 'rushYds',
  player_rush_attempts: 'rushAtt',
  player_rush_longest: 'rushLng',
  player_receptions: 'rec',
  player_reception_yds: 'recYds',
  player_reception_longest: 'recLng',
  player_rush_reception_yds: 'rushRecYds',
  player_pass_rush_yds: 'passRushYds',
  player_anytime_td: 'tds',
  player_tackles_assists: 'tkl',
  player_solo_tackles: 'solo',
  player_sacks: 'sacks',
  player_field_goals: 'fgm',
  player_kicking_points: 'kpts',
};

const FB_OFF = ['QB', 'RB', 'FB', 'WR', 'TE'];
const FB_DEF = ['LB', 'OLB', 'ILB', 'MLB', 'DE', 'DT', 'NT', 'DL', 'EDGE', 'CB', 'S', 'FS', 'SS', 'DB', 'SAF'];
const FB_K = ['K', 'PK'];
const footballRole = (pos) => (FB_K.includes(pos) ? 'k' : FB_DEF.includes(pos) ? 'def' : 'off');

// ---------- baseball (MLB Stats API game logs) ----------
const MLB_STATS = [
  { key: 'h', label: 'Hits', role: 'hitter', from: (s) => pick(s, 'hits') },
  { key: 'tb', label: 'Total bases', role: 'hitter', from: (s) => pick(s, 'totalBases') },
  { key: 'hrr', label: 'Hits + Runs + RBIs', role: 'hitter', from: (s) => sum(pick(s, 'hits'), pick(s, 'runs'), pick(s, 'rbi')) },
  { key: 'hr', label: 'Home runs', role: 'hitter', from: (s) => pick(s, 'homeRuns') },
  { key: 'rbi', label: 'RBIs', role: 'hitter', from: (s) => pick(s, 'rbi') },
  { key: 'r', label: 'Runs', role: 'hitter', from: (s) => pick(s, 'runs') },
  { key: 'singles', label: 'Singles', role: 'hitter', from: (s) => {
      const h = pick(s, 'hits');
      return h === null ? null : h - (pick(s, 'doubles') ?? 0) - (pick(s, 'triples') ?? 0) - (pick(s, 'homeRuns') ?? 0);
    } },
  { key: 'doubles', label: 'Doubles', role: 'hitter', from: (s) => pick(s, 'doubles') },
  { key: 'bb', label: 'Walks', role: 'hitter', from: (s) => pick(s, 'baseOnBalls') },
  { key: 'so', label: 'Strikeouts', role: 'hitter', from: (s) => pick(s, 'strikeOuts') },
  { key: 'sb', label: 'Stolen bases', role: 'hitter', from: (s) => pick(s, 'stolenBases') },
  { key: 'ab', label: 'At bats', role: 'hitter', from: (s) => pick(s, 'atBats') },
  { key: 'pK', label: 'Strikeouts', role: 'pitcher', from: (s) => pick(s, 'strikeOuts') },
  { key: 'pOuts', label: 'Outs recorded', role: 'pitcher', from: (s) => pick(s, 'outs') ?? inningsToOuts(s.inningsPitched) },
  { key: 'pH', label: 'Hits allowed', role: 'pitcher', from: (s) => pick(s, 'hits') },
  { key: 'pER', label: 'Earned runs', role: 'pitcher', from: (s) => pick(s, 'earnedRuns') },
  { key: 'pBB', label: 'Walks allowed', role: 'pitcher', from: (s) => pick(s, 'baseOnBalls') },
  { key: 'pitches', label: 'Pitches thrown', role: 'pitcher', from: (s) => pick(s, 'numberOfPitches') },
];

function inningsToOuts(ip) {
  if (ip === undefined || ip === null) return null;
  const [whole, part = '0'] = String(ip).split('.');
  return Number(whole) * 3 + Number(part);
}

const MLB_MARKETS = {
  batter_hits: 'h',
  batter_total_bases: 'tb',
  batter_hits_runs_rbis: 'hrr',
  batter_home_runs: 'hr',
  batter_rbis: 'rbi',
  batter_runs_scored: 'r',
  batter_runs: 'r', // PropLine's name for runs scored
  batter_singles: 'singles',
  batter_doubles: 'doubles',
  batter_walks: 'bb',
  batter_strikeouts: 'so',
  batter_stolen_bases: 'sb',
  pitcher_strikeouts: 'pK',
  pitcher_outs: 'pOuts',
  pitcher_hits_allowed: 'pH',
  pitcher_earned_runs: 'pER',
  pitcher_walks: 'pBB',
};

// ---------- season conventions ----------
// ESPN labels NBA seasons by the year they end (2025-26 = 2026) and football
// seasons by the year they start. MLB and WNBA use the calendar year.
const seasonFor = {
  calendar: (y) => y,
  nba: (y, m) => (m >= 8 ? y + 1 : y),
  football: (y, m) => (m >= 3 ? y : y - 1),
};

export const SPORTS = {
  mlb: {
    label: 'MLB',
    provider: 'mlb',
    espnSport: 'baseball', // used for the injury report and news
    espnLeague: 'mlb',
    oddsKey: 'baseball_mlb',
    proplineKey: 'baseball_mlb',
    daysAhead: 0,
    seasonsBack: 1, // current season + 1 previous season
    season: seasonFor.calendar,
    stats: MLB_STATS,
    markets: MLB_MARKETS,
    headline: { hitter: ['h', 'tb', 'hrr'], pitcher: ['pK', 'pOuts', 'pER'] },
    logCols: { hitter: ['ab', 'h', 'tb', 'hr', 'rbi', 'r', 'bb', 'so'], pitcher: ['pOuts', 'pK', 'pH', 'pER', 'pBB', 'pitches'] },
    batterVsPitcher: true,
  },
  wnba: {
    label: 'WNBA',
    provider: 'espn',
    espnSport: 'basketball',
    espnLeague: 'wnba',
    oddsKey: 'basketball_wnba',
    proplineKey: 'basketball_wnba',
    daysAhead: 0,
    seasonsBack: 1,
    season: seasonFor.calendar,
    stats: BASKETBALL_STATS,
    markets: BASKETBALL_MARKETS,
    role: () => 'all',
    headline: { all: ['pts', 'reb', 'ast'] },
    logCols: { all: ['min', 'pts', 'reb', 'ast', 'fg3m', 'stl', 'blk', 'tov'] },
  },
  nba: {
    label: 'NBA',
    provider: 'espn',
    espnSport: 'basketball',
    espnLeague: 'nba',
    oddsKey: 'basketball_nba',
    proplineKey: 'basketball_nba',
    daysAhead: 0,
    seasonsBack: 1,
    season: seasonFor.nba,
    stats: BASKETBALL_STATS,
    markets: BASKETBALL_MARKETS,
    role: () => 'all',
    headline: { all: ['pts', 'reb', 'ast'] },
    logCols: { all: ['min', 'pts', 'reb', 'ast', 'fg3m', 'stl', 'blk', 'tov'] },
  },
  nfl: {
    label: 'NFL',
    provider: 'espn',
    espnSport: 'football',
    espnLeague: 'nfl',
    oddsKey: 'americanfootball_nfl',
    proplineKey: 'football_nfl',
    daysAhead: 6, // the whole upcoming week (Thu, Sun, Mon)
    seasonsBack: 2, // more history, since teams play only 17 games a year
    season: seasonFor.football,
    positions: [...FB_OFF, ...FB_DEF, ...FB_K],
    role: footballRole,
    stats: FOOTBALL_STATS,
    markets: FOOTBALL_MARKETS,
    headline: { off: ['passYds', 'rushYds', 'recYds'], def: ['tkl', 'sacks'], k: ['fgm', 'kpts'] },
    logCols: {
      off: ['cmp', 'passAtt', 'passYds', 'passTd', 'int', 'rushAtt', 'rushYds', 'rec', 'tgt', 'recYds', 'tds'],
      def: ['tkl', 'solo', 'sacks', 'defInt', 'pd'],
      k: ['fgm', 'xpm', 'kpts'],
    },
  },
  ncaaf: {
    label: 'College football',
    short: 'NCAAF',
    provider: 'espn',
    espnSport: 'football',
    espnLeague: 'college-football',
    scoreboardParams: { groups: '80' }, // 80 = FBS only
    oddsKey: 'americanfootball_ncaaf',
    proplineKey: 'football_ncaaf',
    daysAhead: 6,
    seasonsBack: 1,
    season: seasonFor.football,
    positions: [...FB_OFF, ...FB_K], // skill players + kickers (defense would triple the run time)
    role: footballRole,
    stats: FOOTBALL_STATS,
    markets: FOOTBALL_MARKETS,
    headline: { off: ['passYds', 'rushYds', 'recYds'], k: ['fgm', 'kpts'] },
    logCols: {
      off: ['cmp', 'passAtt', 'passYds', 'passTd', 'int', 'rushAtt', 'rushYds', 'rec', 'recYds', 'tds'],
      k: ['fgm', 'xpm', 'kpts'],
    },
  },
};

export const SETTINGS = {
  timeZone: 'America/New_York', // defines "today" for the slate
  concurrency: Number(process.env.CONCURRENCY || 8),
  playerLimit: Number(process.env.PLAYER_LIMIT || 0), // for quick local test runs; 0 = everyone
  maxRecentGames: 40, // rows kept per player (plus older head-to-head games)
  maxOlderH2H: 10,
  // Sportsbook lines only for games starting within this many hours. Keeps
  // odds-credit use sane for football, where the slate covers a full week.
  oddsWindowHours: Number(process.env.ODDS_WINDOW_HOURS || 36),
  // Books to pull lines from. Blank = the provider default (see scripts/lib/odds.mjs).
  oddsBookmakers: process.env.ODDS_BOOKMAKERS || '',
};
