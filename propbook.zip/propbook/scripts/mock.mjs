#!/usr/bin/env node
// Writes invented sample data into public/data so the site can be previewed
// offline: npm run mock && npm run serve. The next real refresh replaces it.

import { mkdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SPORTS } from './config.mjs';
import { buildRows, hitRates } from './lib/common.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA = path.join(ROOT, 'public', 'data');
let seed = 7;
const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
const gauss = (mean, sd) => Math.max(0, Math.round(mean + sd * (rnd() + rnd() + rnd() - 1.5) * 1.3));
const write = async (f, o) => {
  await mkdir(path.dirname(f), { recursive: true });
  await writeFile(f, JSON.stringify(o));
};

const FIRST = ['Marcus', 'Devin', 'Tyrell', 'Caleb', 'Jalen', 'Owen', 'Rico', 'Isaiah', 'Brock', 'Dante', 'Kobe', 'Luis', 'Trent', 'Andre', 'Miles', 'Nate'];
const LAST = ['Hollins', 'Varga', 'Pruitt', 'Okafor', 'Delacroix', 'Stroud', 'Mercer', 'Abernathy', 'Kwan', 'Ruiz', 'Talbot', 'Fenwick', 'Osei', 'Lindqvist', 'Bramley', 'Castile'];
const name = () => `${FIRST[Math.floor(rnd() * FIRST.length)]} ${LAST[Math.floor(rnd() * LAST.length)]}`;

const teams = [
  ['1', 'HAR', 'Harbor City Gulls'], ['2', 'MES', 'Mesa Coyotes'], ['3', 'NVL', 'Northvale Pines'],
  ['4', 'RDG', 'Ridgeport Ironmen'], ['5', 'SLT', 'Salt Flats Comets'], ['6', 'BAY', 'Bayline Herons'],
];
const teamObj = ([id, abbr, n]) => ({ id, abbr, name: n, short: n.split(' ').pop(), logo: '', record: '1-1' });

const cfg = SPORTS.nfl;
const now = new Date();
const kickoff = (h) => new Date(now.getTime() + h * 3600e3).toISOString();
const games = [
  { id: 'g1', start: kickoff(20), state: 'pre', detail: '', home: teamObj(teams[0]), away: teamObj(teams[1]) },
  { id: 'g2', start: kickoff(23), state: 'pre', detail: '', home: teamObj(teams[2]), away: teamObj(teams[3]) },
  { id: 'g3', start: kickoff(96), state: 'pre', detail: '', home: teamObj(teams[4]), away: teamObj(teams[5]) },
];

const archetypes = [
  { pos: 'QB', make: () => ({ completions: gauss(22, 5), passingAttempts: gauss(34, 5), passingYards: gauss(248, 60), passingTouchdowns: gauss(1.7, 1.2), interceptions: gauss(0.6, 0.8), rushingAttempts: gauss(4, 2), rushingYards: gauss(18, 14), rushingTouchdowns: gauss(0.2, 0.5) }) },
  { pos: 'RB', make: () => ({ rushingAttempts: gauss(16, 5), rushingYards: gauss(72, 30), rushingTouchdowns: gauss(0.5, 0.7), receptions: gauss(3, 2), receivingTargets: gauss(4, 2), receivingYards: gauss(22, 15), receivingTouchdowns: gauss(0.1, 0.4) }) },
  { pos: 'WR', make: () => ({ receptions: gauss(5.5, 2.5), receivingTargets: gauss(8, 3), receivingYards: gauss(68, 32), receivingTouchdowns: gauss(0.4, 0.6), longReception: gauss(24, 12) }) },
  { pos: 'WR', make: () => ({ receptions: gauss(3.5, 2), receivingTargets: gauss(5, 2), receivingYards: gauss(41, 24), receivingTouchdowns: gauss(0.25, 0.5), longReception: gauss(17, 10) }) },
  { pos: 'TE', make: () => ({ receptions: gauss(4, 2), receivingTargets: gauss(5.5, 2), receivingYards: gauss(44, 22), receivingTouchdowns: gauss(0.3, 0.5), longReception: gauss(16, 8) }) },
  { pos: 'LB', make: () => ({ totalTackles: gauss(7, 3), soloTackles: gauss(4.5, 2), sacks: gauss(0.3, 0.5), interceptions: 0, passesDefended: gauss(0.4, 0.6) }) },
];

const players = [];
let pid = 1000;
for (const g of games) {
  for (const [team, opp, home] of [[g.home, g.away, true], [g.away, g.home, false]]) {
    for (const a of archetypes) {
      const role = cfg.role(a.pos);
      const entries = [];
      for (let i = 0; i < 30; i++) {
        const d = new Date(now.getTime() - (i + 1) * 7 * 864e5);
        const season = d.getUTCMonth() >= 2 ? d.getUTCFullYear() : d.getUTCFullYear() - 1;
        const o = rnd() < 0.12 ? opp : teamObj(teams[Math.floor(rnd() * teams.length)]);
        entries.push({ date: d.toISOString(), season, oppId: o.id, oppAbbr: o.abbr, ha: rnd() > 0.5 ? '@' : 'vs', result: rnd() > 0.5 ? 'W' : 'L', raw: a.make() });
      }
      const defs = cfg.stats.filter((s) => s.role === role);
      const { cols, rows } = buildRows(entries, defs, opp.id);
      players.push({
        id: String(pid++), name: name(), pos: a.pos, role, img: '', inj: rnd() < 0.08 ? 'Questionable' : '',
        team: team.abbr, teamId: team.id, opp: opp.abbr, oppId: opp.id, home, gameId: g.id, cols, rows,
      });
    }
  }
}

const season = cfg.season(now.getFullYear(), now.getMonth() + 1);
const marketFor = { QB: ['passYds', 'passTd', 'cmp', 'rushYds'], RB: ['rushYds', 'rushAtt', 'rec', 'tds'], WR: ['recYds', 'rec', 'tds'], TE: ['recYds', 'rec'], LB: ['tkl'] };
const props = [];
for (const p of players.filter((x) => x.gameId !== 'g3')) {
  for (const stat of marketFor[p.pos] || []) {
    const i = p.cols.indexOf(stat);
    const vals = p.rows.slice(0, 10).map((r) => r[6 + i]);
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
    const line = stat === 'tds' ? 0.5 : Math.max(0.5, Math.round(avg * (0.85 + rnd() * 0.3)) + 0.5);
    const price = () => -130 + Math.round(rnd() * 50);
    props.push({
      pid: p.id, gameId: p.gameId, stat, line,
      books: [
        { book: 'DraftKings', key: 'draftkings', line, over: price(), under: price() },
        { book: 'FanDuel', key: 'fanduel', line, over: price(), under: price() },
        { book: 'BetMGM', key: 'betmgm', line: line + (rnd() > 0.7 ? 1 : 0), over: price(), under: price() },
      ],
      hr: hitRates(p, stat, line, season),
    });
  }
}

await rm(DATA, { recursive: true, force: true });
const meta = { order: Object.keys(SPORTS), sports: {} };
for (const [k, c] of Object.entries(SPORTS)) meta.sports[k] = { label: c.label, short: c.short || c.label, stats: c.stats.map(({ key, label, role }) => ({ key, label, role: role || 'all' })), headline: c.headline, logCols: c.logCols };
await write(path.join(DATA, 'meta.json'), meta);
for (const g of games) await write(path.join(DATA, 'nfl', 'games', `${g.id}.json`), { gameId: g.id, season, players: players.filter((p) => p.gameId === g.id) });
const today = now.toISOString().slice(0, 10);
await write(path.join(DATA, 'nfl', 'slate.json'), {
  sport: 'nfl', generatedAt: now.toISOString(), season, from: today, until: new Date(now.getTime() + 6 * 864e5).toISOString().slice(0, 10),
  games, players: players.map(({ cols, rows, ...r }) => ({ ...r, gp: rows.length, avg: {} })), props, oddsNote: 'Sample data. Run npm run refresh for the real slate.',
});
for (const k of Object.keys(SPORTS)) {
  if (k === 'nfl') continue;
  await write(path.join(DATA, k, 'slate.json'), { sport: k, generatedAt: now.toISOString(), season, from: today, until: today, games: [], players: [], props: [], oddsNote: '' });
}
await write(path.join(DATA, 'index.json'), {
  generatedAt: now.toISOString(),
  sports: Object.fromEntries(Object.keys(SPORTS).map((k) => [k, { generatedAt: now.toISOString(), games: k === 'nfl' ? games.length : 0, players: k === 'nfl' ? players.length : 0, props: k === 'nfl' ? props.length : 0 }])),
});
console.log(`Sample data written: ${players.length} players, ${props.length} lines. Now run: npm run serve`);
