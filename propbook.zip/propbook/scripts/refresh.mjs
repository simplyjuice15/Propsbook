#!/usr/bin/env node
// Daily refresh: builds today's slate for each sport and writes static JSON
// that the site in /public reads.
//
//   node scripts/refresh.mjs               # all sports
//   node scripts/refresh.mjs nfl mlb       # just these
//   PLAYER_LIMIT=10 node scripts/refresh.mjs wnba   # quick test run

import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SPORTS } from './config.mjs';
import * as espn from './lib/espn.mjs';
import * as mlb from './lib/mlb.mjs';
import { fetchProps, oddsUsage } from './lib/odds.mjs';
import { buildReport } from './lib/news.mjs';
import { META_LEN, hitRates } from './lib/common.mjs';
import { counters } from './lib/http.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA = path.join(ROOT, 'public', 'data');

const writeJSON = async (file, obj) => {
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, JSON.stringify(obj));
};

function buildMeta() {
  const sports = {};
  for (const [key, cfg] of Object.entries(SPORTS)) {
    sports[key] = {
      label: cfg.label,
      short: cfg.short || cfg.label,
      stats: cfg.stats.map(({ key: k, label, role }) => ({ key: k, label, role: role || 'all' })),
      headline: cfg.headline,
      logCols: cfg.logCols,
    };
  }
  return { sports, order: Object.keys(SPORTS) };
}

/** A small summary per player for list views: L10 averages of headline stats. */
function summarize(p, cfg) {
  const heads = cfg.headline[p.role] || cfg.headline.all || [];
  const avg = {};
  for (const k of heads) {
    const i = p.cols.indexOf(k);
    if (i < 0) continue;
    const vals = p.rows.slice(0, 10).map((r) => r[META_LEN + i]).filter((v) => v !== null);
    if (vals.length) avg[k] = Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10;
  }
  const { cols, rows, bvp, injury, ...rest } = p;
  return { ...rest, gp: rows.length, avg };
}

async function refreshSport(key, now) {
  const cfg = SPORTS[key];
  const started = Date.now();
  const provider = cfg.provider === 'mlb' ? mlb : espn;
  const slate = await provider.buildSlate(key, cfg, now);

  let props = [];
  let oddsNote = '';
  if (slate.games.length) {
    try {
      const res = await fetchProps(key, cfg, slate, now);
      props = res.props;
      oddsNote = res.note || '';
    } catch (err) {
      oddsNote = `Sportsbook lines failed: ${err.message}`;
      console.warn(`[${key}] ${oddsNote}`);
    }
  }

  // Injury report, roster moves and headlines. Never fatal: stats still publish without it.
  let report = { items: [], byPlayer: new Map() };
  try {
    report = await buildReport(key, cfg, slate);
  } catch (err) {
    console.warn(`[${key}] injury report failed: ${err.message}`);
  }
  for (const p of slate.players) {
    const status = report.byPlayer.get(p.id);
    if (status) {
      p.injury = status;
      p.inj = status.status;
    }
  }

  const byId = new Map(slate.players.map((p) => [p.id, p]));
  for (const pr of props) pr.hr = hitRates(byId.get(pr.pid), pr.stat, pr.line, slate.season);

  const dir = path.join(DATA, key);
  await rm(dir, { recursive: true, force: true });
  const generatedAt = new Date().toISOString();

  for (const g of slate.games) {
    const players = slate.players.filter((p) => p.gameId === g.id);
    await writeJSON(path.join(dir, 'games', `${g.id}.json`), { gameId: g.id, season: slate.season, players });
  }
  await writeJSON(path.join(dir, 'slate.json'), {
    sport: key,
    generatedAt,
    season: slate.season,
    from: slate.today,
    until: slate.until,
    games: slate.games,
    players: slate.players.map((p) => summarize(p, cfg)),
    props,
    oddsNote,
  });

  await writeJSON(path.join(dir, 'injuries.json'), { sport: key, generatedAt, items: report.items });

  const secs = Math.round((Date.now() - started) / 1000);
  console.log(`[${key}] done: ${slate.games.length} games, ${slate.players.length} players, ${props.length} lines in ${secs}s`);
  return { generatedAt, games: slate.games.length, players: slate.players.length, props: props.length, from: slate.today, until: slate.until };
}

/**
 * public/config.js tells the site where accounts live. The Supabase URL and
 * anon key are designed to be public; database rules protect the data.
 */
async function writeSiteConfig() {
  const url = (process.env.SUPABASE_URL || '').trim().replace(/\/+$/, '').replace(/\/(rest|auth)\/v1$/, '');
  const anonKey = (process.env.SUPABASE_ANON_KEY || '').trim();
  const pay = {
    stripeMonthlyLink: (process.env.STRIPE_MONTHLY_LINK || '').trim(),
    stripeYearlyLink: (process.env.STRIPE_YEARLY_LINK || '').trim(),
    stripePortalLink: (process.env.STRIPE_PORTAL_LINK || '').trim(),
    monthlyPrice: (process.env.PREMIUM_MONTHLY_PRICE || '').trim(),
    yearlyPrice: (process.env.PREMIUM_YEARLY_PRICE || '').trim(),
  };
  const linkOk = (l) => !l || /^https:\/\/(buy|billing)\.stripe\.com\//.test(l);
  for (const [name, value] of [['STRIPE_MONTHLY_LINK', pay.stripeMonthlyLink], ['STRIPE_YEARLY_LINK', pay.stripeYearlyLink], ['STRIPE_PORTAL_LINK', pay.stripePortalLink]]) {
    if (!linkOk(value)) console.log(`Payments: warning, ${name} should start with https://buy.stripe.com/ or https://billing.stripe.com/`);
  }
  if (!url || !anonKey) {
    const missing = [!url && 'SUPABASE_URL', !anonKey && 'SUPABASE_ANON_KEY'].filter(Boolean).join(' and ');
    console.log(`Accounts: OFF. ${missing} ${missing.includes(' and ') ? 'are' : 'is'} empty in this run. Add them under Settings > Secrets and variables > Actions, and make sure the workflow file passes them in.`);
    if (!url && !anonKey) return;
  }
  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)) {
    console.log(`Accounts: warning, SUPABASE_URL should look like https://abcdefgh.supabase.co (got "${url.slice(0, 40)}")`);
  }
  const body = `// Written by scripts/refresh.mjs from the repository settings.\nexport default ${JSON.stringify({ supabaseUrl: url, supabaseAnonKey: anonKey, ...pay }, null, 2)};\n`;
  await writeFile(path.join(ROOT, 'public', 'config.js'), body);
  if (url && anonKey) console.log(`Accounts: ON (${url})`);
  console.log(`Payments: ${pay.stripeMonthlyLink || pay.stripeYearlyLink ? 'ON' : 'OFF (no Stripe payment links set)'}`);
}

async function main() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith('-'));
  const keys = args.length ? args : Object.keys(SPORTS);
  const unknown = keys.filter((k) => !SPORTS[k]);
  if (unknown.length) throw new Error(`Unknown sport(s): ${unknown.join(', ')}. Use: ${Object.keys(SPORTS).join(', ')}`);

  const now = new Date();
  await writeJSON(path.join(DATA, 'meta.json'), buildMeta());
  await writeSiteConfig();

  let index = { sports: {} };
  try {
    index = JSON.parse(await readFile(path.join(DATA, 'index.json'), 'utf8'));
  } catch {
    /* first run */
  }

  let failures = 0;
  for (const key of keys) {
    try {
      index.sports[key] = await refreshSport(key, now);
    } catch (err) {
      failures++;
      console.error(`[${key}] FAILED: ${err.stack || err.message}`);
      index.sports[key] = { generatedAt: new Date().toISOString(), error: err.message, games: 0, players: 0, props: 0 };
    }
  }
  index.generatedAt = new Date().toISOString();
  await writeJSON(path.join(DATA, 'index.json'), index);

  console.log(
    `\nRequests: ${counters.requests} (${counters.failures} failed)` +
      (oddsUsage.calls ? `; ${oddsUsage.provider}: ${oddsUsage.calls} calls, ${oddsUsage.remaining ?? '?'} requests left` : ''),
  );
  // Fail the job only if every sport failed, so one bad feed doesn't block the rest.
  if (failures === keys.length) process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

