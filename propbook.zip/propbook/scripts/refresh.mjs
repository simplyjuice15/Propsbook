#!/usr/bin/env node
// Daily refresh: builds today's slate for each sport and writes static JSON
// that the site in /public reads.
//
//   node scripts/refresh.mjs               # all sports
//   node scripts/refresh.mjs nfl mlb       # just these
//   PLAYER_LIMIT=10 node scripts/refresh.mjs wnba   # quick test run

import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SPORTS } from './config.mjs';
import * as espn from './lib/espn.mjs';
import * as mlb from './lib/mlb.mjs';
import { fetchProps, oddsUsage } from './lib/odds.mjs';
import { META_LEN, hitRates } from './lib/common.mjs';
import { counters } from './lib/http.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA = path.join(ROOT, 'public', 'data');

const writeJSON = async (file, obj) => {
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, JSON.stringify(obj));
};

function buildMeta() {
  const sports = {};
  for (const [key, cfg] of Object.entries(SPORTS)) {
    sports[key] = {
      label: cfg.label,
      short: cfg.short || cfg.label,
      stats: cfg.stats.map(({ key: k, label, role }) => ({ key: k, label, role: role || 'all' })),
      headline: cfg.headline,
      logCols: cfg.logCols,
    };
  }
  return { sports, order: Object.keys(SPORTS) };
}

/** A small summary per player for list views: L10 averages of headline stats. */
function summarize(p, cfg) {
  const heads = cfg.headline[p.role] || cfg.headline.all || [];
  const avg = {};
  for (const k of heads) {
    const i = p.cols.indexOf(k);
    if (i < 0) continue;
    const vals = p.rows.slice(0, 10).map((r) => r[META_LEN + i]).filter((v) => v !== null);
    if (vals.length) avg[k] = Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10;
  }
  const { cols, rows, bvp, ...rest } = p;
  return { ...rest, gp: rows.length, avg };
}

async function refreshSport(key, now) {
  const cfg = SPORTS[key];
  const started = Date.now();
  const provider = cfg.provider === 'mlb' ? mlb : espn;
  const slate = await provider.buildSlate(key, cfg, now);

  let props = [];
  let oddsNote = '';
  if (slate.games.length) {
    try {
      const res = await fetchProps(key, cfg, slate, now);
      props = res.props;
      oddsNote = res.note || '';
    } catch (err) {
      oddsNote = `Sportsbook lines failed: ${err.message}`;
      console.warn(`[${key}] ${oddsNote}`);
    }
  }

  const byId = new Map(slate.players.map((p) => [p.id, p]));
  for (const pr of props) pr.hr = hitRates(byId.get(pr.pid), pr.stat, pr.line, slate.season);

  const dir = path.join(DATA, key);
  await rm(dir, { recursive: true, force: true });
  const generatedAt = new Date().toISOString();

  for (const g of slate.games) {
    const players = slate.players.filter((p) => p.gameId === g.id);
    await writeJSON(path.join(dir, 'games', `${g.id}.json`), { gameId: g.id, season: slate.season, players });
  }
  await writeJSON(path.join(dir, 'slate.json'), {
    sport: key,
    generatedAt,
    season: slate.season,
    from: slate.today,
    until: slate.until,
    games: slate.games,
    players: slate.players.map((p) => summarize(p, cfg)),
    props,
    oddsNote,
  });

  const secs = Math.round((Date.now() - started) / 1000);
  console.log(`[${key}] done: ${slate.games.length} games, ${slate.players.length} players, ${props.length} lines in ${secs}s`);
  return { generatedAt, games: slate.games.length, players: slate.players.length, props: props.length, from: slate.today, until: slate.until };
}

async function main() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith('-'));
  const keys = args.length ? args : Object.keys(SPORTS);
  const unknown = keys.filter((k) => !SPORTS[k]);
  if (unknown.length) throw new Error(`Unknown sport(s): ${unknown.join(', ')}. Use: ${Object.keys(SPORTS).join(', ')}`);

  const now = new Date();
  await writeJSON(path.join(DATA, 'meta.json'), buildMeta());

  let index = { sports: {} };
  try {
    index = JSON.parse(await readFile(path.join(DATA, 'index.json'), 'utf8'));
  } catch {
    /* first run */
  }

  let failures = 0;
  for (const key of keys) {
    try {
      index.sports[key] = await refreshSport(key, now);
    } catch (err) {
      failures++;
      console.error(`[${key}] FAILED: ${err.stack || err.message}`);
      index.sports[key] = { generatedAt: new Date().toISOString(), error: err.message, games: 0, players: 0, props: 0 };
    }
  }
  index.generatedAt = new Date().toISOString();
  await writeJSON(path.join(DATA, 'index.json'), index);

  console.log(
    `\nRequests: ${counters.requests} (${counters.failures} failed)` +
      (oddsUsage.calls ? `; odds credits used this month: ${oddsUsage.used}, remaining: ${oddsUsage.remaining}` : ''),
  );
  // Fail the job only if every sport failed, so one bad feed doesn't block the rest.
  if (failures === keys.length) process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

