#!/usr/bin/env node
// Debug helper: print what a provider returns for one player, so stat
// mappings in config.mjs can be checked or fixed quickly.
//
//   node scripts/inspect.mjs nfl 3139477 2025     (ESPN athlete id)
//   node scripts/inspect.mjs mlb 592450 2026 hitting

import { SPORTS } from './config.mjs';
import { getJSON } from './lib/http.mjs';
import { gamelogUrl, parseGamelog } from './lib/espn.mjs';
import { buildRows } from './lib/common.mjs';

const [sport, id, seasonArg, group = 'hitting'] = process.argv.slice(2);
const cfg = SPORTS[sport];
if (!cfg || !id) {
  console.log('Usage: node scripts/inspect.mjs <sport> <playerId> [season] [hitting|pitching]');
  process.exit(1);
}
const season = Number(seasonArg) || new Date().getFullYear();

if (cfg.provider === 'mlb') {
  const url = `https://statsapi.mlb.com/api/v1/people/${id}/stats?stats=gameLog&group=${group}&season=${season}`;
  const { data } = await getJSON(url);
  const split = data?.stats?.[0]?.splits?.[0];
  console.log(url, '\nFirst split:', JSON.stringify(split, null, 2));
} else {
  const url = gamelogUrl(cfg, id, season);
  const { data } = await getJSON(url);
  console.log(url);
  console.log('names :', data?.names);
  console.log('labels:', data?.labels);
  console.log('seasonTypes:', (data?.seasonTypes || []).map((s) => s.displayName));
  const entries = parseGamelog(data, season);
  console.log(`\n${entries.length} games parsed. First raw row:`, entries[0]?.raw);
  const { cols, rows } = buildRows(entries, cfg.stats, '');
  console.log('\nComputed (newest first):');
  console.table(rows.slice(0, 5).map((r) => Object.fromEntries([['date', r[0]], ['opp', r[4] + ' ' + r[2]], ...cols.map((c, i) => [c, r[6 + i]])])));
}
