# Keeping Propbook safe and running

## What's already in place

- **No server to break into.** The site is static files. There's no admin panel, database connection or login form on the web host itself.
- **No npm packages.** The daily job uses only Node's built-ins, so there's no supply chain to poison. The login library loads from a pinned CDN.
- **Database rules, not app rules.** Postgres row level security decides who reads and writes what. Even a stolen anon key can only see that person's own rows. Premium is checked in the database, not in the browser.
- **Nobody can upgrade themselves.** There's no update policy on `profiles`, so `plan` changes only through the Stripe webhook or you.
- **Payments are signature-checked.** The webhook verifies Stripe's signature and timestamp before touching anything, so forged "they paid" requests are rejected.
- **Secrets stay server-side.** The Stripe webhook secret lives in Supabase, the service role key in GitHub Secrets. Neither reaches the browser.
- **Escaped output.** Every value that comes from a feed is escaped before it's put on the page, and the page carries a content security policy that blocks injected scripts.

## Do these once

- [ ] Turn on 2-factor authentication for GitHub, Supabase, Stripe, your registrar and the Gmail account.
- [ ] Supabase → Authentication → Policies: confirm RLS says **Enabled** on `profiles`, `saved_props`, `promo_codes` and `promo_redemptions`.
- [ ] Supabase → Authentication: turn on **leaked password protection**, require email confirmation, and set a minimum password length of 8.
- [ ] GitHub → Settings → Actions → General: set workflow permissions to **Read repository contents**.
- [ ] Confirm no key is in the repo. Only `SUPABASE_ANON_KEY` is public by design.
- [ ] Set a calendar reminder to rotate the service role key and Stripe webhook secret once a year.

Verify the database rules any time by running this in the SQL Editor. Every row should say `true`:

```sql
select tablename, rowsecurity from pg_tables
where schemaname = 'public' and tablename in
  ('profiles', 'saved_props', 'promo_codes', 'promo_redemptions');
```

## Keeping up with deprecations

- **Dependabot** (`.github/dependabot.yml`) opens a pull request when a GitHub Action gets a new version. Merge those when they appear; that's what clears "Node.js 20 is deprecated" warnings.
- **The workflow pins Node 22.** When GitHub retires it, bump `node-version` in the workflow.
- **The login library** is pinned to Supabase v2 in `public/auth.js`. Check it yearly.
- **The data feeds are unofficial.** ESPN can rename a field without warning. The build keeps going and the tests catch the obvious breaks; `npm run inspect` shows what a feed is sending now.

## If something goes wrong

- **Data looks stale:** the header says "Stale" when the slate is over 36 hours old. Check the Actions tab; GitHub emails you when a run fails.
- **Scheduled runs stopped:** GitHub pauses them after 60 days without commits. Push anything, or press Run workflow.
- **A key leaks:** rotate it (Supabase → Project Settings → API, or Stripe → Webhooks), update the GitHub secret, and rerun the workflow.
- **Someone abuses signups:** Supabase → Authentication → Rate Limits lets you cap signups and emails per hour.
