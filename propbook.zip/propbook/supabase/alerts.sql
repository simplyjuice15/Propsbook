-- Propbook: email alerts. Run once in Supabase → SQL Editor. Safe to run again.
alter table public.profiles add column if not exists alerts_enabled boolean not null default true;
alter table public.profiles add column if not exists alerts_injury boolean not null default true;
alter table public.profiles add column if not exists alerts_line boolean not null default true;
alter table public.profiles add column if not exists unsubscribe_token uuid not null default gen_random_uuid();
create unique index if not exists profiles_unsubscribe_idx on public.profiles (unsubscribe_token);

-- People can change their own alert settings, but nothing else on their profile.
create or replace function public.set_alert_prefs(enabled boolean, injury boolean, line boolean)
returns void language sql security definer set search_path = public as $$
  update public.profiles
  set alerts_enabled = enabled, alerts_injury = injury, alerts_line = line
  where id = auth.uid();
$$;
revoke all on function public.set_alert_prefs(boolean, boolean, boolean) from public, anon;
grant execute on function public.set_alert_prefs(boolean, boolean, boolean) to authenticated;

-- One-click unsubscribe from the link in every email; no login needed.
create or replace function public.unsubscribe_alerts(token uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare hit boolean;
begin
  update public.profiles set alerts_enabled = false where unsubscribe_token = token;
  get diagnostics hit = row_count;
  return hit;
end;
$$;
grant execute on function public.unsubscribe_alerts(uuid) to anon, authenticated;

-- Remembers what has already been sent, so nobody gets the same alert twice.
create table if not exists public.alert_log (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users on delete cascade,
  saved_prop_id bigint,
  kind text not null,
  key text not null,
  sent_at timestamptz not null default now(),
  unique (user_id, saved_prop_id, kind, key)
);
alter table public.alert_log enable row level security; -- no policies: only the daily job touches it
