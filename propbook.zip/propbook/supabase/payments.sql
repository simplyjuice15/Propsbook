-- Propbook payments. Run once in Supabase → SQL Editor, after setup.sql. Safe to run again.
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists stripe_customer_id text;
alter table public.profiles add column if not exists stripe_subscription_id text;
alter table public.profiles add column if not exists subscription_status text;
alter table public.profiles add column if not exists current_period_end timestamptz;
create index if not exists profiles_email_idx on public.profiles (email);
create index if not exists profiles_stripe_customer_idx on public.profiles (stripe_customer_id);

-- Keep each profile's email so a payment can be matched even without a login id.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, lower(new.email))
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;
update public.profiles p set email = lower(u.email)
  from auth.users u where u.id = p.id and p.email is distinct from lower(u.email);
