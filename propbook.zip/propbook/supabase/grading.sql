-- Propbook: results for saved props. Run once in Supabase → SQL Editor. Safe to run again.
alter table public.saved_props add column if not exists result text
  check (result is null or result in ('hit', 'miss', 'push', 'dnp'));
alter table public.saved_props add column if not exists actual numeric;
alter table public.saved_props add column if not exists graded_at timestamptz;
create index if not exists saved_props_ungraded_idx on public.saved_props (result, game_start);
