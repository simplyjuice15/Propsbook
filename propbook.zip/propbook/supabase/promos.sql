-- Propbook: complimentary Premium and promo codes. Run once in Supabase → SQL Editor. Safe to run again.

-- Free Premium time, separate from Stripe so payments never overwrite it.
alter table public.profiles add column if not exists comp_until timestamptz;
alter table public.profiles add column if not exists comp_note text;

-- Premium = paying subscriber OR complimentary time that hasn't run out.
create or replace function public.is_premium(uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = uid and (plan = 'premium' or comp_until > now())
  );
$$;

create table if not exists public.promo_codes (
  code text primary key,                 -- stored in capitals
  days integer not null check (days > 0),-- Premium time each person gets
  max_uses integer,                      -- blank = unlimited
  uses integer not null default 0,
  expires_at timestamptz,                -- last moment it can be redeemed; blank = never
  active boolean not null default true,
  note text,
  created_at timestamptz not null default now()
);
alter table public.promo_codes enable row level security; -- no policies: codes can't be listed from the site

create table if not exists public.promo_redemptions (
  code text not null references public.promo_codes (code) on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  redeemed_at timestamptz not null default now(),
  primary key (code, user_id)
);
alter table public.promo_redemptions enable row level security;

create or replace function public.redeem_promo(promo text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  c public.promo_codes;
  uid uuid := auth.uid();
  new_until timestamptz;
begin
  if uid is null then
    return jsonb_build_object('ok', false, 'message', 'Log in to use a promo code.');
  end if;
  select * into c from public.promo_codes where code = upper(trim(promo)) for update;
  if not found or not c.active then
    return jsonb_build_object('ok', false, 'message', 'That code isn''t valid.');
  end if;
  if c.expires_at is not null and c.expires_at < now() then
    return jsonb_build_object('ok', false, 'message', 'That code has expired.');
  end if;
  if c.max_uses is not null and c.uses >= c.max_uses then
    return jsonb_build_object('ok', false, 'message', 'That code has already been used the maximum number of times.');
  end if;
  if exists (select 1 from public.promo_redemptions where code = c.code and user_id = uid) then
    return jsonb_build_object('ok', false, 'message', 'You''ve already used this code.');
  end if;

  insert into public.promo_redemptions (code, user_id) values (c.code, uid);
  update public.promo_codes set uses = uses + 1 where code = c.code;
  update public.profiles
    set comp_until = greatest(coalesce(comp_until, now()), now()) + make_interval(days => c.days),
        comp_note = 'Promo ' || c.code
    where id = uid
    returning comp_until into new_until;
  return jsonb_build_object('ok', true, 'until', new_until, 'days', c.days);
end;
$$;
revoke all on function public.redeem_promo(text) from public, anon;
grant execute on function public.redeem_promo(text) to authenticated;
