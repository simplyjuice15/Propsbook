// @ts-nocheck
// Stripe → Propbook: turns Premium on when someone pays, and off when their
// subscription ends. Deploy in Supabase as an Edge Function named "stripe-webhook"
// with "Verify JWT" turned OFF (Stripe signs its own requests instead).
//
// Needs one secret in Supabase (Edge Functions → Secrets): STRIPE_WEBHOOK_SECRET
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.

const env = (name) =>
  (typeof Deno !== 'undefined' ? Deno.env.get(name) : globalThis.process?.env?.[name]) || '';

// ---------- Stripe signature check ----------
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function verifyStripeSignature(payload, header, secret, nowSec = Math.floor(Date.now() / 1000), tolerance = 300) {
  if (!header || !secret) return false;
  let timestamp = '';
  const signatures = [];
  for (const part of header.split(',')) {
    const [k, v] = part.split('=');
    if (k === 't') timestamp = v;
    if (k === 'v1') signatures.push(v);
  }
  if (!timestamp || !signatures.length || Math.abs(nowSec - Number(timestamp)) > tolerance) return false;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(`${timestamp}.${payload}`)));
  const expected = Array.from(mac, (b) => b.toString(16).padStart(2, '0')).join('');
  return signatures.some((s) => safeEqual(s, expected));
}

// ---------- what each event means for an account ----------
const KEEP_PREMIUM = new Set(['active', 'trialing', 'past_due']); // past_due = grace period while Stripe retries the card
const iso = (sec) => (sec ? new Date(sec * 1000).toISOString() : null);

export function planUpdateFor(event) {
  const o = event?.data?.object || {};
  switch (event?.type) {
    case 'checkout.session.completed': {
      const paid = o.mode === 'subscription' || o.payment_status === 'paid';
      if (!paid) return null;
      const email = (o.customer_details?.email || o.customer_email || '').toLowerCase();
      const match = o.client_reference_id ? { id: o.client_reference_id } : email ? { email } : null;
      if (!match) return null;
      return {
        match,
        patch: {
          plan: 'premium',
          stripe_customer_id: o.customer || null,
          stripe_subscription_id: o.subscription || null,
          subscription_status: o.mode === 'subscription' ? 'active' : 'lifetime',
        },
      };
    }
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      if (!o.customer) return null;
      return {
        match: { customer: o.customer },
        patch: {
          plan: KEEP_PREMIUM.has(o.status) ? 'premium' : 'free',
          subscription_status: o.cancel_at_period_end && o.status === 'active' ? 'canceling' : o.status,
          stripe_subscription_id: o.id,
          current_period_end: iso(o.current_period_end ?? o.items?.data?.[0]?.current_period_end),
        },
      };
    }
    case 'customer.subscription.deleted':
      if (!o.customer) return null;
      return { match: { customer: o.customer }, patch: { plan: 'free', subscription_status: 'canceled', current_period_end: null } };
    default:
      return null;
  }
}

// ---------- write to the profiles table ----------
export async function applyUpdate(update, { url, key, fetchImpl = fetch }) {
  const filter = update.match.id
    ? `id=eq.${encodeURIComponent(update.match.id)}`
    : update.match.email
      ? `email=eq.${encodeURIComponent(update.match.email)}`
      : `stripe_customer_id=eq.${encodeURIComponent(update.match.customer)}`;
  const headers = { apikey: key, 'Content-Type': 'application/json', Prefer: 'return=representation' };
  if (!key.startsWith('sb_')) headers.Authorization = `Bearer ${key}`; // legacy service_role JWT
  const res = await fetchImpl(`${url}/rest/v1/profiles?${filter}`, { method: 'PATCH', headers, body: JSON.stringify(update.patch) });
  if (!res.ok) throw new Error(`Database update failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const reply = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

export async function handleRequest(req, deps = {}) {
  if (req.method !== 'POST') return reply(405, { error: 'POST only' });
  const payload = await req.text();
  const secret = deps.secret ?? env('STRIPE_WEBHOOK_SECRET');
  if (!secret) return reply(500, { error: 'STRIPE_WEBHOOK_SECRET is not set' });
  const ok = await verifyStripeSignature(payload, req.headers.get('stripe-signature'), secret, deps.nowSec);
  if (!ok) return reply(400, { error: 'Bad signature' });

  const event = JSON.parse(payload);
  const update = planUpdateFor(event);
  if (!update) return reply(200, { received: true, ignored: event.type });

  try {
    const rows = await applyUpdate(update, {
      url: deps.url ?? env('SUPABASE_URL'),
      key: deps.key ?? (env('SUPABASE_SERVICE_ROLE_KEY') || env('SERVICE_ROLE_KEY')),
      fetchImpl: deps.fetchImpl,
    });
    if (!rows.length) console.warn(`No account matched ${event.type}`, update.match);
    return reply(200, { received: true, updated: rows.length });
  } catch (err) {
    console.error(err);
    return reply(500, { error: 'Update failed; Stripe will retry' });
  }
}

if (typeof Deno !== 'undefined') Deno.serve((req) => handleRequest(req));
