-- Propbook accounts. Paste this whole file into Supabase → SQL Editor → New query → Run.
-- Safe to run more than once.

-- 1) One profile per account, holding the plan. Everyone starts on free.
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  plan text not null default 'free' check (plan in ('free', 'premium')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

drop policy if exists "Read own profile" on public.profiles;
create policy "Read own profile" on public.profiles
  for select using (auth.uid() = id);
-- No update policy on purpose: people can't upgrade themselves.
-- You (or, later, the payment system) change `plan` from the dashboard.

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Profiles for anyone who signed up before this script ran.
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

create or replace function public.is_premium(uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = uid and plan = 'premium');
$$;

-- 2) Saved props. Only premium accounts can add them; the database enforces it.
create table if not exists public.saved_props (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  sport text not null,
  game_id text not null,
  player_id text not null,
  player_name text not null,
  team text,
  opp text,
  stat text not null,
  stat_label text,
  line numeric not null,
  side text not null check (side in ('over', 'under')),
  game_start timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, sport, game_id, player_id, stat, line, side)
);
alter table public.saved_props enable row level security;

drop policy if exists "Read own saved props" on public.saved_props;
create policy "Read own saved props" on public.saved_props
  for select using (auth.uid() = user_id);

drop policy if exists "Premium accounts save props" on public.saved_props;
create policy "Premium accounts save props" on public.saved_props
  for insert with check (auth.uid() = user_id and public.is_premium(auth.uid()));

drop policy if exists "Remove own saved props" on public.saved_props;
create policy "Remove own saved props" on public.saved_props
  for delete using (auth.uid() = user_id);

-- 3) Let people delete their own account (the App Store requires this).
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from auth.users where id = auth.uid();
end;
$$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- To make an account premium (replace the email):
-- update public.profiles set plan = 'premium'
--   where id = (select id from auth.users where email = 'you@example.com');
