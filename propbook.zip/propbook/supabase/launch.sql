-- Propbook launch hardening. Run once in Supabase → SQL Editor, after the earlier scripts. Safe to run again.

-- 1) Private storage for Premium data. Only Premium accounts can read it.
insert into storage.buckets (id, name, public) values ('premium', 'premium', false)
on conflict (id) do nothing;

drop policy if exists "Premium members read premium data" on storage.objects;
create policy "Premium members read premium data" on storage.objects
  for select to authenticated
  using (bucket_id = 'premium' and public.is_premium(auth.uid()));

-- 2) Age confirmation, recorded at sign-up.
alter table public.profiles add column if not exists age_confirmed_at timestamptz;

-- 3) Closing line value on saved props.
alter table public.saved_props add column if not exists close_line numeric;
alter table public.saved_props add column if not exists close_at timestamptz;

-- 4) Referrals.
alter table public.profiles add column if not exists referral_code text;
alter table public.profiles add column if not exists referred_by text;
alter table public.profiles add column if not exists referral_rewarded boolean not null default false;
update public.profiles set referral_code = upper(substr(md5(id::text), 1, 7)) where referral_code is null;
create unique index if not exists profiles_referral_code_idx on public.profiles (referral_code);

-- New accounts: store email, a referral code, who referred them, and the age confirmation.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, referral_code, referred_by, age_confirmed_at)
  values (
    new.id,
    lower(new.email),
    upper(substr(md5(new.id::text), 1, 7)),
    nullif(upper(trim(new.raw_user_meta_data ->> 'referred_by')), ''),
    case when (new.raw_user_meta_data ->> 'age_confirmed') = 'true' then now() end
  )
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

-- People can see their own code and how many friends have subscribed through it.
create or replace function public.my_referrals()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'code', (select referral_code from public.profiles where id = auth.uid()),
    'joined', (select count(*) from public.profiles p where p.referred_by = (select referral_code from public.profiles where id = auth.uid())),
    'rewarded', (select count(*) from public.profiles p where p.referred_by = (select referral_code from public.profiles where id = auth.uid()) and p.referral_rewarded)
  );
$$;
revoke all on function public.my_referrals() from public, anon;
grant execute on function public.my_referrals() to authenticated;
