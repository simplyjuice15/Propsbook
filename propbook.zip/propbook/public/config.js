// Accounts are off until SUPABASE_URL and SUPABASE_ANON_KEY are set (see README).
// The daily build rewrites this file from those settings.
export default { supabaseUrl: '', supabaseAnonKey: '' };
