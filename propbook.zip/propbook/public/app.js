// Propbook client. Reads the static JSON written by scripts/refresh.mjs.
import { applyTheme, toggleTheme } from './theme.js';
import {
  account, checkoutUrl, deleteAccount, redeemPromo, findSaved, initAccount, isPremium, onAccountChange, payments, portalUrl, refreshPlan, removeSaved,
  saveProp, sendPasswordReset, setNewPassword, signIn, signOut, signUp,
} from './auth.js';

const META_LEN = 6; // [date, season, opp, oppId, homeAway, result, ...values]
const WINDOWS = [
  ['l5', 'L5'],
  ['l10', 'L10'],
  ['l20', 'L20'],
  ['h2h', 'H2H'],
  ['szn', 'Season'],
];
const MAX_RECENT = 40;
const PAGE = 150;

const app = document.getElementById('app');
const cache = new Map();
let meta = null;
let index = null;
const ui = { side: 'over', sort: 'l10', market: '', q: '', shown: PAGE, win: 'l10' };

// ---------- utilities ----------
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtOdds = (p) => (p === null || p === undefined ? '' : p > 0 ? `+${p}` : `${p}`.replace('-', '−'));
const fmtNum = (v) => (v === null || v === undefined ? '–' : Number.isInteger(v) ? String(v) : v.toFixed(1));
const pctOf = ([hits, n]) => (n ? Math.round((hits / n) * 100) : null);

async function load(url) {
  if (cache.has(url)) return cache.get(url);
  const p = fetch(url, { cache: 'no-cache' }).then((r) => {
    if (!r.ok) throw new Error(`${r.status} loading ${url}`);
    return r.json();
  });
  cache.set(url, p);
  p.catch(() => cache.delete(url));
  return p;
}

function parseHash() {
  const [pathPart, query = ''] = location.hash.replace(/^#\/?/, '').split('?');
  const parts = pathPart.split('/').filter(Boolean).map(decodeURIComponent);
  const params = new URLSearchParams(query);
  return { parts, params };
}

function gameLabel(g) {
  return `${g.away.abbr} @ ${g.home.abbr}`;
}
function gameTime(g, multiDay) {
  const d = new Date(g.start);
  if (g.state === 'in') return 'Live';
  const opts = multiDay ? { weekday: 'short', hour: 'numeric', minute: '2-digit' } : { hour: 'numeric', minute: '2-digit' };
  return new Intl.DateTimeFormat(undefined, opts).format(d);
}
// Colour against the break-even the odds demand, not a flat 50%.
function heat(pct, breakeven = 50) {
  if (pct === null) return '';
  const strength = Math.min(60, Math.abs(pct - breakeven) * 1.2);
  const color = pct >= breakeven ? 'var(--hit)' : 'var(--miss)';
  return `background: color-mix(in srgb, ${color} ${strength}%, transparent)`;
}

// ---------- odds math ----------
/** What a price implies you must win to break even, as a percentage. */
export function breakEven(american) {
  if (american === null || american === undefined) return null;
  const pct = american < 0 ? -american / (-american + 100) : 100 / (american + 100);
  return Math.round(pct * 1000) / 10;
}
/** Profit on a $100 bet at American odds. */
export function profitPer100(american) {
  if (american === null || american === undefined) return null;
  return american < 0 ? (100 * 100) / -american : american;
}
/** The book paying most for this side, and how much more it pays than the worst. */
export function bestBookFor(prop, side) {
  const key = side === 'under' ? 'under' : 'over';
  const same = (prop?.books || []).filter((b) => b.line === prop.line && b[key] !== null && b[key] !== undefined);
  if (!same.length) return null;
  const sorted = [...same].sort((a, b) => profitPer100(b[key]) - profitPer100(a[key]));
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];
  return {
    book: best.book,
    price: best[key],
    breakeven: breakEven(best[key]),
    extraPer100: Math.round((profitPer100(best[key]) - profitPer100(worst[key])) * 100) / 100,
    shopped: sorted.length,
  };
}
function photo(p, cls = '') {
  return p.img
    ? `<img class="${cls}" src="${esc(p.img)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'ph'}))">`
    : '<span class="ph"></span>';
}

// ---------- Premium gating ----------
// With accounts connected, L20 / head-to-head / season splits, sportsbook comparison,
// batter-vs-pitcher and full game logs are Premium. Without accounts, everything shows.
const FREE_WINDOWS = new Set(['l5', 'l10']);
const unlocked = () => !account.configured || isPremium();
const windowOpen = (w) => unlocked() || FREE_WINDOWS.has(w);
const LOCK = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const lockPill = (text = 'Premium') => `<a class="lock-pill" href="#/account">${LOCK} ${text}</a>`;

// ---------- hit rates (mirrors scripts/lib/common.mjs) ----------
function windowsFor(player, season, oppId) {
  const recent = player.rows.slice(0, MAX_RECENT);
  return {
    l5: recent.slice(0, 5),
    l10: recent.slice(0, 10),
    l20: recent.slice(0, 20),
    h2h: player.rows.filter((r) => r[3] === String(oppId)),
    szn: recent.filter((r) => r[1] === season),
  };
}
function rateRows(rows, idx, line, side) {
  const vals = rows.map((r) => r[META_LEN + idx]).filter((v) => v !== null);
  const hits = vals.filter((v) => (side === 'under' ? v < line : v > line)).length;
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  return [hits, vals.length, avg];
}

// ---------- header ----------
function renderHeader(sport) {
  const nav = document.getElementById('sports');
  nav.innerHTML =
    meta.order
      .map((key) => {
        const s = meta.sports[key];
        const info = index?.sports?.[key];
        const count = info && !info.error ? `<span class="count">${info.games}</span>` : '';
        return `<a href="#/${key}" ${key === sport ? 'aria-current="page"' : ''}>${esc(s.short)}${count}</a>`;
      })
      .join('') +
    (isPremium() ? `<a class="saved-link" href="#/saved" ${sport === 'saved' ? 'aria-current="page"' : ''}>Saved</a>` : '');
  renderAccountLink();
}

function renderAccountLink() {
  const link = document.getElementById('account-link');
  if (!link) return;
  link.hidden = !account.enabled;
  if (!account.enabled) return;
  link.innerHTML = account.user
    ? `<span class="label">Account</span> <span class="badge ${isPremium() ? '' : 'free'}">${isPremium() ? 'Premium' : 'Free'}</span>`
    : 'Log in';
}

function updatedText(sport) {
  const info = index?.sports?.[sport];
  if (!info?.generatedAt) return '';
  const hours = (Date.now() - Date.parse(info.generatedAt)) / 3600e3;
  const when = new Intl.DateTimeFormat(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' }).format(new Date(info.generatedAt));
  return hours > 36 ? `Stale, last updated ${when}` : `Updated ${when}`;
}

/** Props / Injuries & news tabs shown at the top of each sport. */
function subnav(sport, active, alerts = 0) {
  return `<div class="subnav">
    <nav class="tabs" aria-label="${esc(meta.sports[sport].short)} sections">
      <a href="#/${sport}" ${active === 'props' ? 'aria-current="page"' : ''}>Props</a>
      <a href="#/${sport}/injuries" ${active === 'injuries' ? 'aria-current="page"' : ''}>Injuries &amp; news${alerts ? `<span class="dot" aria-label="${alerts} players out">${alerts}</span>` : ''}</a>
    </nav>
    <p class="updated ${updatedText(sport).startsWith('Stale') ? 'stale' : ''}">${esc(updatedText(sport))}</p>
  </div>`;
}

/** 3 = out or off the roster, 2 = uncertain, 1 = informational (mirrors scripts/lib/news.mjs). */
function severity(status = '') {
  const s = status.toLowerCase();
  if (/out|injured reserve|injured list|suspend|retire|waive|releas|dfa|season/.test(s)) return 3;
  if (/doubt|question|day-to-day|game-time|probable|illness|personal/.test(s)) return 2;
  return 1;
}

/** Injury and roster-move items that affect one game, worst first. */
function itemsForGame(report, gameId, players = []) {
  if (!report || !gameId) return [];
  const ids = new Set(players.filter((p) => p.gameId === gameId).map((p) => String(p.id)));
  return (report.items || [])
    .filter((i) => i.kind !== 'news' && (i.gameId === gameId || (i.pid && ids.has(String(i.pid)))))
    .sort((a, b) => severity(b.status) - severity(a.status) || (Date.parse(b.date) || 0) - (Date.parse(a.date) || 0));
}

async function outCount(sport) {
  try {
    const report = await load(`data/${sport}/injuries.json`);
    return new Set(report.items.filter((i) => i.pid && i.kind !== 'news' && severity(i.status) === 3).map((i) => i.pid)).size;
  } catch {
    return 0;
  }
}

// ---------- board ----------
async function renderBoard(sport, gameId) {
  const slate = await load(`data/${sport}/slate.json`);
  const s = meta.sports[sport];
  const multiDay = slate.from !== slate.until;
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  const players = new Map(slate.players.map((p) => [p.id, p]));
  const gamesById = new Map(slate.games.map((g) => [g.id, g]));

  const alerts = await outCount(sport);
  if (!slate.games.length) {
    app.innerHTML = `${subnav(sport, 'props', alerts)}<section class="empty"><h1>No ${esc(s.short)} games coming up</h1>
      <p class="muted">Nothing is on the schedule ${multiDay ? 'this week' : 'today'}. The slate rebuilds every morning, so check back tomorrow or pick another sport.</p></section>`;
    return;
  }

  const report = await load(`data/${sport}/injuries.json`).catch(() => null);
  const gameItems = itemsForGame(report, gameId, slate.players).slice(0, 8);
  const gameInjuries = gameId && gameItems.length
    ? `<section class="game-injuries">
        <h2>Injuries in this game</h2>
        <ul>${gameItems.map((i) => `<li>
          <span class="status s${severity(i.status)}">${esc(i.status)}</span>
          ${i.pid && i.gameId ? `<a href="#/${sport}/p/${esc(i.gameId)}/${encodeURIComponent(i.pid)}">${esc(i.player)}</a>` : `<b>${esc(i.player || i.teamName || i.team)}</b>`}
          <span class="muted">${esc([i.pos, i.team].filter(Boolean).join(' '))}${i.injury ? `, ${esc(i.injury)}` : ''}</span>
        </li>`).join('')}</ul>
        <a class="more-link" href="#/${sport}/injuries/g/${gameId}">Full report for this game</a>
      </section>`
    : '';

  const strip = `${subnav(sport, 'props', alerts)}<nav class="games" aria-label="Games">
      <a class="game" href="#/${sport}" aria-current="${!gameId}"><strong>All games</strong><span>${slate.games.length} on the slate</span></a>
      ${slate.games
        .map(
          (g) => `<a class="game" href="#/${sport}/g/${g.id}" aria-current="${g.id === gameId}">
            <strong>${esc(gameLabel(g))}</strong><span>${esc(gameTime(g, multiDay))}</span></a>`,
        )
        .join('')}
    </nav>`;

  if (!slate.props.length) {
    renderRoster(slate, s, gameId, strip, players, gamesById, sport);
    return;
  }

  const markets = [...new Set(slate.props.map((p) => p.stat))];
  const q = ui.q.trim().toLowerCase();
  if (!windowOpen(ui.sort)) ui.sort = 'l10';
  const sortKey = ui.sort;

  let rows = slate.props
    .filter((pr) => (!gameId || pr.gameId === gameId) && (!ui.market || pr.stat === ui.market))
    .map((pr) => {
      const p = players.get(pr.pid);
      if (!p) return null;
      const rates = {};
      for (const [w] of WINDOWS) {
        const [hits, n, avg] = pr.hr?.[w] || [0, 0, null];
        const h = ui.side === 'under' ? n - hits - pushes(pr, w) : hits;
        rates[w] = { hits: h, n, avg, pct: n ? Math.round((h / n) * 100) : null };
      }
      return { pr, p, rates };
    })
    .filter((r) => r && (!q || r.p.name.toLowerCase().includes(q) || r.p.team.toLowerCase() === q));

  rows.sort((a, b) => {
    if (sortKey === 'edge') {
      const ea = ((a.rates.l10.avg ?? a.pr.line) - a.pr.line) * (ui.side === 'under' ? -1 : 1);
      const eb = ((b.rates.l10.avg ?? b.pr.line) - b.pr.line) * (ui.side === 'under' ? -1 : 1);
      return eb - ea;
    }
    const pa = a.rates[sortKey].pct ?? -1;
    const pb = b.rates[sortKey].pct ?? -1;
    return pb - pa || b.rates[sortKey].n - a.rates[sortKey].n;
  });

  const total = rows.length;
  rows = rows.slice(0, ui.shown);
  const sortHead = (key, label) =>
    key !== 'edge' && !windowOpen(key)
      ? `<th class="num locked-head" title="Premium">${LOCK} ${label}</th>`
      : `<th class="num" ${sortKey === key ? 'aria-sort="descending"' : ''}><button data-sort="${key}">${label}</button></th>`;

  app.innerHTML = `
    ${strip}
    ${gameInjuries}
    <div class="toolbar">
      <label class="visually-hidden" for="q">Search players</label>
      <input id="q" type="search" placeholder="Search player or team" value="${esc(ui.q)}" autocomplete="off">
      <label class="visually-hidden" for="market">Market</label>
      <select id="market">
        <option value="">All markets</option>
        ${markets.map((m) => `<option value="${m}" ${m === ui.market ? 'selected' : ''}>${esc(statLabel[m] || m)}</option>`).join('')}
      </select>
      <label class="visually-hidden" for="sort">Sort by</label>
      <select id="sort" class="narrow-only">
        ${[...WINDOWS, ['edge', 'L10 avg']].map(([k, l]) => `<option value="${k}" ${k === sortKey ? 'selected' : ''} ${k !== 'edge' && !windowOpen(k) ? 'disabled' : ''}>Sort: ${k === 'edge' ? 'avg vs line' : `${l} hit %`}${k !== 'edge' && !windowOpen(k) ? ' (Premium)' : ''}</option>`).join('')}
      </select>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${ui.side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${ui.side === 'under'}">Under</button>
      </div>
    </div>
    ${unlocked() ? '<p class="muted legend">Shading compares each hit rate with the win rate the price needs. Grey cells are fewer than 5 games.</p>' : ''}
    ${unlocked() ? '' : `<p class="note upsell">L20, head-to-head, season hit rates and sportsbook odds comparison are part of Premium. ${lockPill('See Premium')}</p>`}
    ${total ? '' : '<p class="note">No lines match. Clear the search or pick another market.</p>'}
    <div class="board-wrap">
      <table class="board">
        <thead><tr>
          <th scope="col">Player</th><th scope="col">Market</th><th scope="col" class="num">Line</th>
          ${sortHead('l5', 'L5')}${sortHead('l10', 'L10')}${sortHead('l20', 'L20')}${sortHead('h2h', 'H2H')}${sortHead('szn', 'Season')}
          ${sortHead('edge', 'L10 avg')}
        </tr></thead>
        <tbody>
          ${rows
            .map(({ pr, p, rates }) => {
              const g = gamesById.get(pr.gameId);
              const href = `#/${sport}/p/${pr.gameId}/${encodeURIComponent(p.id)}?s=${pr.stat}&l=${pr.line}&side=${ui.side}`;
              const bb = unlocked() ? bestBookFor(pr, ui.side) : null;
              const be = bb?.breakeven ?? 50;
              return `<tr data-href="${href}">
                <td><div class="who">${photo(p)}<div><a href="${href}">${esc(p.name)}</a>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}
                  <small>${esc(p.pos)} ${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}${g && multiDay ? `, ${esc(gameTime(g, true))}` : ''}</small></div></div></td>
                <td>${esc(statLabel[pr.stat] || pr.stat)}</td>
                <td class="num"><span class="line-cell">${ui.side === 'over' ? 'O' : 'U'} ${fmtNum(pr.line)}</span>${bb ? `<small class="muted" style="display:block">${esc(`${fmtOdds(bb.price)} ${bb.book}`)}${bb.extraPer100 >= 1 ? ` <span class="edge-tag">+$${bb.extraPer100.toFixed(0)}</span>` : ''}</small>` : ''}</td>
                ${WINDOWS.map(([w]) => {
                  const r = rates[w];
                  const label = WINDOWS.find((x) => x[0] === w)[1];
                  if (!windowOpen(w)) return `<td class="num" data-w="${label}"><span class="rate locked" aria-label="${label} is a Premium stat">${LOCK}</span></td>`;
                  const thin = r.n > 0 && r.n < 5;
                  return `<td class="num" data-w="${label}"><span class="rate ${thin ? 'thin' : ''}" style="${thin ? '' : heat(r.pct, be)}" ${thin ? 'title="Small sample"' : ''}>${r.pct === null ? '–' : `${r.pct}%`}<small>${r.n ? `${r.hits}/${r.n}` : 'no games'}</small></span></td>`;
                }).join('')}
                <td class="num" data-w="L10 avg"><span class="line-cell">${fmtNum(rates.l10.avg)}</span></td>
              </tr>`;
            })
            .join('')}
        </tbody>
      </table>
    </div>
    ${total > rows.length ? `<button class="btn more" id="more">Show ${Math.min(PAGE, total - rows.length)} more of ${total - rows.length}</button>` : ''}
    ${slate.oddsNote ? `<p class="note">${esc(slate.oddsNote)}</p>` : ''}
  `;

  const q$ = document.getElementById('q');
  q$.addEventListener('input', () => {
    ui.q = q$.value;
    ui.shown = PAGE;
    const pos = q$.selectionStart;
    renderBoard(sport, gameId).then(() => {
      const el = document.getElementById('q');
      el.focus();
      el.setSelectionRange(pos, pos);
    });
  });
  document.getElementById('market').addEventListener('change', (e) => {
    ui.market = e.target.value;
    ui.shown = PAGE;
    renderBoard(sport, gameId);
  });
  document.getElementById('sort').addEventListener('change', (e) => {
    ui.sort = e.target.value;
    renderBoard(sport, gameId);
  });
  app.querySelectorAll('[data-side]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.side = b.dataset.side;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('[data-sort]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.sort = b.dataset.sort;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('tr[data-href]').forEach((tr) =>
    tr.addEventListener('click', (e) => {
      if (e.target.closest('a')) return;
      location.hash = tr.dataset.href;
    }),
  );
  document.getElementById('more')?.addEventListener('click', () => {
    ui.shown += PAGE;
    renderBoard(sport, gameId);
  });
}

// Precomputed rates count over hits; under hits exclude games that landed exactly on the line.
function pushes(pr, w) {
  return pr.hr?.[w]?.[3] ?? 0;
}

function bestPrice(pr, side) {
  const key = side === 'under' ? 'under' : 'over';
  const same = pr.books.filter((b) => b.line === pr.line && b[key] !== null);
  if (!same.length) return '';
  const best = same.reduce((a, b) => (b[key] > a[key] ? b : a));
  return `${fmtOdds(best[key])} ${best.book}`;
}

function renderRoster(slate, s, gameId, strip, players, gamesById, sport) {
  const list = slate.players.filter((p) => !gameId || p.gameId === gameId);
  const byTeam = new Map();
  for (const p of list) {
    const k = `${p.gameId}|${p.team}`;
    if (!byTeam.has(k)) byTeam.set(k, []);
    byTeam.get(k).push(p);
  }
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  app.innerHTML = `
    ${strip}
    <p class="note">No sportsbook lines in this refresh${slate.oddsNote ? ` (${esc(slate.oddsNote)})` : ''}. Numbers are last-10-game averages. Open a player to set your own line.</p>
    ${[...byTeam.entries()]
      .map(([k, ps]) => {
        const [gid, team] = k.split('|');
        const g = gamesById.get(gid);
        ps.sort((a, b) => b.gp - a.gp);
        return `<div class="team-head"><h2>${esc(team)}</h2><span class="muted">${g ? esc(gameLabel(g)) : ''}</span></div>
          <div class="roster">${ps
            .map(
              (p) => `<a href="#/${sport}/p/${p.gameId}/${encodeURIComponent(p.id)}">
                <div class="who">${photo(p)}<div><b>${esc(p.name)}</b>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}<small>${esc(p.pos)}</small></div></div>
                <div class="avgs">${Object.entries(p.avg)
                  .map(([k2, v]) => `<div><b>${fmtNum(v)}</b><span>${esc(shortLabel(statLabel[k2] || k2))}</span></div>`)
                  .join('')}</div></a>`,
            )
            .join('')}</div>`;
      })
      .join('')}`;
}
const shortLabel = (label) => label.replace('Passing yards', 'Pass yds').replace('Rushing yards', 'Rush yds').replace('Receiving yards', 'Rec yds').replace('Total bases', 'TB').replace('Hits + Runs + RBIs', 'H+R+RBI');

// ---------- player ----------
async function renderPlayer(sport, gameId, pid, params) {
  const [slate, game] = await Promise.all([load(`data/${sport}/slate.json`), load(`data/${sport}/games/${gameId}.json`)]);
  const s = meta.sports[sport];
  const p = game.players.find((x) => x.id === pid);
  const back = `<a class="back" href="#/${sport}${ui.lastGame ? `/g/${ui.lastGame}` : ''}">← Back to ${esc(s.short)} board</a>`;
  if (!p) {
    app.innerHTML = `${back}<section class="empty"><h1>Player not on this slate</h1><p class="muted">The slate has been rebuilt since this link was made. Go back to the board to find them.</p></section>`;
    return;
  }
  const g = slate.games.find((x) => x.id === gameId);
  const statDefs = s.stats.filter((x) => p.cols.includes(x.key));
  const props = slate.props.filter((x) => x.pid === pid);
  const stat = p.cols.includes(params.get('s')) ? params.get('s') : props[0]?.stat || (s.headline[p.role] || s.headline.all || [p.cols[0]])[0];
  const idx = p.cols.indexOf(stat);
  const prop = props.find((x) => x.stat === stat);
  const side = params.get('side') === 'under' ? 'under' : 'over';

  // Splits: same venue type as tonight's game, and recent form only.
  const f = (ui.filters ||= { loc: 'all', recent: false });
  const wantHA = p.home ? 'vs' : '@';
  const cutoff = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
  const filtered = {
    ...p,
    rows: p.rows.filter((r) => (f.loc === 'all' || r[4] === wantHA) && (!f.recent || r[0] >= cutoff)),
  };
  const wins = windowsFor(filtered, slate.season, p.oppId);
  const filtering = f.loc !== 'all' || f.recent;

  let line = Number(params.get('l'));
  if (!params.has('l') || Number.isNaN(line)) {
    if (prop) line = prop.line;
    else {
      const avg = rateRows(wins.l10, idx, 0, 'over')[2];
      line = avg === null ? 0.5 : Math.max(0.5, Math.round(avg) - 0.5);
    }
  }
  if (!windowOpen(ui.win)) ui.win = 'l10';
  const win = ui.win;

  const setParams = (changes) => {
    const next = new URLSearchParams({ s: stat, l: String(line), side, ...changes });
    history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
    renderPlayer(sport, gameId, pid, next);
  };

  const bb = unlocked() ? bestBookFor(prop, side) : null;
  const priced = bb && prop && prop.line === line;
  const be = priced ? bb.breakeven : 50;

  const tiles = WINDOWS.map(([w, label]) => {
    if (!windowOpen(w)) {
      return `<a class="tile locked" href="#/account" aria-label="${label} hit rate is a Premium stat">
        <span class="w">${label}</span><span class="pct">${LOCK}</span><span class="sub">Premium</span></a>`;
    }
    const [hits, n, avg] = rateRows(wins[w], idx, line, side);
    const pct = pctOf([hits, n]);
    const thin = n > 0 && n < 5;
    const cls = pct === null || thin ? '' : pct >= be + 8 ? 'good' : pct < be - 8 ? 'bad' : '';
    return `<button class="tile ${cls} ${thin ? 'thin' : ''}" data-win="${w}" aria-pressed="${w === win}">
      <span class="w">${label}</span><span class="pct">${pct === null ? '–' : `${pct}%`}</span>
      <span class="sub">${n ? `${hits} of ${n}` : 'No games'}${thin ? ', small sample' : ''}</span><span class="sub">${avg === null ? '' : `avg ${fmtNum(Math.round(avg * 10) / 10)}`}</span>
    </button>`;
  }).join('');

  const chartRows = [...wins[win]].reverse().filter((r) => r[META_LEN + idx] !== null);
  const statLabel = statDefs.find((x) => x.key === stat)?.label || stat;

  const cols = (s.logCols[p.role] || s.logCols.all || p.cols).filter((c) => p.cols.includes(c));
  if (!cols.includes(stat)) cols.unshift(stat);
  const labelFor = (k) => abbrev(k, s.stats);

  const savedProp = {
    sport, game_id: gameId, player_id: pid, player_name: p.name, team: p.team, opp: p.opp,
    stat, stat_label: statLabel, line, side, game_start: g?.start || null,
  };

  app.innerHTML = `
    ${back}
    <header class="player-head">
      ${photo(p)}
      <div>
        <h1>${esc(p.name)}${p.inj ? ` <span class="inj">${esc(p.inj)}</span>` : ''}</h1>
        <p><span>${esc(p.pos)}</span> <span class="matchup">${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}</span>
        ${g ? `<span>${esc(gameTime(g, slate.from !== slate.until))}</span>` : ''}</p>
      </div>
    </header>
    ${injuryBanner(p)}

    <div class="stat-tabs" role="group" aria-label="Stat">
      ${statDefs
        .map((d) => `<button data-stat="${d.key}" aria-pressed="${d.key === stat}" class="${props.some((x) => x.stat === d.key) ? 'has-line' : ''}">${esc(d.label)}</button>`)
        .join('')}
    </div>

    <div class="line-row">
      <div class="line-ctl">
        <button data-step="-0.5" aria-label="Lower line">−</button>
        <label><span>${esc(statLabel)}</span><input id="line" type="number" inputmode="decimal" step="0.5" min="0" value="${line}"></label>
        <button data-step="0.5" aria-label="Raise line">+</button>
      </div>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${side === 'under'}">Under</button>
      </div>
      ${
        prop && !unlocked()
          ? `<div class="books"><button class="book" data-line="${prop.line}" aria-pressed="${prop.line === line}"><b>Line ${fmtNum(prop.line)}</b><span>Consensus</span></button>${lockPill(`Compare ${prop.books.length} sportsbook${prop.books.length === 1 ? '' : 's'}`)}</div>`
          : prop
          ? `<div class="books">${prop.books
              .map(
                (b) => `<button class="book" data-line="${b.line}" aria-pressed="${b.line === line}">
                  <b>${esc(b.book)} ${fmtNum(b.line)}</b><span>O ${fmtOdds(b.over) || '–'} U ${fmtOdds(b.under) || '–'}</span></button>`,
              )
              .join('')}</div>`
          : '<span class="muted">No sportsbook line for this stat. Set your own.</span>'
      }
    </div>

    ${saveControl(savedProp)}

    <div class="chips splits" role="group" aria-label="Filter games">
      <button class="chip" type="button" data-loc="all" aria-pressed="${f.loc === 'all'}">All games</button>
      <button class="chip" type="button" data-loc="${wantHA}" aria-pressed="${f.loc !== 'all'}">${p.home ? 'Home games' : 'Road games'}</button>
      <button class="chip" type="button" data-recent="1" aria-pressed="${f.recent}">Last 30 days</button>
    </div>
    ${priced ? `<p class="breakeven">At ${esc(fmtOdds(bb.price))} (${esc(bb.book)}) you need <b>${bb.breakeven}%</b> to break even.${bb.extraPer100 >= 1 ? ` That's $${bb.extraPer100.toFixed(0)} more per $100 than the worst of the ${bb.shopped} books.` : ''}</p>` : ''}
    <div class="tiles">${tiles}</div>

    ${filtering ? `<p class="muted legend">Showing ${f.loc === 'all' ? '' : `${p.home ? 'home' : 'road'} games`}${filtering && f.loc !== 'all' && f.recent ? ' from ' : ''}${f.recent ? 'the last 30 days' : ''} only.</p>` : ''}
    <figure class="chart" style="margin:0">
      <figcaption class="caption"><span>${esc(statLabel)}, ${WINDOWS.find((w) => w[0] === win)[1]} ${win === 'h2h' ? `vs ${esc(p.opp)}` : 'games'}</span>
        <span class="muted">${side === 'over' ? 'Over' : 'Under'} ${fmtNum(line)}</span></figcaption>
      ${chartRows.length ? barChart(chartRows, idx, line, side) : `<p class="muted" style="padding:0 8px">No ${win === 'h2h' ? `games against ${esc(p.opp)}` : 'games'} in the last two seasons.</p>`}
    </figure>

    ${unlocked() ? matchupCard(p, sport, stat, statLabel, s) : (p.matchup ? `<section class="matchup-card"><h2>Matchup: ${esc(p.opp)} defense</h2><p class="muted">See what this defense allows to ${esc(groupLabelFor(sport, p.matchup.group))}, and where it ranks.</p>${lockPill('Unlock matchups')}</section>` : '')}
    ${p.bvp && !unlocked() ? `<section class="bvp"><h3>Career vs ${esc(p.bvp.pitcher)}</h3>${lockPill('Unlock batter vs pitcher')}</section>` : ''}
    ${p.bvp && unlocked() ? `<section class="bvp"><h3>Career vs ${esc(p.bvp.pitcher)}</h3>
      <div><b>${p.bvp.h}-${p.bvp.ab}</b>hits</div><div><b>${esc(p.bvp.avg)}</b>avg</div><div><b>${p.bvp.hr}</b>HR</div>
      <div><b>${p.bvp.bb}</b>BB</div><div><b>${p.bvp.so}</b>K</div><div><b>${esc(p.bvp.ops)}</b>OPS</div></section>` : ''}

    <section class="log">
      <h2>Game log</h2>
      <div class="log-wrap"><table class="gl">
        <thead><tr><th>Date</th><th>Opp</th><th>Result</th>${cols.map((c) => `<th ${c === stat ? 'class="sel"' : ''} title="${esc(s.stats.find((x) => x.key === c)?.label || c)}">${esc(labelFor(c))}</th>`).join('')}</tr></thead>
        <tbody>${p.rows
          .filter((r, i) => unlocked() || i < 10)
          .slice(0, ui.fullLog ? p.rows.length : 20)
          .map((r) => {
            const v = r[META_LEN + idx];
            const hit = v === null || v === line ? '' : (side === 'under' ? v < line : v > line) ? 'h' : 'm';
            return `<tr class="${unlocked() && r[3] === String(p.oppId) ? 'h2h' : ''}"><td>${esc(shortDate(r[0]))}</td><td>${esc(r[4])} ${esc(r[2])}</td><td>${esc(r[5])}</td>
              ${cols.map((c) => {
                const val = r[META_LEN + p.cols.indexOf(c)];
                return `<td class="${c === stat ? `sel ${hit}` : ''}">${fmtNum(val)}</td>`;
              }).join('')}</tr>`;
          })
          .join('')}</tbody>
      </table></div>
      ${!unlocked() && p.rows.length > 10 ? `<p class="note upsell">Showing the last 10 games. ${lockPill(`See all ${p.rows.length} with Premium`)}</p>` : ''}
      ${unlocked() && p.rows.length > 20 ? `<button class="btn more" id="full-log">${ui.fullLog ? 'Show last 20 games' : `Show all ${p.rows.length} games`}</button>` : ''}
    </section>
  `;

  app.querySelectorAll('[data-stat]').forEach((b) =>
    b.addEventListener('click', () => {
      const pr = props.find((x) => x.stat === b.dataset.stat);
      const next = new URLSearchParams({ s: b.dataset.stat, side });
      if (pr) next.set('l', pr.line);
      history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
      renderPlayer(sport, gameId, pid, next);
    }),
  );
  app.querySelectorAll('[data-step]').forEach((b) =>
    b.addEventListener('click', () => setParams({ l: String(Math.max(0, line + Number(b.dataset.step))) })),
  );
  const input = document.getElementById('line');
  input.addEventListener('change', () => {
    const v = Number(input.value);
    if (!Number.isNaN(v) && v >= 0) setParams({ l: String(v) });
  });
  app.querySelectorAll('[data-side]').forEach((b) => b.addEventListener('click', () => setParams({ side: b.dataset.side })));
  app.querySelectorAll('[data-line]').forEach((b) => b.addEventListener('click', () => setParams({ l: b.dataset.line })));
  app.querySelectorAll('[data-loc]').forEach((b) => b.addEventListener('click', () => {
    f.loc = b.dataset.loc;
    setParams({});
  }));
  app.querySelector('[data-recent]')?.addEventListener('click', () => {
    f.recent = !f.recent;
    setParams({});
  });
  document.getElementById('share-btn')?.addEventListener('click', () =>
    shareCard({ player: p, stat, statLabel, line, side, wins, idx, win, sport: s.short, breakeven: priced ? bb.breakeven : null }),
  );

  wireSave(savedProp, () => setParams({}));
  document.getElementById('full-log')?.addEventListener('click', () => {
    ui.fullLog = !ui.fullLog;
    setParams({});
  });
  app.querySelectorAll('[data-win]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.win = b.dataset.win;
      setParams({});
    }),
  );
}

const GROUP_LABEL = {
  QB: 'quarterbacks', RB: 'running backs', WR: 'wide receivers', TE: 'tight ends', K: 'kickers', DEF: 'defenders',
  G: 'guards', F: 'forwards', C: 'centers', D: 'defensemen', ALL: 'this position',
};
const groupLabelFor = (sport, group) => (sport === 'nhl' && group === 'G' ? 'goalies' : sport === 'nhl' && group === 'F' ? 'forwards' : GROUP_LABEL[group] || 'this position');

/** How friendly a rank is: 1 = allows the most. */
const rankTone = (rank, of) => (of < 6 ? '' : rank <= of / 3 ? 'good' : rank > (of * 2) / 3 ? 'bad' : '');
const ordinal = (n) => {
  const s2 = ['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) || n % 10 > 3 ? 0 : n % 10];
  return `${n}${s2}`;
};

/** What tonight's opponent gives up to this player's position. */
function matchupCard(p, sport, stat, statLabel, s) {
  const m = p.matchup;
  if (!m) return '';
  const who = groupLabelFor(sport, m.group);
  const labelOf = (key) => s.stats.find((x) => x.key === key)?.label || key;
  const order = [stat, ...Object.keys(m.stats).filter((k) => k !== stat)];
  const rows = order.filter((k) => m.stats[k]).slice(0, 8);
  if (!rows.length) return '';
  const headline = m.stats[stat];
  return `<section class="matchup-card">
    <h2>Matchup: ${esc(p.opp)} defense</h2>
    <p class="muted">Per game allowed to ${esc(who)}${m.games ? ` over ${m.games} games` : ''}. Rank 1 allows the most.</p>
    ${headline ? `<p class="matchup-head ${rankTone(headline.rank, headline.of)}">
      <b>${fmtNum(headline.value)}</b> ${esc(statLabel.toLowerCase())} allowed, <b>${esc(ordinal(headline.rank))}</b> most of ${headline.of}</p>` : ''}
    <div class="matchup-grid">${rows.map((k) => {
      const v = m.stats[k];
      return `<div class="${k === stat ? 'is-stat' : ''}">
        <span class="label">${esc(labelOf(k))}</span>
        <span class="value">${fmtNum(v.value)}</span>
        <span class="rank ${rankTone(v.rank, v.of)}">${esc(ordinal(v.rank))} most</span>
      </div>`;
    }).join('')}</div>
  </section>`;
}

function injuryBanner(p) {
  const i = p.injury;
  if (!i && !p.inj) return '';
  const status = i?.status || p.inj;
  const details = [i?.injury, i?.returnDate ? `expected back ${shortDate(i.returnDate.slice(0, 10))}` : ''].filter(Boolean).join(', ');
  return `<div class="inj-banner s${severity(status)}" role="note"><b>${esc(status)}</b>${details ? ` ${esc(details)}` : ''}${i?.note ? `<br>${esc(i.note)}` : ''}</div>`;
}

const SHARE = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M12 3 8 7M12 3l4 4"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/></svg>';
const PIN = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4.5L6 21z"/></svg>';

function saveControl(prop) {
  let button = '';
  if (account.enabled) {
    if (!account.user) button = `<button class="save-btn" data-save="login" type="button">${PIN} Save prop</button>`;
    else if (!isPremium()) button = `<button class="save-btn" data-save="upsell" type="button">${PIN} Save prop <span class="lock">Premium</span></button>`;
    else {
      const saved = findSaved(prop);
      button = `<button class="save-btn" data-save="toggle" type="button" aria-pressed="${Boolean(saved)}">${PIN} ${saved ? 'Saved' : 'Save prop'}</button>`;
    }
  }
  return `<div class="save-row" style="margin-top:12px">${button}<button class="save-btn" id="share-btn" type="button">${SHARE} Share</button><p class="save-note" id="save-note" hidden></p></div>`;
}

function wireSave(prop, rerender) {
  const btn = app.querySelector('[data-save]');
  const note = document.getElementById('save-note');
  if (!btn) return;
  const say = (html) => {
    note.innerHTML = html;
    note.hidden = false;
  };
  btn.addEventListener('click', async () => {
    const mode = btn.dataset.save;
    if (mode === 'login') {
      location.hash = `#/account?next=${encodeURIComponent(location.hash)}`;
      return;
    }
    if (mode === 'upsell') {
      say('Saving props is part of Premium. <a href="#/account">See plans</a>');
      return;
    }
    btn.disabled = true;
    const existing = findSaved(prop);
    const res = existing ? await removeSaved(existing.id) : await saveProp(prop);
    btn.disabled = false;
    if (!res.ok) return say(esc(res.message));
    rerender();
  });
}

function abbrev(key, stats) {
  const map = {
    min: 'MIN', pts: 'PTS', reb: 'REB', ast: 'AST', fg3m: '3PM', stl: 'STL', blk: 'BLK', tov: 'TO', pra: 'PRA', pr: 'PR', pa: 'PA', ra: 'RA',
    stocks: 'STK', fgm: 'FGM', fga: 'FGA', fg3a: '3PA', ftm: 'FTM',
    cmp: 'CMP', passAtt: 'ATT', passYds: 'PYDS', passTd: 'PTD', int: 'INT', passLng: 'LNG', rushAtt: 'CAR', rushYds: 'RYDS', rushLng: 'RLNG',
    rec: 'REC', tgt: 'TGT', recYds: 'RECYDS', recLng: 'RECLNG', rushRecYds: 'R+R', passRushYds: 'P+R', tds: 'TD', tkl: 'TKL', solo: 'SOLO',
    sacks: 'SACK', defInt: 'INT', pd: 'PD', xpm: 'XP', kpts: 'KPTS',
    fantasy: 'FPTS', pFantasy: 'FPTS', gFantasy: 'FPTS',
    points: 'PTS', goals: 'G', assists: 'A', shots: 'SOG', blocks: 'BLK', hits: 'HIT', ppp: 'PPP', pim: 'PIM', toi: 'TOI',
    saves: 'SV', shotsAgainst: 'SA', goalsAgainst: 'GA',
    h: 'H', tb: 'TB', hrr: 'H+R+RBI', hr: 'HR', rbi: 'RBI', r: 'R', singles: '1B', doubles: '2B', bb: 'BB', so: 'K', sb: 'SB', ab: 'AB',
    pK: 'K', pOuts: 'OUTS', pH: 'H', pER: 'ER', pBB: 'BB', pitches: 'PC',
  };
  return map[key] || stats.find((s) => s.key === key)?.label || key;
}

function shortDate(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  const thisYear = new Date().getFullYear();
  return `${m}/${d}${y !== thisYear ? `/${String(y).slice(2)}` : ''}`;
}

function barChart(rows, idx, line, side) {
  const available = Math.max(320, (app.clientWidth || 700) - 20);
  const W = Math.max(available, rows.length * 30 + 48);
  const H = 230;
  const top = 22;
  const bottom = 34;
  const left = 8;
  const right = 40;
  const vals = rows.map((r) => r[META_LEN + idx]);
  const max = Math.max(line, ...vals, 1) * 1.15;
  const plotH = H - top - bottom;
  const y = (v) => top + plotH - (v / max) * plotH;
  const slot = (W - left - right) / rows.length;
  const bw = Math.min(38, slot * 0.66);

  const bars = rows
    .map((r, i) => {
      const v = r[META_LEN + idx];
      const hit = side === 'under' ? v < line : v > line;
      const cls = v === line ? 'bar-push' : hit ? 'bar-hit' : 'bar-miss';
      const x = left + i * slot + (slot - bw) / 2;
      const h = Math.max(2, top + plotH - y(v));
      const cx = x + bw / 2;
      return `<g><title>${esc(r[0])} ${esc(r[4])} ${esc(r[2])}: ${fmtNum(v)}</title>
        <rect class="bar ${cls}" x="${x.toFixed(1)}" y="${(top + plotH - h).toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="2"/>
        <text class="bar-val" x="${cx.toFixed(1)}" y="${(top + plotH - h - 5).toFixed(1)}">${fmtNum(v)}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 15}">${esc(r[2])}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 28}">${esc(shortDate(r[0]))}</text></g>`;
    })
    .join('');
  const ly = y(line).toFixed(1);
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Game by game results against the line">
    <line class="axis" x1="${left}" x2="${W - right}" y1="${top + plotH}" y2="${top + plotH}"/>
    ${bars}
    <line class="line-rule" x1="${left}" x2="${W - right + 4}" y1="${ly}" y2="${ly}"/>
    <text class="line-tag" x="${W - right + 8}" y="${Number(ly) + 5}">${fmtNum(line)}</text>
  </svg>`;
}



// ---------- shareable prop card ----------
const themeVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim() || '#888';

/** Draw the current prop as an image and hand it to the phone's share sheet. */
export async function shareCard({ player, statLabel, line, side, wins, idx, win, sport, breakeven }) {
  const W = 1080;
  const H = 1350;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const x = c.getContext('2d');
  const ink = themeVar('--text');
  const bg = themeVar('--bg');
  const muted = themeVar('--muted');
  const hit = themeVar('--hit');
  const miss = themeVar('--miss');
  const lamp = themeVar('--lamp');
  const body = "600 34px Barlow, system-ui, sans-serif";
  const display = (size, weight = 700) => `${weight} ${size}px 'Barlow Condensed', 'Arial Narrow', sans-serif`;
  /** Shrink text until it fits the width given, then draw it. */
  const fit = (text, px, py, maxW, size, weight = 700) => {
    let s2 = size;
    do {
      x.font = display(s2, weight);
      s2 -= 2;
    } while (x.measureText(text).width > maxW && s2 > 16);
    x.fillText(text, px, py);
  };

  x.fillStyle = bg;
  x.fillRect(0, 0, W, H);
  x.fillStyle = lamp;
  x.fillRect(0, 0, W, 10);

  x.fillStyle = ink;
  fit(player.name, 60, 150, W - 120, 84);
  x.font = body;
  x.fillStyle = muted;
  x.fillText(`${player.pos}   ${player.team} ${player.home ? 'vs' : '@'} ${player.opp}   ${sport}`, 62, 200);

  x.fillStyle = ink;
  fit(`${side === 'under' ? 'Under' : 'Over'} ${fmtNum(line)} ${statLabel}`, 60, 320, W - 120, 96);
  if (breakeven !== null && breakeven !== undefined) {
    x.font = body;
    x.fillStyle = muted;
    x.fillText(`Break-even ${breakeven}%`, 62, 372);
  }

  // hit-rate tiles
  const tiles = WINDOWS.filter(([w]) => windowOpen(w)).map(([w, label]) => {
    const [hits, n] = rateRows(wins[w], idx, line, side);
    return [label, pctOf([hits, n]), hits, n];
  });
  const tw = (W - 120 - (tiles.length - 1) * 18) / tiles.length;
  tiles.forEach(([label, pct, hits, n], i) => {
    const tx = 60 + i * (tw + 18);
    x.fillStyle = themeVar('--panel');
    x.fillRect(tx, 420, tw, 190);
    x.fillStyle = muted;
    x.font = display(34, 600);
    x.fillText(label, tx + 22, 466);
    x.fillStyle = pct === null ? muted : pct >= (breakeven ?? 50) ? hit : miss;
    fit(pct === null ? '–' : `${pct}%`, tx + 22, 545, tw - 40, 78);
    x.fillStyle = muted;
    x.font = "500 26px Barlow, system-ui, sans-serif";
    x.fillText(n ? `${hits} of ${n}` : 'no games', tx + 22, 585);
  });

  // last games as bars
  const rows = [...wins[win]].reverse().filter((r) => r[META_LEN + idx] !== null).slice(-10);
  const top = 700;
  const plotH = 430;
  const max = Math.max(line, ...rows.map((r) => r[META_LEN + idx]), 1) * 1.2;
  const slot = (W - 120) / Math.max(rows.length, 1);
  rows.forEach((r, i) => {
    const v = r[META_LEN + idx];
    const won = side === 'under' ? v < line : v > line;
    const bw = Math.min(70, slot * 0.62);
    const bx = 60 + i * slot + (slot - bw) / 2;
    const bh = (v / max) * plotH;
    x.fillStyle = won ? hit : miss;
    x.globalAlpha = won ? 1 : 0.35;
    x.fillRect(bx, top + plotH - bh, bw, bh);
    x.globalAlpha = 1;
    x.fillStyle = ink;
    x.font = display(32, 600);
    x.textAlign = 'center';
    x.fillText(fmtNum(v), bx + bw / 2, top + plotH - bh - 14);
    x.fillStyle = muted;
    x.font = "500 24px Barlow, system-ui, sans-serif";
    x.fillText(r[2], bx + bw / 2, top + plotH + 36);
    x.textAlign = 'left';
  });
  const ly = top + plotH - (line / max) * plotH;
  x.strokeStyle = lamp;
  x.lineWidth = 5;
  x.beginPath();
  x.moveTo(60, ly);
  x.lineTo(W - 60, ly);
  x.stroke();

  x.fillStyle = muted;
  x.font = body;
  x.fillText(`${WINDOWS.find((w) => w[0] === win)[1]} games`, 62, top + plotH + 100);
  x.fillStyle = ink;
  x.font = display(48);
  x.textAlign = 'right';
  x.fillText(location.host || 'Propbook', W - 60, top + plotH + 105);
  x.textAlign = 'left';

  const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
  if (!blob) return;
  const fileName = `${player.name.replace(/\W+/g, '-').toLowerCase()}-${statLabel.replace(/\W+/g, '-').toLowerCase()}.png`;
  const file = new File([blob], fileName, { type: 'image/png' });
  const note = document.getElementById('save-note');
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], text: `${player.name} ${side === 'under' ? 'under' : 'over'} ${fmtNum(line)} ${statLabel}` });
      return;
    } catch {
      /* cancelled or refused: fall through to a download */
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  if (note) {
    note.textContent = 'Image saved to your downloads.';
    note.hidden = false;
  }
}

// ---------- injuries & news ----------
function relDay(iso) {
  const t = Date.parse(iso);
  if (!t) return '';
  const d = new Date(t);
  const today = new Date();
  const days = Math.round((new Date(today.toDateString()) - new Date(d.toDateString())) / 864e5);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(d);
}

async function renderInjuries(sport, gameId) {
  const s = meta.sports[sport];
  const [report, slate] = await Promise.all([
    load(`data/${sport}/injuries.json`).catch(() => null),
    load(`data/${sport}/slate.json`).catch(() => null),
  ]);
  const alerts = await outCount(sport);
  const f = (ui.injFilter ||= { scope: 'slate', kind: 'all' });
  if (!report) {
    app.innerHTML = `${subnav(sport, 'injuries')}<section class="empty"><h1>Injury report coming soon</h1>
      <p class="muted">It's added on the next daily refresh.</p></section>`;
    return;
  }
  const items = report.items.filter(
    (i) =>
      (gameId ? i.gameId === gameId : f.scope === 'all' || i.onSlate) &&
      (f.kind === 'all' || i.kind === f.kind),
  );
  const multiDay = slate && slate.from !== slate.until;
  const gamesStrip = slate?.games?.length
    ? `<nav class="games" aria-label="Games">
        <a class="game" href="#/${sport}/injuries" aria-current="${!gameId}"><strong>All teams</strong><span>league-wide</span></a>
        ${slate.games.map((g) => `<a class="game" href="#/${sport}/injuries/g/${g.id}" aria-current="${g.id === gameId}">
          <strong>${esc(gameLabel(g))}</strong><span>${esc(gameTime(g, multiDay))}</span></a>`).join('')}
      </nav>`
    : '';
  const chip = (group, value, label) =>
    `<button class="chip" type="button" data-${group}="${value}" aria-pressed="${f[group] === value}">${label}</button>`;

  const row = (i) => {
    const title = i.kind === 'news'
      ? i.url ? `<a href="${esc(i.url)}" target="_blank" rel="noopener">${esc(i.headline)}</a>` : esc(i.headline)
      : i.pid && i.gameId ? `<a href="#/${sport}/p/${esc(i.gameId)}/${encodeURIComponent(i.pid)}">${esc(i.player)}</a>` : esc(i.player || i.teamName || i.team);
    const namedPlayer = i.kind !== 'news' && (i.player || i.pid);
    const meta1 = namedPlayer ? [i.pos, i.team || i.teamName].filter(Boolean).map(esc).join(' ') : '';
    const detail = i.kind === 'injury'
      ? [i.side, i.injury].filter(Boolean).join(' ') + (i.returnDate ? `${i.injury ? ', ' : ''}expected back ${shortDate(i.returnDate.slice(0, 10))}` : '')
      : '';
    const body = [detail, i.kind !== 'news' ? i.note : ''].filter(Boolean).map(esc).join('<br>');
    return `<article class="report">
      <div><h3>${title}</h3>${meta1 || i.kind === 'news' ? `<div class="meta">${i.kind === 'news' ? (i.player ? esc(i.player) : 'ESPN') : meta1}</div>` : ''}</div>
      <div style="text-align:right"><span class="status s${i.kind === 'news' ? 1 : severity(i.status)}">${esc(i.status)}</span><div class="when">${esc(relDay(i.date))}</div></div>
      ${body ? `<p>${body}</p>` : ''}
    </article>`;
  };

  app.innerHTML = `
    ${subnav(sport, 'injuries', alerts)}
    ${gamesStrip}
    ${gameId ? '' : `<div class="chips" role="group" aria-label="Which teams">
      ${chip('scope', 'slate', 'Upcoming games')}${chip('scope', 'all', `All ${esc(s.short)}`)}
    </div>`}
    <div class="chips" role="group" aria-label="Type">
      ${chip('kind', 'all', 'Everything')}${chip('kind', 'injury', 'Injuries')}${chip('kind', 'move', 'Roster moves')}${chip('kind', 'news', 'Headlines')}
    </div>
    ${items.length
      ? `<div class="reports">${items.map(row).join('')}</div>`
      : `<p class="note">Nothing here right now. ${gameId ? 'No injuries reported for this game.' : f.scope === 'slate' ? `Try All ${esc(s.short)}.` : 'Check back after the next refresh.'}</p>`}
  `;
  app.querySelectorAll('[data-scope]').forEach((b) => b.addEventListener('click', () => { f.scope = b.dataset.scope; renderInjuries(sport, gameId); }));
  app.querySelectorAll('[data-kind]').forEach((b) => b.addEventListener('click', () => { f.kind = b.dataset.kind; renderInjuries(sport, gameId); }));
}

// ---------- account ----------
const PLANS = {
  free: ['Every player on today’s slate', 'L5 and L10 hit rates', 'Consensus sportsbook line', 'Injury reports and news', 'Last 10 games in each game log'],
  premium: ['Everything in Free', 'L20, head-to-head and season hit rates', 'Compare odds across sportsbooks', 'Full game logs and batter vs pitcher', 'Save props and track them with live hit rates', 'More features on the way'],
};

function renderAccountPage(params) {
  if (!account.ready) {
    app.innerHTML = '<section class="account"><p class="muted">Loading your account…</p></section>';
    return;
  }
  if (!account.enabled) {
    app.innerHTML = `<section class="empty"><h1>Accounts aren’t available yet</h1><p class="muted">${esc(account.error || 'Everything else on the site works without an account.')}</p></section>`;
    document.getElementById('account-link').hidden = true;
    return;
  }
  const next = params.get('next');

  if (account.recovering) {
    app.innerHTML = `<section class="account"><h1>Set a new password</h1>
      <form class="form" id="pw-form"><label>New password<input name="password" type="password" minlength="8" autocomplete="new-password" required></label>
      <button class="btn primary" type="submit">Save new password</button><p class="msg" id="msg" hidden></p></form></section>`;
    wireForm('pw-form', async (d) => {
      const res = await setNewPassword(d.password);
      return res.ok ? { done: true } : res;
    }, () => { location.hash = '#/account'; route(); });
    return;
  }

  if (!account.user) {
    const mode = ui.authMode || 'login';
    const titles = { login: 'Log in', signup: 'Create your account', reset: 'Reset your password' };
    app.innerHTML = `<section class="account">
      <h1>${titles[mode]}</h1>
      ${ui.upgrading ? '<p class="note">Thanks for upgrading. Log in with the email you paid with to see Premium.</p>' : ''}
      ${ui.promo ? `<p class="note">Log in or create a free account to use promo code <b>${esc(ui.promo)}</b>.</p>` : ''}
      <p class="muted">${mode === 'signup' ? 'Free to join. Upgrade to Premium any time.' : mode === 'reset' ? 'We’ll email you a link to set a new password.' : 'Welcome back.'}</p>
      <form class="form" id="auth-form" novalidate>
        <label>Email<input name="email" type="email" autocomplete="email" inputmode="email" required></label>
        ${mode !== 'reset' ? `<label>Password<input name="password" type="password" minlength="8" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" required></label>` : ''}
        <button class="btn primary" type="submit">${mode === 'login' ? 'Log in' : mode === 'signup' ? 'Create account' : 'Send reset link'}</button>
        <p class="msg" id="msg" hidden></p>
        ${mode === 'login' ? '<button class="linkish" type="button" data-mode="reset">Forgot your password?</button>' : ''}
        <button class="linkish" type="button" data-mode="${mode === 'login' ? 'signup' : 'login'}">${mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}</button>
      </form>
    </section>`;
    app.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => { ui.authMode = b.dataset.mode; renderAccountPage(params); }));
    wireForm('auth-form', async (d) => {
      if (!/^\S+@\S+\.\S+$/.test(d.email || '')) return { ok: false, message: 'Enter a valid email address.' };
      if (mode !== 'reset' && (d.password || '').length < 8) return { ok: false, message: 'Use a password with at least 8 characters.' };
      if (mode === 'reset') {
        const res = await sendPasswordReset(d.email);
        return res.ok ? { ok: true, message: 'Check your email for a link to reset your password.' } : res;
      }
      if (mode === 'signup') {
        const res = await signUp(d.email, d.password);
        if (!res.ok) return res;
        return res.needsConfirmation ? { ok: true, message: 'Almost done. Check your email and tap the link to confirm your account.' } : { done: true };
      }
      const res = await signIn(d.email, d.password);
      return res.ok ? { done: true } : res;
    }, () => { location.hash = next || '#/account'; route(); });
    return;
  }

  const premium = isPremium();
  if (premium && ui.upgrading) Object.assign(ui, { upgrading: false, justUpgraded: true });
  const planCard = (key, title, price) => `<div class="plan ${account.plan === key ? 'current' : ''}">
      <h2>${title}${account.plan === key ? '<span class="badge">Your plan</span>' : ''}</h2>
      ${price ? `<p class="price">${esc(price)}</p>` : ''}
      <ul>${PLANS[key].map((f) => `<li>${esc(f)}</li>`).join('')}</ul>
    </div>`;
  const sub = account.subscription || {};
  const until = sub.periodEnd ? new Intl.DateTimeFormat(undefined, { month: 'long', day: 'numeric' }).format(new Date(sub.periodEnd)) : '';
  const longDate = (d) => new Intl.DateTimeFormat(undefined, { month: 'long', day: 'numeric', year: 'numeric' }).format(new Date(d));
  const compLine = account.comp && !account.paid
    ? `<p class="note">${new Date(account.comp.until).getFullYear() >= 2090 ? 'You have complimentary Premium.' : `You have free Premium access until ${esc(longDate(account.comp.until))}${account.comp.note ? ` (${esc(account.comp.note)})` : ''}.`}</p>`
    : '';
  const statusLine = compLine ? compLine : !premium ? ''
    : sub.status === 'past_due' ? '<p class="msg err">Your last payment didn’t go through. Update your card under Manage subscription to keep Premium.</p>'
    : sub.status === 'canceling' ? `<p class="note">Your subscription is canceled and Premium stays on${until ? ` until ${esc(until)}` : ' until the end of this billing period'}.</p>`
    : sub.status === 'trialing' ? `<p class="note">You’re on a free trial${until ? ` until ${esc(until)}` : ''}.</p>`
    : until ? `<p class="muted">Renews ${esc(until)}.</p>` : '';

  let upgrade = '';
  if (!premium && ui.upgrading) {
    upgrade = '<p class="note" id="upgrading">Payment received. Turning on Premium, this takes a few seconds…</p>';
  } else if ((!premium || (account.comp && !account.paid)) && payments.enabled) {
    upgrade = `<div class="upgrade">
      ${account.comp ? '<p class="muted" style="font-size:14px">Subscribe any time to keep Premium after your free access ends.</p>' : ''}
      ${payments.monthly ? `<a class="btn primary" href="${esc(checkoutUrl(payments.monthly))}">Go Premium${payments.monthlyPrice ? `, ${esc(payments.monthlyPrice)}` : ' monthly'}</a>` : ''}
      ${payments.yearly ? `<a class="btn" href="${esc(checkoutUrl(payments.yearly))}">Yearly${payments.yearlyPrice ? `, ${esc(payments.yearlyPrice)}` : ''}</a>` : ''}
      <p class="muted">Secure checkout by Stripe. Cancel any time.</p>
    </div>`;
  } else if (!premium) {
    upgrade = '<p class="note">Premium sign-up opens soon. Already upgraded? <button class="linkish" type="button" id="refresh-plan">Refresh your plan</button></p>';
  }

  const promoForm = account.paid ? '' : `<details class="promo" ${ui.promo ? 'open' : ''}>
      <summary>Have a promo code?</summary>
      <form class="form promo-form" id="promo-form">
        <label class="visually-hidden" for="promo-code">Promo code</label>
        <div class="promo-row"><input id="promo-code" name="code" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Enter code" value="${esc(ui.promo || '')}">
        <button class="btn primary" type="submit">Apply</button></div>
        <p class="msg" id="promo-msg" hidden></p>
      </form>
    </details>`;

  app.innerHTML = `<section class="account">
    <h1>${(ui.justUpgraded || ui.promoWelcome) && premium ? 'You’re Premium' : 'Your account'}</h1>
    <p class="muted">${esc(account.user.email)} <span class="badge ${premium ? '' : 'free'}">${premium ? 'Premium' : 'Free'}</span></p>
    ${statusLine}
    ${upgrade}
    ${promoForm}
    <div class="plans">${planCard('free', 'Free', '')}${planCard('premium', 'Premium', [payments.monthlyPrice, payments.yearlyPrice && `or ${payments.yearlyPrice}`].filter(Boolean).join(' '))}</div>
    <div class="account-actions">
      ${premium ? '<a class="btn" href="#/saved" style="display:inline-flex;align-items:center;text-decoration:none">Saved props</a>' : ''}
      ${premium && portalUrl() ? `<a class="btn" href="${esc(portalUrl())}" style="display:inline-flex;align-items:center;text-decoration:none">Manage subscription</a>` : ''}
      <button class="btn" type="button" id="logout">Log out</button>
      <button class="btn danger" type="button" id="delete-account">Delete account</button>
    </div>
    ${premium && sub.status && !['canceled', 'lifetime'].includes(sub.status) ? '<p class="muted" style="font-size:13px">Deleting your account doesn’t cancel billing. Cancel under Manage subscription first.</p>' : ''}
    <p class="msg err" id="msg" hidden></p>
  </section>`;

  if (!premium && ui.upgrading) waitForPremium();

  document.getElementById('promo-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const msg = document.getElementById('promo-msg');
    const button = form.querySelector('button');
    button.disabled = true;
    const res = await redeemPromo(new FormData(form).get('code'));
    button.disabled = false;
    if (res.ok) {
      ui.promo = '';
      ui.promoWelcome = res.until;
      renderAccountPage(params);
      return;
    }
    msg.textContent = res.message;
    msg.className = 'msg err';
    msg.hidden = false;
  });

  document.getElementById('logout').addEventListener('click', async () => { await signOut(); route(); });
  document.getElementById('refresh-plan')?.addEventListener('click', () => refreshPlan());
  document.getElementById('delete-account').addEventListener('click', async () => {
    if (!confirm('Delete your account and everything saved to it? This can’t be undone.')) return;
    const res = await deleteAccount();
    if (!res.ok) {
      const msg = document.getElementById('msg');
      msg.textContent = res.message;
      msg.hidden = false;
    } else route();
  });
}

/** After Stripe sends people back, poll until the webhook has switched them to Premium. */
let polling = false;
async function waitForPremium() {
  if (polling) return;
  polling = true;
  for (let i = 0; i < 20 && !isPremium(); i++) {
    await new Promise((r) => setTimeout(r, 3000));
    await refreshPlan();
  }
  polling = false;
  if (!isPremium()) {
    ui.upgrading = false;
    const el = document.getElementById('upgrading');
    if (el) el.innerHTML = 'Your payment went through, but Premium hasn’t switched on yet. Refresh this page in a minute. If it still says Free, contact support with the email you paid with.';
  }
}

function wireForm(id, submit, onDone) {
  const form = document.getElementById(id);
  const msg = document.getElementById('msg');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    msg.hidden = true;
    const res = await submit(Object.fromEntries(new FormData(form)));
    button.disabled = false;
    if (res.done) return onDone();
    msg.textContent = res.message || '';
    msg.className = `msg ${res.ok ? '' : 'err'}`;
    msg.hidden = !res.message;
  });
}

// ---------- saved props ----------
async function renderSavedPage() {
  if (!account.ready) {
    app.innerHTML = '<p class="muted">Loading…</p>';
    return;
  }
  if (!account.user || !isPremium()) {
    app.innerHTML = `<section class="empty"><h1>Saved props are a Premium feature</h1>
      <p class="muted">Save any prop from a player page. We score it once the game ends and keep your running record.</p>
      <a class="btn primary" href="#/account" style="display:inline-flex;align-items:center;text-decoration:none;margin-top:12px">${account.user ? 'See plans' : 'Log in'}</a></section>`;
    return;
  }
  if (!account.saved.length) {
    app.innerHTML = `<section class="empty"><h1>No saved props yet</h1>
      <p class="muted">Open any player, set the stat and line you like, and tap Save prop.</p></section>`;
    return;
  }

  const settled = account.saved.filter((s) => s.result === 'hit' || s.result === 'miss');
  const hits = settled.filter((s) => s.result === 'hit').length;
  const pct = settled.length ? Math.round((hits / settled.length) * 100) : null;
  const f = (ui.savedFilter ||= 'all');
  const list = account.saved.filter((s) => (f === 'all' ? true : f === 'open' ? !s.result : Boolean(s.result)));

  const rows = await Promise.all(list.map(async (sv) => {
    if (sv.result) return { sv, live: null };
    let live = null;
    try {
      const slate = await load(`data/${sv.sport}/slate.json`);
      if (slate.games.some((g) => g.id === sv.game_id)) {
        const game = await load(`data/${sv.sport}/games/${sv.game_id}.json`);
        const p = game.players.find((x) => x.id === sv.player_id);
        const idx = p ? p.cols.indexOf(sv.stat) : -1;
        if (idx >= 0) {
          const wins = windowsFor(p, slate.season, p.oppId);
          live = { p, rates: WINDOWS.filter(([w]) => windowOpen(w)).map(([w, label]) => [label, ...rateRows(wins[w], idx, Number(sv.line), sv.side)]) };
        }
      }
    } catch {
      /* sport data missing: show the saved details only */
    }
    return { sv, live };
  }));

  const chip = (value, label) => `<button class="chip" type="button" data-saved="${value}" aria-pressed="${f === value}">${label}</button>`;
  const badge = (sv) => {
    if (!sv.result) return '';
    const label = { hit: 'Hit', miss: 'Miss', push: 'Push', dnp: 'Did not play' }[sv.result];
    return `<span class="result ${sv.result}">${label}${sv.actual !== null && sv.actual !== undefined ? ` ${fmtNum(Number(sv.actual))}` : ''}</span>`;
  };

  app.innerHTML = `<div class="subnav"><h1>Saved props</h1><p class="updated">${account.saved.length} saved</p></div>
    ${settled.length
      ? `<div class="record"><span class="big">${hits}-${settled.length - hits}</span><span class="muted">your record on settled props${pct === null ? '' : `, ${pct}% hits`}</span></div>`
      : '<p class="muted legend">Props are scored automatically the morning after each game.</p>'}
    <div class="chips">${chip('all', 'All')}${chip('open', 'Not settled')}${chip('done', 'Settled')}</div>
    <div class="saved-list">${rows.map(({ sv, live }) => {
      const label = `${sv.side === 'under' ? 'Under' : 'Over'} ${fmtNum(Number(sv.line))} ${sv.stat_label || sv.stat}`;
      const href = `#/${sv.sport}/p/${sv.game_id}/${encodeURIComponent(sv.player_id)}?s=${sv.stat}&l=${sv.line}&side=${sv.side}`;
      const sportName = meta.sports[sv.sport]?.short || sv.sport;
      return `<article class="saved-item ${sv.result || ''}">
        <div>
          <h3>${live ? `<a href="${href}">${esc(sv.player_name)}</a>` : esc(sv.player_name)} ${badge(sv)}</h3>
          <div class="meta">${esc(label)}</div>
          <div class="meta">${esc(sportName)} ${esc(sv.team || '')} vs ${esc(sv.opp || '')}${live?.p.inj ? ` <span class="inj">${esc(live.p.inj)}</span>` : ''}${live || sv.result ? '' : ', waiting to be scored'}</div>
        </div>
        <button class="btn" type="button" data-remove="${sv.id}" aria-label="Remove ${esc(sv.player_name)} ${esc(label)}">Remove</button>
        ${live ? `<div class="rates">${live.rates.map(([l, hits2, n]) => {
          const p2 = pctOf([hits2, n]);
          return `<span style="${heat(p2)}"><small>${l}</small>${p2 === null ? '–' : `${p2}%`}</span>`;
        }).join('')}</div>` : ''}
      </article>`;
    }).join('')}</div>`;

  app.querySelectorAll('[data-saved]').forEach((b) => b.addEventListener('click', () => {
    ui.savedFilter = b.dataset.saved;
    renderSavedPage();
  }));
  app.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    await removeSaved(Number(b.dataset.remove));
  }));
}

// ---------- router ----------
async function route() {
  try {
    if (!meta) [meta, index] = await Promise.all([load('data/meta.json'), load('data/index.json').catch(() => null)]);
  } catch {
    app.innerHTML = `<section class="empty"><h1>No data yet</h1><p class="muted">The daily refresh hasn't produced any files. Run <code>npm run refresh</code> locally, or start the "Refresh slate" workflow in GitHub Actions.</p></section>`;
    return;
  }
  const { parts, params } = parseHash();
  if (parts[0] === 'account' || parts[0] === 'saved') {
    renderHeader(parts[0]);
    return parts[0] === 'account' ? renderAccountPage(params) : renderSavedPage();
  }
  const firstWithGames = meta.order.find((k) => index?.sports?.[k]?.games) || meta.order[0];
  const sport = meta.sports[parts[0]] ? parts[0] : firstWithGames;
  renderHeader(sport);

  try {
    if (parts[1] === 'p' && parts[2] && parts[3]) {
      await renderPlayer(sport, parts[2], parts[3], params);
    } else if (parts[1] === 'injuries') {
      await renderInjuries(sport, parts[2] === 'g' ? parts[3] : undefined);
    } else {
      const gameId = parts[1] === 'g' ? parts[2] : undefined;
      if (ui.sport !== sport) Object.assign(ui, { sport, market: '', q: '', shown: PAGE });
      ui.lastGame = gameId;
      await renderBoard(sport, gameId);
    }
  } catch (err) {
    console.error(err);
    const info = index?.sports?.[sport];
    app.innerHTML = `<section class="empty"><h1>Couldn't load ${esc(meta.sports[sport].short)}</h1>
      <p class="muted">${info?.error ? `The last refresh failed: ${esc(info.error)}` : esc(err.message)}. Try another sport, or rerun the refresh.</p></section>`;
  }
}

let lastPath = '';
window.addEventListener('hashchange', () => {
  const path = location.hash.split('?')[0];
  if (path !== lastPath) window.scrollTo(0, 0);
  lastPath = path;
  route();
});

// Shareable promo links: https://your-site/?promo=CODE opens the account page with the code filled in.
const promoParam = new URLSearchParams(location.search).get('promo');
if (promoParam) {
  ui.promo = promoParam.trim().toUpperCase().slice(0, 40);
  history.replaceState(null, '', `${location.pathname}#/account`);
}

// Stripe sends people back to ?upgraded=1 after checkout.
if (new URLSearchParams(location.search).get('upgraded') === '1') {
  ui.upgrading = true;
  history.replaceState(null, '', `${location.pathname}#/account`);
}

applyTheme();
document.getElementById('theme-toggle')?.addEventListener('click', toggleTheme);

// Screens that depend on who's logged in redraw when that changes.
onAccountChange(() => {
  renderAccountLink();
  if (meta) route();
});
route();
initAccount().then(() => {
  renderAccountLink();
  if (meta) route();
});
