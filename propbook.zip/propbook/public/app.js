// Propbook client. Reads the static JSON written by scripts/refresh.mjs.
import { applyTheme, toggleTheme } from './theme.js';
import {
  account, analyticsToken, checkoutUrl, deleteAccount, myReferrals, premiumDownload, redeemPromo, saveAlertPrefs, unsubscribeWithToken, findSaved, initAccount, isPremium, onAccountChange, payments, portalUrl, refreshPlan, removeSaved,
  saveProp, sendPasswordReset, setNewPassword, signIn, signOut, signUp,
} from './auth.js';

const META_LEN = 7; // [date, season, opp, oppId, homeAway, result, type (R/P), ...values]
const WINDOWS = [
  ['l5', 'L5'],
  ['l10', 'L10'],
  ['l20', 'L20'],
  ['h2h', 'H2H'],
  ['szn', 'Season'],
];
const MAX_RECENT = 40;
const PAGE = 150;

const app = document.getElementById('app');
const cache = new Map();
let meta = null;
let index = null;
const ui = { side: 'over', sort: 'l10', market: '', q: '', shown: PAGE, win: 'l10' };

// ---------- utilities ----------
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtOdds = (p) => (p === null || p === undefined ? '' : p > 0 ? `+${p}` : `${p}`.replace('-', '−'));
const fmtNum = (v) => (v === null || v === undefined ? '–' : Number.isInteger(v) ? String(v) : v.toFixed(1));
const pctOf = ([hits, n]) => (n ? Math.round((hits / n) * 100) : null);

async function load(url) {
  if (cache.has(url)) return cache.get(url);
  const p = fetch(url, { cache: 'no-cache' }).then((r) => {
    if (!r.ok) throw new Error(`${r.status} loading ${url}`);
    return r.json();
  });
  cache.set(url, p);
  p.catch(() => cache.delete(url));
  return p;
}

// Premium accounts read the full data from private storage; everyone else gets
// the public Free-level files. Falls back to public if private storage fails.
const wantsPrivate = (slate) => Boolean(slate?.premium) && account.configured && isPremium();

async function privateOr(publicUrl, privatePath) {
  const key = `private:${privatePath}`;
  if (!cache.has(key)) {
    const p2 = premiumDownload(privatePath);
    cache.set(key, p2);
    p2.catch(() => cache.delete(key));
  }
  try {
    return await cache.get(key);
  } catch {
    return load(publicUrl);
  }
}

async function loadSlate(sport) {
  const slate = await load(`data/${sport}/slate.json`);
  if (!wantsPrivate(slate)) return slate;
  try {
    const { props } = await privateOr(`data/${sport}/slate.json`, `${sport}/props.json`);
    return props ? { ...slate, props } : slate;
  } catch {
    return slate;
  }
}

async function loadMarket(sport, stat, slate) {
  const url = `data/${sport}/markets/${stat}.json`;
  try {
    return wantsPrivate(slate) ? await privateOr(url, `${sport}/markets/${stat}.json`) : await load(url);
  } catch {
    return { props: [] };
  }
}

async function loadGame(sport, gameId, slate) {
  const url = `data/${sport}/games/${gameId}.json`;
  return wantsPrivate(slate) ? privateOr(url, `${sport}/games/${gameId}.json`) : load(url);
}

function parseHash() {
  const [pathPart, query = ''] = location.hash.replace(/^#\/?/, '').split('?');
  const parts = pathPart.split('/').filter(Boolean).map(decodeURIComponent);
  const params = new URLSearchParams(query);
  return { parts, params };
}

function gameLabel(g) {
  return `${g.away.abbr} @ ${g.home.abbr}`;
}
function gameTime(g, multiDay) {
  const d = new Date(g.start);
  if (g.state === 'in') return 'Live';
  const opts = multiDay ? { weekday: 'short', hour: 'numeric', minute: '2-digit' } : { hour: 'numeric', minute: '2-digit' };
  return new Intl.DateTimeFormat(undefined, opts).format(d);
}
// Colour against the break-even the odds demand, not a flat 50%.
function heat(pct, breakeven = 50) {
  if (pct === null) return '';
  const strength = Math.min(60, Math.abs(pct - breakeven) * 1.2);
  const color = pct >= breakeven ? 'var(--hit)' : 'var(--miss)';
  return `background: color-mix(in srgb, ${color} ${strength}%, transparent)`;
}

// ---------- odds math ----------
/** What a price implies you must win to break even, as a percentage. */
export function breakEven(american) {
  if (american === null || american === undefined) return null;
  const pct = american < 0 ? -american / (-american + 100) : 100 / (american + 100);
  return Math.round(pct * 1000) / 10;
}
/** Profit on a $100 bet at American odds. */
export function profitPer100(american) {
  if (american === null || american === undefined) return null;
  return american < 0 ? (100 * 100) / -american : american;
}
/** The book paying most for this side, and how much more it pays than the worst. */
export function bestBookFor(prop, side) {
  const key = side === 'under' ? 'under' : 'over';
  const same = (prop?.books || []).filter((b) => b.line === prop.line && b[key] !== null && b[key] !== undefined);
  if (!same.length) return null;
  const sorted = [...same].sort((a, b) => profitPer100(b[key]) - profitPer100(a[key]));
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];
  return {
    book: best.book,
    price: best[key],
    breakeven: breakEven(best[key]),
    extraPer100: Math.round((profitPer100(best[key]) - profitPer100(worst[key])) * 100) / 100,
    shopped: sorted.length,
  };
}
function photo(p, cls = '') {
  return p.img
    ? `<img class="${cls}" src="${esc(p.img)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'ph'}))">`
    : '<span class="ph"></span>';
}

// ---------- Premium gating ----------
// With accounts connected, L20 / head-to-head / season splits, sportsbook comparison,
// batter-vs-pitcher and full game logs are Premium. Without accounts, everything shows.
const FREE_WINDOWS = new Set(['l5', 'l10']);
const unlocked = () => !account.configured || isPremium();
const windowOpen = (w) => unlocked() || FREE_WINDOWS.has(w);
const LOCK = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const lockPill = (text = 'Premium') => `<a class="lock-pill" href="#/account">${LOCK} ${text}</a>`;

// ---------- hit rates (mirrors scripts/lib/common.mjs) ----------
function windowsFor(player, season, oppId) {
  const recent = player.rows.slice(0, MAX_RECENT);
  return {
    l5: recent.slice(0, 5),
    l10: recent.slice(0, 10),
    l20: recent.slice(0, 20),
    h2h: player.rows.filter((r) => r[3] === String(oppId)),
    szn: recent.filter((r) => r[1] === season),
  };
}
function rateRows(rows, idx, line, side) {
  const vals = rows.map((r) => r[META_LEN + idx]).filter((v) => v !== null);
  const hits = vals.filter((v) => (side === 'under' ? v < line : v > line)).length;
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  return [hits, vals.length, avg];
}

// ---------- header ----------
function renderHeader(sport) {
  const nav = document.getElementById('sports');
  nav.innerHTML =
    meta.order
      .map((key) => {
        const s = meta.sports[key];
        const info = index?.sports?.[key];
        const count = info && !info.error ? `<span class="count">${info.games}</span>` : '';
        return `<a href="#/${key}" ${key === sport ? 'aria-current="page"' : ''}>${esc(s.short)}${count}</a>`;
      })
      .join('') +
    (isPremium() ? `<a class="saved-link" href="#/saved" ${sport === 'saved' ? 'aria-current="page"' : ''}>Saved</a>` : '');
  renderAccountLink();
  renderTabbar(sport);
}

const TAB_ICONS = {
  props: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/></svg>',
  injuries: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 7v10M7 12h10"/></svg>',
  saved: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4.5L6 21z"/></svg>',
  account: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/></svg>',
};

function currentTab() {
  const { parts } = parseHash();
  if (parts[0] === 'saved') return 'saved';
  if (parts[0] === 'account') return 'account';
  return parts[1] === 'injuries' ? 'injuries' : 'props';
}

/** Phone-sized navigation, pinned to the bottom where thumbs are. */
function renderTabbar(sport) {
  const bar = document.getElementById('tabbar');
  if (!bar) return;
  const key = meta.sports[sport] ? sport : meta.order[0];
  const active = currentTab();
  const tabs = [
    ['props', 'Props', `#/${key}`],
    ['injuries', 'Injuries', `#/${key}/injuries`],
    ...(account.enabled ? [['saved', 'Saved', '#/saved'], ['account', account.user ? 'Account' : 'Log in', '#/account']] : []),
  ];
  bar.innerHTML = tabs
    .map(([id, label, href]) => `<a href="${href}" ${id === active ? 'aria-current="page"' : ''}>${TAB_ICONS[id]}<span>${esc(label)}</span></a>`)
    .join('');
}

function renderAccountLink() {
  const link = document.getElementById('account-link');
  if (!link) return;
  link.hidden = !account.enabled;
  if (!account.enabled) return;
  link.innerHTML = account.user
    ? `<span class="label">Account</span> <span class="badge ${isPremium() ? '' : 'free'}">${isPremium() ? 'Premium' : 'Free'}</span>`
    : 'Log in';
}

function updatedText(sport) {
  const info = index?.sports?.[sport];
  if (!info?.generatedAt) return '';
  const hours = (Date.now() - Date.parse(info.generatedAt)) / 3600e3;
  const when = new Intl.DateTimeFormat(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' }).format(new Date(info.generatedAt));
  return hours > 36 ? `Stale, last updated ${when}` : `Updated ${when}`;
}

/** Props / Injuries & news tabs shown at the top of each sport. */
function subnav(sport, active, alerts = 0) {
  return `<div class="subnav">
    <nav class="tabs" aria-label="${esc(meta.sports[sport].short)} sections">
      <a href="#/${sport}" ${active === 'props' ? 'aria-current="page"' : ''}>Props</a>
      <a href="#/${sport}/injuries" ${active === 'injuries' ? 'aria-current="page"' : ''}>Injuries &amp; news${alerts ? `<span class="dot" aria-label="${alerts} players out">${alerts}</span>` : ''}</a>
    </nav>
    <p class="updated ${updatedText(sport).startsWith('Stale') ? 'stale' : ''}">${esc(updatedText(sport))}</p>
  </div>`;
}

/** 3 = out or off the roster, 2 = uncertain, 1 = informational (mirrors scripts/lib/news.mjs). */
function severity(status = '') {
  const s = status.toLowerCase();
  if (/out|injured reserve|injured list|suspend|retire|waive|releas|dfa|season/.test(s)) return 3;
  if (/doubt|question|day-to-day|game-time|probable|illness|personal/.test(s)) return 2;
  return 1;
}

/** Injury and roster-move items that affect one game, worst first. */
function itemsForGame(report, gameId, players = []) {
  if (!report || !gameId) return [];
  const ids = new Set(players.filter((p) => p.gameId === gameId).map((p) => String(p.id)));
  return (report.items || [])
    .filter((i) => i.kind !== 'news' && (i.gameId === gameId || (i.pid && ids.has(String(i.pid)))))
    .sort((a, b) => severity(b.status) - severity(a.status) || (Date.parse(b.date) || 0) - (Date.parse(a.date) || 0));
}

async function outCount(sport) {
  try {
    const report = await load(`data/${sport}/injuries.json`);
    return new Set(report.items.filter((i) => i.pid && i.kind !== 'news' && severity(i.status) === 3).map((i) => i.pid)).size;
  } catch {
    return 0;
  }
}

// ---------- board ----------
async function renderBoard(sport, gameId) {
  const slate = await loadSlate(sport);
  const s = meta.sports[sport];
  const multiDay = slate.from !== slate.until;
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  const players = new Map(slate.players.map((p) => [p.id, p]));
  const gamesById = new Map(slate.games.map((g) => [g.id, g]));

  const alerts = await outCount(sport);
  if (!slate.games.length) {
    app.innerHTML = `${subnav(sport, 'props', alerts)}<section class="empty"><h1>No ${esc(s.short)} games coming up</h1>
      <p class="muted">Nothing is on the schedule ${multiDay ? 'this week' : 'today'}. The slate rebuilds every morning, so check back tomorrow or pick another sport.</p></section>`;
    return;
  }

  const report = await load(`data/${sport}/injuries.json`).catch(() => null);
  const gameItems = itemsForGame(report, gameId, slate.players).slice(0, 8);
  const gameInjuries = gameId && gameItems.length
    ? `<section class="game-injuries">
        <h2>Injuries in this game</h2>
        <ul>${gameItems.map((i) => `<li>
          <span class="status s${severity(i.status)}">${esc(i.status)}</span>
          ${i.pid && i.gameId ? `<a href="#/${sport}/p/${esc(i.gameId)}/${encodeURIComponent(i.pid)}">${esc(i.player)}</a>` : `<b>${esc(i.player || i.teamName || i.team)}</b>`}
          <span class="muted">${esc([i.pos, i.team].filter(Boolean).join(' '))}${i.injury ? `, ${esc(i.injury)}` : ''}</span>
        </li>`).join('')}</ul>
        <a class="more-link" href="#/${sport}/injuries/g/${gameId}">Full report for this game</a>
      </section>`
    : '';

  const strip = `${subnav(sport, 'props', alerts)}<nav class="games" aria-label="Games">
      <a class="game" href="#/${sport}" aria-current="${!gameId}"><strong>All games</strong><span>${slate.games.length} on the slate</span></a>
      ${slate.games
        .map(
          (g) => `<a class="game" href="#/${sport}/g/${g.id}" aria-current="${g.id === gameId}">
            <strong>${esc(gameLabel(g))}</strong><span>${esc(gameTime(g, multiDay))}</span></a>`,
        )
        .join('')}
    </nav>`;

  // Lines are optional. Stats are not: if this game has none, or the person asked
  // for all players, show the roster with their recent averages instead.
  const scopedProps = slate.props.filter((pr) => !gameId || pr.gameId === gameId);
  const allMarkets = Object.keys(slate.marketStats || {});
  if ((!scopedProps.length && !(ui.market && allMarkets.includes(ui.market))) || ui.view === 'players') {
    renderRoster(slate, s, gameId, strip, players, gamesById, sport, scopedProps.length > 0);
    return;
  }

  const bookMarkets = [...new Set(scopedProps.map((p) => p.stat))];
  const markets = [...bookMarkets, ...allMarkets.filter((m) => !bookMarkets.includes(m))];

  // Picking one market pulls in every player who records it, book line or not.
  let pool = scopedProps;
  if (ui.market && allMarkets.includes(ui.market)) {
    const extra = (await loadMarket(sport, ui.market, slate)).props || [];
    pool = [...scopedProps, ...extra.filter((x) => !gameId || x.gameId === gameId)];
  }
  const q = ui.q.trim().toLowerCase();
  if (!windowOpen(ui.sort)) ui.sort = 'l10';
  const sortKey = ui.sort;

  let rows = pool
    .filter((pr) => !ui.market || pr.stat === ui.market)
    .map((pr) => {
      const p = players.get(pr.pid);
      if (!p) return null;
      const rates = {};
      for (const [w] of WINDOWS) {
        const [hits, n, avg] = pr.hr?.[w] || [0, 0, null];
        const h = ui.side === 'under' ? n - hits - pushes(pr, w) : hits;
        rates[w] = { hits: h, n, avg, pct: n ? Math.round((h / n) * 100) : null };
      }
      return { pr, p, rates };
    })
    .filter((r) => r && (!q || r.p.name.toLowerCase().includes(q) || r.p.team.toLowerCase() === q));

  rows.sort((a, b) => {
    if (sortKey === 'edge') {
      const ea = ((a.rates.l10.avg ?? a.pr.line) - a.pr.line) * (ui.side === 'under' ? -1 : 1);
      const eb = ((b.rates.l10.avg ?? b.pr.line) - b.pr.line) * (ui.side === 'under' ? -1 : 1);
      return eb - ea;
    }
    const pa = a.rates[sortKey].pct ?? -1;
    const pb = b.rates[sortKey].pct ?? -1;
    return pb - pa || b.rates[sortKey].n - a.rates[sortKey].n;
  });

  // One card per player, their markets stacked inside, best first.
  const cards = [];
  const byPlayer = new Map();
  for (const row of rows) {
    if (!byPlayer.has(row.p.id)) {
      byPlayer.set(row.p.id, { p: row.p, markets: [] });
      cards.push(byPlayer.get(row.p.id));
    }
    byPlayer.get(row.p.id).markets.push(row);
  }
  const totalPlayers = cards.length;
  const shown = cards.slice(0, ui.shown);
  const openWindows = WINDOWS.filter(([w]) => windowOpen(w));

  app.innerHTML = `
    ${strip}
    ${gameInjuries}
    <div class="toolbar">
      <label class="visually-hidden" for="q">Search players</label>
      <input id="q" type="search" placeholder="Search player or team" value="${esc(ui.q)}" autocomplete="off">
      <label class="visually-hidden" for="sort">Sort by</label>
      <select id="sort">
        ${[...WINDOWS, ['edge', 'L10 avg']].map(([k, l]) => `<option value="${k}" ${k === sortKey ? 'selected' : ''} ${k !== 'edge' && !windowOpen(k) ? 'disabled' : ''}>Sort: ${k === 'edge' ? 'avg vs line' : `${l} hit %`}${k !== 'edge' && !windowOpen(k) ? ' (Premium)' : ''}</option>`).join('')}
      </select>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${ui.side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${ui.side === 'under'}">Under</button>
      </div>
      ${viewToggle('lines')}
    </div>
    <div class="chips markets" role="group" aria-label="Market">
      <button class="chip" type="button" data-market="" aria-pressed="${!ui.market}">All markets</button>
      ${markets.map((m) => `<button class="chip ${bookMarkets.includes(m) ? '' : 'no-book'}" type="button" data-market="${m}" aria-pressed="${ui.market === m}">${esc(statLabel[m] || m)}</button>`).join('')}
    </div>
    ${unlocked() ? '<p class="muted legend">Shading compares each hit rate with the win rate the price needs. Grey means fewer than 5 games.</p>' : `<p class="note upsell">L20, head-to-head, season hit rates and sportsbook odds comparison are part of Premium. ${lockPill('See Premium')}</p>`}
    ${totalPlayers ? '' : '<p class="note">No lines match. Clear the search or pick another market.</p>'}
    <div class="plist">
      ${shown.map(({ p, markets: list }) => {
        const g = gamesById.get(p.gameId);
        return `<article class="pcard">
          <header>
            ${photo(p)}
            <div class="who-text">
              <b>${esc(p.name)}</b>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}
              <small>${esc(p.pos)} ${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}${g ? `, ${esc(gameTime(g, multiDay))}` : ''}</small>
            </div>
          </header>
          ${list.map(({ pr, rates }) => {
            const bb = unlocked() ? bestBookFor(pr, ui.side) : null;
            const be = bb?.breakeven ?? 50;
            const href = `#/${sport}/p/${pr.gameId}/${encodeURIComponent(p.id)}?s=${pr.stat}&l=${pr.line}&side=${ui.side}`;
            return `<a class="prow" href="${href}">
              <span class="m">${esc(statLabel[pr.stat] || pr.stat)}</span>
              <span class="ln">${ui.side === 'over' ? 'O' : 'U'} ${fmtNum(pr.line)}${pr.est ? '<small>his avg, no book line</small>' : bb ? `<small>${esc(fmtOdds(bb.price))} ${esc(bb.book)}${bb.extraPer100 >= 1 ? ` <span class="edge-tag">+$${bb.extraPer100.toFixed(0)}</span>` : ''}</small>` : ''}</span>
              <span class="rates">${openWindows.map(([w, label]) => {
                const r = rates[w];
                const thin = r.n > 0 && r.n < 5;
                return `<i class="${thin ? 'thin' : ''}" style="${thin ? '' : heat(r.pct, be)}"><em>${label}</em>${r.pct === null ? '–' : `${r.pct}%`}</i>`;
              }).join('')}${unlocked() ? '' : `<i class="locked">${LOCK}</i>`}</span>
            </a>`;
          }).join('')}
        </article>`;
      }).join('')}
    </div>
    ${totalPlayers > shown.length ? `<button class="btn more" id="more">Show ${Math.min(PAGE, totalPlayers - shown.length)} more of ${totalPlayers - shown.length} players</button>` : ''}
    ${slate.oddsNote ? `<p class="note">${esc(slate.oddsNote)}</p>` : ''}
  `;

  const q$ = document.getElementById('q');
  q$.addEventListener('input', () => {
    ui.q = q$.value;
    ui.shown = PAGE;
    const pos = q$.selectionStart;
    renderBoard(sport, gameId).then(() => {
      const el = document.getElementById('q');
      el.focus();
      el.setSelectionRange(pos, pos);
    });
  });
  app.querySelectorAll('[data-market]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.market = b.dataset.market;
      ui.shown = PAGE;
      renderBoard(sport, gameId);
    }),
  );
  document.getElementById('sort').addEventListener('change', (e) => {
    ui.sort = e.target.value;
    renderBoard(sport, gameId);
  });
  app.querySelectorAll('[data-side]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.side = b.dataset.side;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('[data-view]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.view = b.dataset.view;
      renderBoard(sport, gameId);
    }),
  );
  document.getElementById('more')?.addEventListener('click', () => {
    ui.shown += PAGE;
    renderBoard(sport, gameId);
  });
}

// Precomputed rates count over hits; under hits exclude games that landed exactly on the line.
function pushes(pr, w) {
  return pr.hr?.[w]?.[3] ?? 0;
}

function bestPrice(pr, side) {
  const key = side === 'under' ? 'under' : 'over';
  const same = pr.books.filter((b) => b.line === pr.line && b[key] !== null);
  if (!same.length) return '';
  const best = same.reduce((a, b) => (b[key] > a[key] ? b : a));
  return `${fmtOdds(best[key])} ${best.book}`;
}

/** Switch between props with sportsbook lines and every player's stats. */
function viewToggle(current) {
  return `<div class="seg" role="group" aria-label="What to show">
    <button data-view="lines" aria-pressed="${current === 'lines'}">With lines</button>
    <button data-view="players" aria-pressed="${current === 'players'}">All players</button>
  </div>`;
}

function renderRoster(slate, s, gameId, strip, players, gamesById, sport, hasLines = false) {
  const list = slate.players.filter((p) => !gameId || p.gameId === gameId);
  const byTeam = new Map();
  for (const p of list) {
    const k = `${p.gameId}|${p.team}`;
    if (!byTeam.has(k)) byTeam.set(k, []);
    byTeam.get(k).push(p);
  }
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  app.innerHTML = `
    ${strip}
    <div class="toolbar">${hasLines ? viewToggle('players') : ''}</div>
    ${Object.keys(slate.marketStats || {}).length ? `<div class="chips markets" role="group" aria-label="Market">
      ${Object.keys(slate.marketStats).map((m) => `<button class="chip no-book" type="button" data-market="${m}" aria-pressed="false">${esc(s.stats.find((x) => x.key === m)?.label || m)}</button>`).join('')}
    </div>` : ''}
    <p class="note">${hasLines
      ? 'Every player in this view, with last-10-game averages. Open one to set your own line.'
      : `No sportsbook lines for ${gameId ? 'this game' : 'these games'} yet${slate.oddsNote ? ` (${esc(slate.oddsNote)})` : ''}. Stats still work: numbers are last-10-game averages, and you can set your own line on any player.`}</p>
    ${[...byTeam.entries()]
      .map(([k, ps]) => {
        const [gid, team] = k.split('|');
        const g = gamesById.get(gid);
        ps.sort((a, b) => b.gp - a.gp);
        return `<div class="team-head"><h2>${esc(team)}</h2><span class="muted">${g ? esc(gameLabel(g)) : ''}</span></div>
          <div class="roster">${ps
            .map(
              (p) => `<a href="#/${sport}/p/${p.gameId}/${encodeURIComponent(p.id)}">
                <div class="who">${photo(p)}<div><b>${esc(p.name)}</b>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}<small>${esc(p.pos)}</small></div></div>
                <div class="avgs">${Object.entries(p.avg)
                  .map(([k2, v]) => `<div><b>${fmtNum(v)}</b><span>${esc(shortLabel(statLabel[k2] || k2))}</span></div>`)
                  .join('')}</div></a>`,
            )
            .join('')}</div>`;
      })
      .join('')}`;
  app.querySelectorAll('[data-view]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.view = b.dataset.view;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('[data-market]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.market = b.dataset.market;
      ui.view = 'lines';
      ui.shown = PAGE;
      renderBoard(sport, gameId);
    }),
  );
}
const shortLabel = (label) => label.replace('Passing yards', 'Pass yds').replace('Rushing yards', 'Rush yds').replace('Receiving yards', 'Rec yds').replace('Total bases', 'TB').replace('Hits + Runs + RBIs', 'H+R+RBI');

// ---------- player ----------
async function renderPlayer(sport, gameId, pid, params) {
  const slate = await loadSlate(sport);
  let game;
  try {
    game = await loadGame(sport, gameId, slate);
  } catch {
    // The slate moved on since this page was opened (game started, or data is mid-update).
    app.innerHTML = `<a class="back" href="#/${sport}">← Back to ${esc(meta.sports[sport].short)} board</a>
      <section class="empty"><h1>This game is updating</h1>
      <p class="muted">Its data is being rebuilt or the game has already started. Go back to the board and pick it again in a minute.</p></section>`;
    return;
  }
  const s = meta.sports[sport];
  const p = game.players.find((x) => x.id === pid);
  const back = `<a class="back" href="#/${sport}${ui.lastGame ? `/g/${ui.lastGame}` : ''}">← Back to ${esc(s.short)} board</a>`;
  if (!p) {
    app.innerHTML = `${back}<section class="empty"><h1>Player not on this slate</h1><p class="muted">The slate has been rebuilt since this link was made. Go back to the board to find them.</p></section>`;
    return;
  }
  const g = slate.games.find((x) => x.id === gameId);
  const statDefs = s.stats.filter((x) => p.cols.includes(x.key));
  const props = slate.props.filter((x) => x.pid === pid);
  const stat = p.cols.includes(params.get('s')) ? params.get('s') : props[0]?.stat || (s.headline[p.role] || s.headline.all || [p.cols[0]])[0];
  const idx = p.cols.indexOf(stat);
  const prop = props.find((x) => x.stat === stat);
  const side = params.get('side') === 'under' ? 'under' : 'over';

  // Splits: same venue type as tonight's game, and recent form only.
  const f = (ui.filters ||= { loc: 'all', recent: false, rest: 'all', result: 'all', opp: 'all', season: 'all', stype: 'all', mate: '', mateMode: 'without' });
  if (f.loc === true || f.loc === false) f.loc = 'all';

  // Teammates: anyone else on his team in this game file, with enough games to compare.
  const teammates = game.players
    .filter((t) => t.team === p.team && t.id !== p.id && t.rows.length >= 3)
    .sort((a, b) => b.rows.length - a.rows.length || a.name.localeCompare(b.name));
  if (f.mate && !teammates.some((t) => t.id === f.mate)) f.mate = '';
  const mate = teammates.find((t) => t.id === f.mate) || null;
  const mateDates = mate ? new Set(mate.rows.map((r) => r[0])) : null;
  const wantHA = p.home ? 'vs' : '@';
  const cutoff = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);

  // Days of rest before each game, worked out from the log itself.
  const restBefore = new Map();
  const byDate = [...p.rows].sort((a, b) => (a[0] < b[0] ? -1 : 1));
  byDate.forEach((r, i) => {
    if (i === 0) return;
    restBefore.set(r, Math.round((Date.parse(r[0]) - Date.parse(byDate[i - 1][0])) / 864e5));
  });

  // How tough each past opponent is against this stat, from the league ranks.
  const defRanks = await loadDefenseRanks(sport, p, stat);
  const toughness = (r) => defRanks?.get(String(r[3])) ?? null;

  const usageList = usageOptions(sport, p);
  if (!usageList.some((u) => u.key === f.usageKey)) {
    f.usageKey = usageList[0]?.key || null;
    f.usageMin = null;
  }
  const usage = usageList.find((u) => u.key === f.usageKey) || null;
  const usageIdx = usage ? p.cols.indexOf(usage.key) : -1;
  const usageMedian = usage ? median(p.rows.map((r) => r[META_LEN + usageIdx]).filter((v) => v !== null && v > 0)) : 0;

  const keep = (r) => {
    if (f.loc !== 'all' && r[4] !== f.loc) return false;
    if (f.stype !== 'all' && r[6] !== f.stype) return false;
    if (mateDates) {
      const together = mateDates.has(r[0]);
      if (f.mateMode === 'with' && !together) return false;
      if (f.mateMode === 'without' && together) return false;
    }
    if (f.recent && r[0] < cutoff) return false;
    if (f.season === 'cur' && r[1] !== slate.season) return false;
    if (f.season === 'prev' && r[1] === slate.season) return false;
    if (f.result !== 'all' && r[5] !== f.result) return false;
    if (f.rest !== 'all') {
      const rest = restBefore.get(r);
      if (rest === undefined) return false;
      if (f.rest === 'b2b' && rest > 1) return false;
      if (f.rest === 'rested' && rest < 3) return false;
    }
    if (usage && f.usageMin !== null && f.usageMin !== undefined) {
      const v = r[META_LEN + usageIdx];
      if (v === null || v === undefined || v < f.usageMin) return false;
    }
    if (f.opp !== 'all') {
      const rank = toughness(r);
      if (rank === null) return false;
      if (f.opp === 'easy' && rank.rank > rank.of / 3) return false; // allows the most
      if (f.opp === 'tough' && rank.rank <= (rank.of * 2) / 3) return false;
    }
    return true;
  };

  const filtered = { ...p, rows: p.rows.filter(keep) };
  f.mateName = mate?.name || '';
  const moreCount = ['rest', 'result', 'opp', 'season', 'stype'].filter((k) => f[k] !== 'all').length + (mate ? 1 : 0);
  const wins = windowsFor(filtered, slate.season, p.oppId);
  const activeFilters =
    ['loc', 'recent', 'rest', 'result', 'opp', 'season', 'stype'].filter((k) => f[k] && f[k] !== 'all').length +
    (mate ? 1 : 0) +
    (usage && f.usageMin !== null && f.usageMin !== undefined ? 1 : 0);
  const filtering = activeFilters > 0;

  let line = Number(params.get('l'));
  if (!params.has('l') || Number.isNaN(line)) {
    if (prop) line = prop.line;
    else {
      const avg = rateRows(wins.l10, idx, 0, 'over')[2];
      line = avg === null ? 0.5 : Math.max(0.5, Math.round(avg) - 0.5);
    }
  }
  const tab = ui.playerTab && ['overview', 'log', 'matchup'].includes(ui.playerTab) ? ui.playerTab : 'overview';
  if (!windowOpen(ui.win)) ui.win = 'l10';
  const win = ui.win;

  const setParams = (changes) => {
    const next = new URLSearchParams({ s: stat, l: String(line), side, ...changes });
    history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
    renderPlayer(sport, gameId, pid, next);
  };

  const bb = unlocked() ? bestBookFor(prop, side) : null;
  const priced = bb && prop && prop.line === line;
  const be = priced ? bb.breakeven : 50;

  const tiles = WINDOWS.map(([w, label]) => {
    if (!windowOpen(w)) {
      return `<a class="tile locked" href="#/account" aria-label="${label} hit rate is a Premium stat">
        <span class="w">${label}</span><span class="pct">${LOCK}</span><span class="sub">Premium</span></a>`;
    }
    const [hits, n, avg] = rateRows(wins[w], idx, line, side);
    const pct = pctOf([hits, n]);
    const thin = n > 0 && n < 5;
    const cls = pct === null || thin ? '' : pct >= be + 8 ? 'good' : pct < be - 8 ? 'bad' : '';
    return `<button class="tile ${cls} ${thin ? 'thin' : ''}" data-win="${w}" aria-pressed="${w === win}">
      <span class="w">${label}</span><span class="pct">${pct === null ? '–' : `${pct}%`}</span>
      <span class="sub">${n ? `${hits} of ${n}` : 'No games'}${thin ? ', small sample' : ''}</span><span class="sub">${avg === null ? '' : `avg ${fmtNum(Math.round(avg * 10) / 10)}`}</span>
    </button>`;
  }).join('');

  const chartRows = [...wins[win]].reverse().filter((r) => r[META_LEN + idx] !== null);
  const statLabel = statDefs.find((x) => x.key === stat)?.label || stat;

  const cols = (s.logCols[p.role] || s.logCols.all || p.cols).filter((c) => p.cols.includes(c));
  if (!cols.includes(stat)) cols.unshift(stat);
  const labelFor = (k) => abbrev(k, s.stats);

  const savedProp = {
    sport, game_id: gameId, player_id: pid, player_name: p.name, team: p.team, opp: p.opp,
    stat, stat_label: statLabel, line, side, game_start: g?.start || null,
  };

  app.innerHTML = `
    ${back}
    <header class="player-head">
      ${photo(p)}
      <div>
        <h1>${esc(p.name)}${p.inj ? ` <span class="inj">${esc(p.inj)}</span>` : ''}</h1>
        <p><span>${esc(p.pos)}</span> <span class="matchup">${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}</span>
        ${g ? `<span>${esc(gameTime(g, slate.from !== slate.until))}</span>` : ''}</p>
      </div>
    </header>
    ${injuryBanner(p)}

    <div class="stat-tabs" role="group" aria-label="Stat">
      ${statDefs
        .map((d) => `<button data-stat="${d.key}" aria-pressed="${d.key === stat}" class="${props.some((x) => x.stat === d.key) ? 'has-line' : ''}">${esc(d.label)}</button>`)
        .join('')}
    </div>

    <nav class="chips ptabs" role="group" aria-label="Sections">
      <button class="chip" type="button" data-ptab="overview" aria-pressed="${tab === 'overview'}">Overview</button>
      <button class="chip" type="button" data-ptab="log" aria-pressed="${tab === 'log'}">Game log</button>
      ${p.matchup || p.hasMatchup ? `<button class="chip" type="button" data-ptab="matchup" aria-pressed="${tab === 'matchup'}">Matchup</button>` : ''}
    </nav>

    <div class="line-row">
      <div class="line-ctl">
        <button data-step="-0.5" aria-label="Lower line">−</button>
        <label><span>${esc(statLabel)}</span><input id="line" type="number" inputmode="decimal" step="0.5" min="0" value="${line}"></label>
        <button data-step="0.5" aria-label="Raise line">+</button>
      </div>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${side === 'under'}">Under</button>
      </div>
      ${bb && priced ? `<span class="best-price">Best ${esc(fmtOdds(bb.price))} at ${esc(bb.book)}</span>` : ''}
      ${
        prop && !unlocked()
          ? `<div class="books"><button class="book" data-line="${prop.line}" aria-pressed="${prop.line === line}"><b>Line ${fmtNum(prop.line)}</b><span>Consensus</span></button>${lockPill(`Compare ${prop.books.length} sportsbook${prop.books.length === 1 ? '' : 's'}`)}</div>`
          : prop
          ? `<details class="books-wrap"><summary>Compare ${prop.books.length} book${prop.books.length === 1 ? '' : 's'}</summary><div class="books">${prop.books
              .map(
                (b) => `<button class="book" data-line="${b.line}" aria-pressed="${b.line === line}">
                  <b>${esc(b.book)} ${fmtNum(b.line)}</b><span>O ${fmtOdds(b.over) || '–'} U ${fmtOdds(b.under) || '–'}</span></button>`,
              )
              .join('')}</div></details>`
          : '<span class="muted">No sportsbook line for this stat. Set your own.</span>'
      }
    </div>

    ${saveControl(savedProp)}

    <div ${tab === 'overview' ? '' : 'hidden'}>
    ${priced ? `<p class="breakeven">At ${esc(fmtOdds(bb.price))} (${esc(bb.book)}) you need <b>${bb.breakeven}%</b> to break even.${bb.extraPer100 >= 1 ? ` That's $${bb.extraPer100.toFixed(0)} more per $100 than the worst of the ${bb.shopped} books.` : ''}</p>` : ''}
    <div class="tiles">${tiles}</div>
    <div class="chips splits" role="group" aria-label="Filter games">
      <button class="chip" type="button" data-loc="all" aria-pressed="${f.loc === 'all'}">All</button>
      <button class="chip" type="button" data-loc="vs" aria-pressed="${f.loc === 'vs'}">Home${p.home ? ' (tonight)' : ''}</button>
      <button class="chip" type="button" data-loc="@" aria-pressed="${f.loc === '@'}">Away${p.home ? '' : ' (tonight)'}</button>
      <button class="chip" type="button" data-recent="1" aria-pressed="${f.recent}">Last 30 days</button>
    </div>
    <details class="more-filters" id="more-filters" ${moreCount || ui.moreOpen ? 'open' : ''}>
      <summary>More filters${moreCount ? ` (${moreCount})` : ''}</summary>
      <div class="filter-grid">
        ${filterRow('Rest', 'rest', [['all', 'Any'], ['b2b', 'Back to back'], ['rested', '3+ days']], f)}
        ${filterRow('Result', 'result', [['all', 'Any'], ['W', 'Wins'], ['L', 'Losses']], f)}
        ${filterRow('Season', 'season', [['all', 'All'], ['cur', 'This season'], ['prev', 'Earlier seasons']], f)}
        ${p.rows.some((r) => r[6] === 'P') ? filterRow('Game type', 'stype', [['all', 'All'], ['R', 'Regular season'], ['P', 'Playoffs']], f) : ''}
        ${teammates.length ? `<div class="filter-row"><span>Teammate</span>
          <div class="mate-pick">
            <select id="mate" aria-label="Teammate">
              <option value="">Anyone</option>
              ${teammates.map((t) => `<option value="${esc(t.id)}" ${t.id === f.mate ? 'selected' : ''}>${esc(t.name)}${t.pos ? ` (${esc(t.pos)})` : ''}${t.inj ? `, ${esc(t.inj)}` : ''}</option>`).join('')}
            </select>
            <div class="seg" role="group" aria-label="With or without">
              <button type="button" data-mate-mode="with" aria-pressed="${f.mateMode === 'with'}" ${mate ? '' : 'disabled'}>With</button>
              <button type="button" data-mate-mode="without" aria-pressed="${f.mateMode === 'without'}" ${mate ? '' : 'disabled'}>Without</button>
            </div>
          </div></div>` : ''}
        ${defRanks ? filterRow('Opponent', 'opp', [['all', 'Any'], ['easy', 'Soft defenses'], ['tough', 'Tough defenses']], f) : ''}
      </div>
      ${activeFilters ? '<button class="linkish" type="button" id="clear-filters">Clear all filters</button>' : ''}
    </details>

    ${usage ? `<div class="usage">
      <span class="usage-label">At least</span>
      ${usageList.length > 1 ? `<select id="usage-key" aria-label="Playing time measure">${usageList.map((u) => `<option value="${u.key}" ${u.key === usage.key ? 'selected' : ''}>${esc(u.label)}</option>`).join('')}</select>` : `<b>${esc(usage.label)}</b>`}
      <div class="stepper" role="group" aria-label="${esc(usage.label)} minimum">
        <button type="button" data-usage-step="-1" aria-label="Lower">−</button>
        <output>${f.usageMin === null || f.usageMin === undefined ? 'Any' : `${fmtNum(f.usageMin)}${usage.unit}`}</output>
        <button type="button" data-usage-step="1" aria-label="Raise">+</button>
      </div>
      ${f.usageMin !== null && f.usageMin !== undefined ? '<button class="linkish" type="button" id="usage-clear">Any</button>' : `<span class="muted usage-hint">typical ${fmtNum(Math.round(usageMedian))}${usage.unit}</span>`}
    </div>` : ''}
    ${filtering ? `<p class="muted legend">${filtered.rows.length} of ${p.rows.length} games match: ${esc(filterSummary(f, p))}.</p>` : ''}
    <figure class="chart" style="margin:0">
      <figcaption class="caption"><span>${esc(statLabel)}, ${WINDOWS.find((w) => w[0] === win)[1]} ${win === 'h2h' ? `vs ${esc(p.opp)}` : 'games'}</span>
        <span class="muted">${side === 'over' ? 'Over' : 'Under'} ${fmtNum(line)}</span></figcaption>
      ${chartRows.length > 5 ? `<p class="trend-note">${esc(trendText(chartRows, idx))}</p>` : ''}
      <div class="chips chart-opts" role="group" aria-label="Chart lines">
        <button class="chip" type="button" data-chart="showAverage" aria-pressed="${ui.showAverage !== false}">Average line</button>
        <button class="chip" type="button" data-chart="showTrend" aria-pressed="${ui.showTrend !== false}">3-game trend</button>
      </div>
      ${chartRows.length ? barChart(chartRows, idx, line, side, { showAverage: ui.showAverage !== false, showTrend: ui.showTrend !== false, usageIdx: usage ? usageIdx : -1, usageUnit: usage?.unit || '' }) : `<p class="muted" style="padding:0 8px">No ${win === 'h2h' ? `games against ${esc(p.opp)}` : 'games'} in the last two seasons.</p>`}
    </figure>

    </div>
    <div ${tab === 'matchup' ? '' : 'hidden'}>
    ${unlocked() ? matchupCard(p, sport, stat, statLabel, s) : (p.matchup || p.hasMatchup ? `<section class="matchup-card"><h2>Matchup: ${esc(p.opp)} defense</h2><p class="muted">See what this defense allows to his position, and where it ranks in the league.</p>${lockPill('Unlock matchups')}</section>` : '')}
    ${(p.bvp || p.hasBvp) && !unlocked() ? `<section class="bvp"><h3>Career vs ${esc(p.bvp?.pitcher || 'tonight’s starter')}</h3>${lockPill('Unlock batter vs pitcher')}</section>` : ''}
    ${p.bvp && unlocked() ? `<section class="bvp"><h3>Career vs ${esc(p.bvp.pitcher)}</h3>
      <div><b>${p.bvp.h}-${p.bvp.ab}</b>hits</div><div><b>${esc(p.bvp.avg)}</b>avg</div><div><b>${p.bvp.hr}</b>HR</div>
      <div><b>${p.bvp.bb}</b>BB</div><div><b>${p.bvp.so}</b>K</div><div><b>${esc(p.bvp.ops)}</b>OPS</div></section>` : ''}

    </div>
    <section class="log" ${tab === 'log' ? '' : 'hidden'}>
      ${seasonTable(p, sport, cols, labelFor)}
      <h2>Game log</h2>
      <div class="log-wrap"><table class="gl">
        <thead><tr><th>Date</th><th>Opp</th><th>Result</th>${cols.map((c) => `<th ${c === stat ? 'class="sel"' : ''} title="${esc(s.stats.find((x) => x.key === c)?.label || c)}">${esc(labelFor(c))}</th>`).join('')}</tr></thead>
        <tbody>${p.rows
          .filter((r, i) => unlocked() || i < 10)
          .slice(0, ui.fullLog ? p.rows.length : 20)
          .map((r) => {
            const v = r[META_LEN + idx];
            const hit = v === null || v === line ? '' : (side === 'under' ? v < line : v > line) ? 'h' : 'm';
            return `<tr class="${unlocked() && r[3] === String(p.oppId) ? 'h2h' : ''} ${r[6] === 'P' ? 'post' : ''}"><td>${esc(shortDate(r[0]))}</td><td>${esc(r[4])} ${esc(r[2])}</td><td>${esc(r[5])}</td>
              ${cols.map((c) => {
                const val = r[META_LEN + p.cols.indexOf(c)];
                return `<td class="${c === stat ? `sel ${hit}` : ''}">${fmtNum(val)}</td>`;
              }).join('')}</tr>`;
          })
          .join('')}</tbody>
      </table></div>
      ${!unlocked() && p.rows.length > 10 ? `<p class="note upsell">Showing the last 10 games. ${lockPill(`See all ${p.rows.length} with Premium`)}</p>` : ''}
      ${unlocked() && p.rows.length > 20 ? `<button class="btn more" id="full-log">${ui.fullLog ? 'Show last 20 games' : `Show all ${p.rows.length} games`}</button>` : ''}
    </section>
  `;

  app.querySelectorAll('[data-stat]').forEach((b) =>
    b.addEventListener('click', () => {
      const pr = props.find((x) => x.stat === b.dataset.stat);
      const next = new URLSearchParams({ s: b.dataset.stat, side });
      if (pr) next.set('l', pr.line);
      history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
      renderPlayer(sport, gameId, pid, next);
    }),
  );
  app.querySelectorAll('[data-step]').forEach((b) =>
    b.addEventListener('click', () => setParams({ l: String(Math.max(0, line + Number(b.dataset.step))) })),
  );
  const input = document.getElementById('line');
  input.addEventListener('change', () => {
    const v = Number(input.value);
    if (!Number.isNaN(v) && v >= 0) setParams({ l: String(v) });
  });
  app.querySelectorAll('[data-side]').forEach((b) => b.addEventListener('click', () => setParams({ side: b.dataset.side })));
  app.querySelectorAll('[data-line]').forEach((b) => b.addEventListener('click', () => setParams({ l: b.dataset.line })));
  app.querySelectorAll('[data-season-mode]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.seasonMode = b.dataset.seasonMode;
      setParams({});
    }),
  );
  app.querySelectorAll('[data-ptab]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.playerTab = b.dataset.ptab;
      setParams({});
    }),
  );
  app.querySelectorAll('[data-loc]').forEach((b) => b.addEventListener('click', () => {
    f.loc = b.dataset.loc;
    setParams({});
  }));
  document.getElementById('usage-key')?.addEventListener('change', (e) => {
    f.usageKey = e.target.value;
    f.usageMin = null;
    setParams({});
  });
  app.querySelectorAll('[data-usage-step]').forEach((b) =>
    b.addEventListener('click', () => {
      const dir = Number(b.dataset.usageStep);
      const start = f.usageMin === null || f.usageMin === undefined ? Math.round(usageMedian / usage.step) * usage.step : f.usageMin + dir * usage.step;
      f.usageMin = Math.max(0, start);
      setParams({});
    }),
  );
  document.getElementById('usage-clear')?.addEventListener('click', () => {
    f.usageMin = null;
    setParams({});
  });
  app.querySelectorAll('[data-chart]').forEach((b) =>
    b.addEventListener('click', () => {
      ui[b.dataset.chart] = ui[b.dataset.chart] === false;
      setParams({});
    }),
  );
  app.querySelectorAll('[data-filter]').forEach((b) =>
    b.addEventListener('click', () => {
      f[b.dataset.filter] = b.dataset.value;
      setParams({});
    }),
  );
  document.getElementById('more-filters')?.addEventListener('toggle', (e) => {
    ui.moreOpen = e.target.open;
  });
  document.getElementById('mate')?.addEventListener('change', (e) => {
    f.mate = e.target.value;
    setParams({});
  });
  app.querySelectorAll('[data-mate-mode]').forEach((b) =>
    b.addEventListener('click', () => {
      f.mateMode = b.dataset.mateMode;
      setParams({});
    }),
  );
  document.getElementById('clear-filters')?.addEventListener('click', () => {
    Object.assign(f, { loc: 'all', recent: false, rest: 'all', result: 'all', opp: 'all', season: 'all', stype: 'all', mate: '', usageMin: null });
    setParams({});
  });
  app.querySelector('[data-recent]')?.addEventListener('click', () => {
    f.recent = !f.recent;
    setParams({});
  });
  document.getElementById('share-btn')?.addEventListener('click', () =>
    shareCard({ player: p, stat, statLabel, line, side, wins, idx, win, sport: s.short, breakeven: priced ? bb.breakeven : null }),
  );

  wireSave(savedProp, () => setParams({}));
  document.getElementById('full-log')?.addEventListener('click', () => {
    ui.fullLog = !ui.fullLog;
    setParams({});
  });
  app.querySelectorAll('[data-win]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.win = b.dataset.win;
      setParams({});
    }),
  );
}

// Playing-time measures each sport offers for the "at least" filter.
const USAGE = {
  basketball: [
    { key: 'min', label: 'Minutes', step: 2, unit: 'm' },
    { key: 'fgm', label: 'Field goals made', step: 1, unit: '' },
    { key: 'fga', label: 'Field goal attempts', step: 2, unit: '' },
    { key: 'fg3m', label: '3-pointers made', step: 1, unit: '' },
    { key: 'fg3a', label: '3-point attempts', step: 1, unit: '' },
    { key: 'fg2m', label: '2-pointers made', step: 1, unit: '' },
    { key: 'pts', label: 'Points', step: 2, unit: '' },
    { key: 'reb', label: 'Rebounds', step: 1, unit: '' },
    { key: 'oreb', label: 'Offensive rebounds', step: 1, unit: '' },
    { key: 'dreb', label: 'Defensive rebounds', step: 1, unit: '' },
    { key: 'fg2a', label: '2-point attempts', step: 1, unit: '' },
    { key: 'ast', label: 'Assists', step: 1, unit: '' },
  ],
  hockey: [
    { key: 'toi', label: 'Time on ice', step: 1, unit: 'm' },
    { key: 'shots', label: 'Shots', step: 1, unit: '' },
    { key: 'points', label: 'Points', step: 1, unit: '' },
    { key: 'blocks', label: 'Blocked shots', step: 1, unit: '' },
    { key: 'goalieToi', label: 'Minutes', step: 5, unit: 'm' },
    { key: 'shotsAgainst', label: 'Shots faced', step: 3, unit: '' },
  ],
  football: [
    { key: 'passAtt', label: 'Pass attempts', step: 3, unit: '' },
    { key: 'rushAtt', label: 'Carries', step: 2, unit: '' },
    { key: 'tgt', label: 'Targets', step: 1, unit: '' },
    { key: 'rec', label: 'Receptions', step: 1, unit: '' },
    { key: 'cmp', label: 'Completions', step: 2, unit: '' },
  ],
  baseball: [
    { key: 'ab', label: 'At bats', step: 1, unit: '' },
    { key: 'h', label: 'Hits', step: 1, unit: '' },
    { key: 'bb', label: 'Walks', step: 1, unit: '' },
    { key: 'pitches', label: 'Pitches', step: 10, unit: '' },
    { key: 'pOuts', label: 'Outs recorded', step: 3, unit: '' },
  ],
};
const SPORT_FAMILY = { nba: 'basketball', wnba: 'basketball', ncaam: 'basketball', ncaaw: 'basketball', nhl: 'hockey', nfl: 'football', ncaaf: 'football', mlb: 'baseball' };

/** The playing-time measures this player actually has numbers for. */
function usageOptions(sport, p) {
  return (USAGE[SPORT_FAMILY[sport]] || []).filter((u) => {
    const i = p.cols.indexOf(u.key);
    return i >= 0 && p.rows.some((r) => (r[META_LEN + i] ?? 0) > 0);
  });
}
const median = (vals) => {
  const v = [...vals].sort((a, b) => a - b);
  return v.length ? v[Math.floor(v.length / 2)] : 0;
};

/** Plain-English list of what's currently filtering the games. */
function filterSummary(f, p) {
  const parts = [];
  if (f.loc === 'vs') parts.push('home games');
  if (f.loc === '@') parts.push('away games');
  if (f.stype === 'R') parts.push('regular season');
  if (f.stype === 'P') parts.push('playoffs');
  if (f.mate && f.mateName) parts.push(`${f.mateMode} ${f.mateName}`);
  if (f.recent) parts.push('last 30 days');
  if (f.rest === 'b2b') parts.push('back-to-back games');
  if (f.rest === 'rested') parts.push('3+ days rest');
  if (f.result === 'W') parts.push('wins');
  if (f.result === 'L') parts.push('losses');
  if (f.season === 'cur') parts.push('this season');
  if (f.season === 'prev') parts.push('earlier seasons');
  if (f.opp === 'easy') parts.push('soft defenses');
  if (f.opp === 'tough') parts.push('tough defenses');
  if (f.usageMin !== null && f.usageMin !== undefined && f.usageKey) {
    const u = Object.values(USAGE).flat().find((x) => x.key === f.usageKey);
    if (u) parts.push(`${u.label.toLowerCase()} ${fmtNum(f.usageMin)}${u.unit}+`);
  }
  return parts.join(', ');
}

/** How each sport writes a season: 2025-26 for winter leagues, 2026 for the rest. */
function seasonName(sport, season) {
  return ['nba', 'nhl', 'ncaam', 'ncaaw'].includes(sport) ? `${season - 1}-${String(season).slice(2)}` : String(season);
}

/** Every season we have for this player, regular season and playoffs, as averages or totals. */
function seasonTable(p, sport, cols, labelFor) {
  const list = p.seasons || [];
  if (!list.length && p.hasSeasons) return `<div class="season-head"><h2>Seasons</h2></div><p class="note upsell">Totals and averages for this season and the two before it, regular season and playoffs. ${lockPill('Unlock season history')}</p>`;
  if (!list.length) return '';
  const mode = ui.seasonMode === 'tot' ? 'tot' : 'avg';
  return `<div class="season-head"><h2>Seasons</h2>
      <div class="seg" role="group" aria-label="Averages or totals">
        <button type="button" data-season-mode="avg" aria-pressed="${mode === 'avg'}">Per game</button>
        <button type="button" data-season-mode="tot" aria-pressed="${mode === 'tot'}">Totals</button>
      </div></div>
    <div class="log-wrap"><table class="gl seasons">
      <thead><tr><th>Season</th><th>GP</th>${cols.map((c) => `<th>${esc(labelFor(c))}</th>`).join('')}</tr></thead>
      <tbody>${list.map((x) => `<tr>
        <td>${esc(seasonName(sport, x.season))}${x.type === 'P' ? ' <span class="post-tag">Playoffs</span>' : ''}</td>
        <td>${x.gp}</td>
        ${cols.map((c) => `<td>${x[mode][c] === undefined ? '–' : fmtNum(x[mode][c])}</td>`).join('')}
      </tr>`).join('')}</tbody>
    </table></div>`;
}

function filterRow(label, key, options, f) {
  return `<div class="filter-row"><span>${label}</span><div class="chips">${options
    .map(([value, text]) => `<button class="chip" type="button" data-filter="${key}" data-value="${value}" aria-pressed="${f[key] === value}">${text}</button>`)
    .join('')}</div></div>`;
}

const GROUP_LABEL = {
  QB: 'quarterbacks', RB: 'running backs', WR: 'wide receivers', TE: 'tight ends', K: 'kickers', DEF: 'defenders',
  REC: 'pass catchers',
  G: 'guards', F: 'forwards', C: 'centers', D: 'defensemen', ALL: 'this position',
};
const groupLabelFor = (sport, group) => (sport === 'nhl' && group === 'G' ? 'goalies' : sport === 'nhl' && group === 'F' ? 'forwards' : GROUP_LABEL[group] || 'this position');

/** How friendly a rank is: 1 = allows the most. */
const rankTone = (rank, of) => (of < 6 ? '' : rank <= of / 3 ? 'good' : rank > (of * 2) / 3 ? 'bad' : '');
const ordinal = (n) => {
  const s2 = ['th', 'st', 'nd', 'rd'][(n % 100 > 10 && n % 100 < 14) || n % 10 > 3 ? 0 : n % 10];
  return `${n}${s2}`;
};

/** What tonight's opponent gives up to this player's position. */
function matchupCard(p, sport, stat, statLabel, s) {
  const m = p.matchup;
  if (!m) return '';
  const who = groupLabelFor(sport, m.group);
  const labelOf = (key) => s.stats.find((x) => x.key === key)?.label || key;
  const order = [stat, ...Object.keys(m.stats).filter((k) => k !== stat)];
  const rows = order.filter((k) => m.stats[k]).slice(0, 8);
  if (!rows.length) return '';
  const headline = m.stats[stat];
  return `<section class="matchup-card">
    <h2>Matchup: ${esc(p.opp)} defense</h2>
    <p class="muted">Per game allowed to ${esc(who)}${m.games ? ` over ${m.games} games` : ''}. Rank 1 allows the most.</p>
    ${headline ? `<p class="matchup-head ${rankTone(headline.rank, headline.of)}">
      <b>${fmtNum(headline.value)}</b> ${esc(statLabel.toLowerCase())} allowed, <b>${esc(ordinal(headline.rank))}</b> most of ${headline.of}</p>` : ''}
    <div class="matchup-grid">${rows.map((k) => {
      const v = m.stats[k];
      return `<div class="${k === stat ? 'is-stat' : ''}">
        <span class="label">${esc(labelOf(k))}</span>
        <span class="value">${fmtNum(v.value)}</span>
        <span class="rank ${rankTone(v.rank, v.of)}">${esc(ordinal(v.rank))} most</span>
      </div>`;
    }).join('')}</div>
  </section>`;
}

const defenseCache = new Map();
/** Rank of every team against this player's position and stat, for judging past opponents. */
async function loadDefenseRanks(sport, player, stat) {
  if (!player.matchup) return null;
  const key = `${sport}|${player.matchup.group}|${stat}`;
  if (defenseCache.has(key)) return defenseCache.get(key);
  let ranks = null;
  try {
    const data = await privateOr(`data/${sport}/defense.json`, `${sport}/defense.json`);
    ranks = new Map();
    for (const [teamId, team] of Object.entries(data.teams || {})) {
      const info = team.groups?.[player.matchup.group]?.[stat] || team.groups?.ALL?.[stat];
      if (info) ranks.set(String(teamId), info);
    }
    if (!ranks.size) ranks = null;
  } catch {
    ranks = null;
  }
  defenseCache.set(key, ranks);
  return ranks;
}

function injuryBanner(p) {
  const i = p.injury;
  if (!i && !p.inj) return '';
  const status = i?.status || p.inj;
  const details = [i?.injury, i?.returnDate ? `expected back ${shortDate(i.returnDate.slice(0, 10))}` : ''].filter(Boolean).join(', ');
  return `<div class="inj-banner s${severity(status)}" role="note"><b>${esc(status)}</b>${details ? ` ${esc(details)}` : ''}${i?.note ? `<br>${esc(i.note)}` : ''}</div>`;
}

const SHARE = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M12 3 8 7M12 3l4 4"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/></svg>';
const PIN = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 3h12v18l-6-4.5L6 21z"/></svg>';

function saveControl(prop) {
  let button = '';
  if (account.enabled) {
    if (!account.user) button = `<button class="save-btn" data-save="login" type="button">${PIN} Save prop</button>`;
    else if (!isPremium()) button = `<button class="save-btn" data-save="upsell" type="button">${PIN} Save prop <span class="lock">Premium</span></button>`;
    else {
      const saved = findSaved(prop);
      button = `<button class="save-btn" data-save="toggle" type="button" aria-pressed="${Boolean(saved)}">${PIN} ${saved ? 'Saved' : 'Save prop'}</button>`;
    }
  }
  return `<div class="save-row" style="margin-top:12px">${button}<button class="save-btn" id="share-btn" type="button">${SHARE} Share</button><p class="save-note" id="save-note" hidden></p></div>`;
}

function wireSave(prop, rerender) {
  const btn = app.querySelector('[data-save]');
  const note = document.getElementById('save-note');
  if (!btn) return;
  const say = (html) => {
    note.innerHTML = html;
    note.hidden = false;
  };
  btn.addEventListener('click', async () => {
    const mode = btn.dataset.save;
    if (mode === 'login') {
      location.hash = `#/account?next=${encodeURIComponent(location.hash)}`;
      return;
    }
    if (mode === 'upsell') {
      say('Saving props is part of Premium. <a href="#/account">See plans</a>');
      return;
    }
    btn.disabled = true;
    const existing = findSaved(prop);
    const res = existing ? await removeSaved(existing.id) : await saveProp(prop);
    btn.disabled = false;
    if (!res.ok) return say(esc(res.message));
    rerender();
  });
}

function abbrev(key, stats) {
  const map = {
    min: 'MIN', pts: 'PTS', reb: 'REB', ast: 'AST', fg3m: '3PM', stl: 'STL', blk: 'BLK', tov: 'TO', pra: 'PRA', pr: 'PR', pa: 'PA', ra: 'RA',
    stocks: 'STK', fgm: 'FGM', fga: 'FGA', fg3a: '3PA', fg2m: '2PM', fg2a: '2PA', oreb: 'OREB', dreb: 'DREB', ftm: 'FTM',
    cmp: 'CMP', passAtt: 'ATT', passYds: 'PYDS', passTd: 'PTD', int: 'INT', passLng: 'LNG', rushAtt: 'CAR', rushYds: 'RYDS', rushLng: 'RLNG',
    rec: 'REC', tgt: 'TGT', recYds: 'RECYDS', recLng: 'RECLNG', rushRecYds: 'R+R', passRushYds: 'P+R', tds: 'TD', tkl: 'TKL', solo: 'SOLO',
    sacks: 'SACK', defInt: 'INT', pd: 'PD', xpm: 'XP', kpts: 'KPTS',
    fantasy: 'FPTS', pFantasy: 'FPTS', gFantasy: 'FPTS',
    points: 'PTS', goals: 'G', assists: 'A', shots: 'SOG', blocks: 'BLK', hits: 'HIT', ppp: 'PPP', pim: 'PIM', toi: 'TOI',
    saves: 'SV', shotsAgainst: 'SA', goalsAgainst: 'GA', savePct: 'SV%', goalieToi: 'MIN',
    h: 'H', tb: 'TB', hrr: 'H+R+RBI', hr: 'HR', rbi: 'RBI', r: 'R', singles: '1B', doubles: '2B', bb: 'BB', so: 'K', sb: 'SB', ab: 'AB',
    pK: 'K', pOuts: 'OUTS', pH: 'H', pER: 'ER', pBB: 'BB', pitches: 'PC',
  };
  return map[key] || stats.find((s) => s.key === key)?.label || key;
}

function shortDate(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  const thisYear = new Date().getFullYear();
  return `${m}/${d}${y !== thisYear ? `/${String(y).slice(2)}` : ''}`;
}

/** Average of the last n values (newest first). */
const avgOf = (vals) => (vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null);

function trendText(rows, idx) {
  const vals = [...rows].reverse().map((r) => r[META_LEN + idx]).filter((v) => v !== null); // newest first
  if (vals.length < 6) return '';
  const recent = avgOf(vals.slice(0, 5));
  const before = avgOf(vals.slice(5));
  const diff = Math.round((recent - before) * 10) / 10;
  if (Math.abs(diff) < 0.5) return `Last 5 average ${fmtNum(Math.round(recent * 10) / 10)}, steady with the ${vals.length - 5} before`;
  return `Last 5 average ${fmtNum(Math.round(recent * 10) / 10)}, ${diff > 0 ? 'up' : 'down'} ${fmtNum(Math.abs(diff))} on the ${vals.length - 5} before`;
}

function barChart(rows, idx, line, side, options = {}) {
  const available = Math.max(320, (app.clientWidth || 700) - 20);
  const W = Math.max(available, rows.length * 30 + 48);
  const showUsage = options.usageIdx !== undefined && options.usageIdx >= 0;
  const H = showUsage ? 244 : 230;
  const top = 22;
  const bottom = showUsage ? 48 : 34;
  const left = 8;
  const right = 40;
  const vals = rows.map((r) => r[META_LEN + idx]);
  const max = Math.max(line, ...vals, 1) * 1.15;
  const plotH = H - top - bottom;
  const y = (v) => top + plotH - (v / max) * plotH;
  const slot = (W - left - right) / rows.length;
  const bw = Math.min(38, slot * 0.66);

  const bars = rows
    .map((r, i) => {
      const v = r[META_LEN + idx];
      const hit = side === 'under' ? v < line : v > line;
      const cls = v === line ? 'bar-push' : hit ? 'bar-hit' : 'bar-miss';
      const x = left + i * slot + (slot - bw) / 2;
      const h = Math.max(2, top + plotH - y(v));
      const cx = x + bw / 2;
      return `<g><title>${esc(r[0])} ${esc(r[4])} ${esc(r[2])}: ${fmtNum(v)}</title>
        <rect class="bar ${cls}" x="${x.toFixed(1)}" y="${(top + plotH - h).toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="2"/>
        <text class="bar-val" x="${cx.toFixed(1)}" y="${(top + plotH - h - 5).toFixed(1)}">${fmtNum(v)}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 15}">${esc(r[2])}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 28}">${esc(shortDate(r[0]))}</text>
        ${showUsage && r[META_LEN + options.usageIdx] !== null ? `<text class="bar-usage" x="${cx.toFixed(1)}" y="${H - bottom + 42}">${fmtNum(Math.round(r[META_LEN + options.usageIdx]))}${options.usageUnit}</text>` : ''}</g>`;
    })
    .join('');
  const ly = y(line).toFixed(1);

  // Running 3-game average, so streaks and slides are visible at a glance.
  const window3 = [];
  const trendPoints = rows.map((r, i) => {
    window3.push(r[META_LEN + idx]);
    if (window3.length > 3) window3.shift();
    const avg = avgOf(window3);
    return `${(left + i * slot + slot / 2).toFixed(1)},${y(avg).toFixed(1)}`;
  });
  const avgAll = avgOf(vals);
  const avgY = avgAll === null ? null : y(avgAll).toFixed(1);

  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Game by game results against the line">
    <line class="axis" x1="${left}" x2="${W - right}" y1="${top + plotH}" y2="${top + plotH}"/>
    ${avgY && options.showAverage !== false ? `<line class="avg-rule" x1="${left}" x2="${W - right}" y1="${avgY}" y2="${avgY}"/>
      <text class="avg-tag" x="${left + 4}" y="${Number(avgY) - 7}">avg ${fmtNum(Math.round(avgAll * 10) / 10)}</text>` : ''}
    ${bars}
    ${rows.length > 3 && options.showTrend !== false ? `<polyline class="trend-line" points="${trendPoints.join(' ')}"/>` : ''}
    <line class="line-rule" x1="${left}" x2="${W - right + 4}" y1="${ly}" y2="${ly}"/>
    <text class="line-tag" x="${W - right + 8}" y="${Number(ly) + 5}">${fmtNum(line)}</text>
  </svg>`;
}



// ---------- shareable prop card ----------
const themeVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim() || '#888';

/** Draw the current prop as an image and hand it to the phone's share sheet. */
export async function shareCard({ player, statLabel, line, side, wins, idx, win, sport, breakeven }) {
  const W = 1080;
  const H = 1350;
  const c = document.createElement('canvas');
  c.width = W;
  c.height = H;
  const x = c.getContext('2d');
  const ink = themeVar('--text');
  const bg = themeVar('--bg');
  const muted = themeVar('--muted');
  const hit = themeVar('--hit');
  const miss = themeVar('--miss');
  const lamp = themeVar('--lamp');
  const body = "600 34px Barlow, system-ui, sans-serif";
  const display = (size, weight = 700) => `${weight} ${size}px 'Barlow Condensed', 'Arial Narrow', sans-serif`;
  /** Shrink text until it fits the width given, then draw it. */
  const fit = (text, px, py, maxW, size, weight = 700) => {
    let s2 = size;
    do {
      x.font = display(s2, weight);
      s2 -= 2;
    } while (x.measureText(text).width > maxW && s2 > 16);
    x.fillText(text, px, py);
  };

  x.fillStyle = bg;
  x.fillRect(0, 0, W, H);
  x.fillStyle = lamp;
  x.fillRect(0, 0, W, 10);

  x.fillStyle = ink;
  fit(player.name, 60, 150, W - 120, 84);
  x.font = body;
  x.fillStyle = muted;
  x.fillText(`${player.pos}   ${player.team} ${player.home ? 'vs' : '@'} ${player.opp}   ${sport}`, 62, 200);

  x.fillStyle = ink;
  fit(`${side === 'under' ? 'Under' : 'Over'} ${fmtNum(line)} ${statLabel}`, 60, 320, W - 120, 96);
  if (breakeven !== null && breakeven !== undefined) {
    x.font = body;
    x.fillStyle = muted;
    x.fillText(`Break-even ${breakeven}%`, 62, 372);
  }

  // hit-rate tiles
  const tiles = WINDOWS.filter(([w]) => windowOpen(w)).map(([w, label]) => {
    const [hits, n] = rateRows(wins[w], idx, line, side);
    return [label, pctOf([hits, n]), hits, n];
  });
  const tw = (W - 120 - (tiles.length - 1) * 18) / tiles.length;
  tiles.forEach(([label, pct, hits, n], i) => {
    const tx = 60 + i * (tw + 18);
    x.fillStyle = themeVar('--panel');
    x.fillRect(tx, 420, tw, 190);
    x.fillStyle = muted;
    x.font = display(34, 600);
    x.fillText(label, tx + 22, 466);
    x.fillStyle = pct === null ? muted : pct >= (breakeven ?? 50) ? hit : miss;
    fit(pct === null ? '–' : `${pct}%`, tx + 22, 545, tw - 40, 78);
    x.fillStyle = muted;
    x.font = "500 26px Barlow, system-ui, sans-serif";
    x.fillText(n ? `${hits} of ${n}` : 'no games', tx + 22, 585);
  });

  // last games as bars
  const rows = [...wins[win]].reverse().filter((r) => r[META_LEN + idx] !== null).slice(-10);
  const top = 700;
  const plotH = 430;
  const max = Math.max(line, ...rows.map((r) => r[META_LEN + idx]), 1) * 1.2;
  const slot = (W - 120) / Math.max(rows.length, 1);
  rows.forEach((r, i) => {
    const v = r[META_LEN + idx];
    const won = side === 'under' ? v < line : v > line;
    const bw = Math.min(70, slot * 0.62);
    const bx = 60 + i * slot + (slot - bw) / 2;
    const bh = (v / max) * plotH;
    x.fillStyle = won ? hit : miss;
    x.globalAlpha = won ? 1 : 0.35;
    x.fillRect(bx, top + plotH - bh, bw, bh);
    x.globalAlpha = 1;
    x.fillStyle = ink;
    x.font = display(32, 600);
    x.textAlign = 'center';
    x.fillText(fmtNum(v), bx + bw / 2, top + plotH - bh - 14);
    x.fillStyle = muted;
    x.font = "500 24px Barlow, system-ui, sans-serif";
    x.fillText(r[2], bx + bw / 2, top + plotH + 36);
    x.textAlign = 'left';
  });
  const ly = top + plotH - (line / max) * plotH;
  x.strokeStyle = lamp;
  x.lineWidth = 5;
  x.beginPath();
  x.moveTo(60, ly);
  x.lineTo(W - 60, ly);
  x.stroke();

  x.fillStyle = muted;
  x.font = body;
  x.fillText(`${WINDOWS.find((w) => w[0] === win)[1]} games`, 62, top + plotH + 100);
  x.fillStyle = ink;
  x.font = display(48);
  x.textAlign = 'right';
  x.fillText(location.host || 'Propbook', W - 60, top + plotH + 105);
  x.textAlign = 'left';

  const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
  if (!blob) return;
  const fileName = `${player.name.replace(/\W+/g, '-').toLowerCase()}-${statLabel.replace(/\W+/g, '-').toLowerCase()}.png`;
  const file = new File([blob], fileName, { type: 'image/png' });
  const note = document.getElementById('save-note');
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], text: `${player.name} ${side === 'under' ? 'under' : 'over'} ${fmtNum(line)} ${statLabel}` });
      return;
    } catch {
      /* cancelled or refused: fall through to a download */
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  if (note) {
    note.textContent = 'Image saved to your downloads.';
    note.hidden = false;
  }
}

// ---------- injuries & news ----------
function relDay(iso) {
  const t = Date.parse(iso);
  if (!t) return '';
  const d = new Date(t);
  const today = new Date();
  const days = Math.round((new Date(today.toDateString()) - new Date(d.toDateString())) / 864e5);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(d);
}

async function renderInjuries(sport, gameId) {
  const s = meta.sports[sport];
  const [report, slate] = await Promise.all([
    load(`data/${sport}/injuries.json`).catch(() => null),
    loadSlate(sport).catch(() => null),
  ]);
  const alerts = await outCount(sport);
  const f = (ui.injFilter ||= { scope: 'slate', kind: 'all' });
  if (!report) {
    app.innerHTML = `${subnav(sport, 'injuries')}<section class="empty"><h1>Injury report coming soon</h1>
      <p class="muted">It's added on the next daily refresh.</p></section>`;
    return;
  }
  const items = report.items.filter(
    (i) =>
      (gameId ? i.gameId === gameId : f.scope === 'all' || i.onSlate) &&
      (f.kind === 'all' || i.kind === f.kind),
  );
  const multiDay = slate && slate.from !== slate.until;
  const gamesStrip = slate?.games?.length
    ? `<nav class="games" aria-label="Games">
        <a class="game" href="#/${sport}/injuries" aria-current="${!gameId}"><strong>All teams</strong><span>league-wide</span></a>
        ${slate.games.map((g) => `<a class="game" href="#/${sport}/injuries/g/${g.id}" aria-current="${g.id === gameId}">
          <strong>${esc(gameLabel(g))}</strong><span>${esc(gameTime(g, multiDay))}</span></a>`).join('')}
      </nav>`
    : '';
  const chip = (group, value, label) =>
    `<button class="chip" type="button" data-${group}="${value}" aria-pressed="${f[group] === value}">${label}</button>`;

  const row = (i) => {
    const title = i.kind === 'news'
      ? i.url ? `<a href="${esc(i.url)}" target="_blank" rel="noopener">${esc(i.headline)}</a>` : esc(i.headline)
      : i.pid && i.gameId ? `<a href="#/${sport}/p/${esc(i.gameId)}/${encodeURIComponent(i.pid)}">${esc(i.player)}</a>` : esc(i.player || i.teamName || i.team);
    const namedPlayer = i.kind !== 'news' && (i.player || i.pid);
    const meta1 = namedPlayer ? [i.pos, i.team || i.teamName].filter(Boolean).map(esc).join(' ') : '';
    const detail = i.kind === 'injury'
      ? [i.side, i.injury].filter(Boolean).join(' ') + (i.returnDate ? `${i.injury ? ', ' : ''}expected back ${shortDate(i.returnDate.slice(0, 10))}` : '')
      : '';
    const body = [detail, i.kind !== 'news' ? i.note : ''].filter(Boolean).map(esc).join('<br>');
    return `<article class="report">
      <div><h3>${title}</h3>${meta1 || i.kind === 'news' ? `<div class="meta">${i.kind === 'news' ? (i.player ? esc(i.player) : 'ESPN') : meta1}</div>` : ''}</div>
      <div style="text-align:right"><span class="status s${i.kind === 'news' ? 1 : severity(i.status)}">${esc(i.status)}</span><div class="when">${esc(relDay(i.date))}</div></div>
      ${body ? `<p>${body}</p>` : ''}
    </article>`;
  };

  app.innerHTML = `
    ${subnav(sport, 'injuries', alerts)}
    ${gamesStrip}
    ${gameId ? '' : `<div class="chips" role="group" aria-label="Which teams">
      ${chip('scope', 'slate', 'Upcoming games')}${chip('scope', 'all', `All ${esc(s.short)}`)}
    </div>`}
    <div class="chips" role="group" aria-label="Type">
      ${chip('kind', 'all', 'Everything')}${chip('kind', 'injury', 'Injuries')}${chip('kind', 'move', 'Roster moves')}${chip('kind', 'news', 'Headlines')}
    </div>
    ${items.length
      ? `<div class="reports">${items.map(row).join('')}</div>`
      : `<p class="note">Nothing here right now. ${gameId ? 'No injuries reported for this game.' : f.scope === 'slate' ? `Try All ${esc(s.short)}.` : 'Check back after the next refresh.'}</p>`}
  `;
  app.querySelectorAll('[data-scope]').forEach((b) => b.addEventListener('click', () => { f.scope = b.dataset.scope; renderInjuries(sport, gameId); }));
  app.querySelectorAll('[data-kind]').forEach((b) => b.addEventListener('click', () => { f.kind = b.dataset.kind; renderInjuries(sport, gameId); }));
}

// ---------- account ----------
const PLANS = {
  free: ['Every player on today’s slate', 'L5 and L10 hit rates', 'Consensus sportsbook line', 'Injury reports and news', 'Last 10 games in each game log'],
  premium: ['Everything in Free', 'L20, head-to-head and season hit rates', 'Compare odds across sportsbooks', 'Full game logs and batter vs pitcher', 'Save props and track them with live hit rates', 'More features on the way'],
};

function renderAccountPage(params) {
  if (!account.ready) {
    app.innerHTML = `<section class="account">${ui.unsubMessage ? `<p class="note">${esc(ui.unsubMessage)}</p>` : ''}<p class="muted">Loading your account…</p></section>`;
    return;
  }
  if (!account.enabled) {
    app.innerHTML = `<section class="empty"><h1>Accounts aren’t available yet</h1><p class="muted">${esc(account.error || 'Everything else on the site works without an account.')}</p></section>`;
    document.getElementById('account-link').hidden = true;
    return;
  }
  const next = params.get('next');

  if (account.recovering) {
    app.innerHTML = `<section class="account"><h1>Set a new password</h1>
      <form class="form" id="pw-form"><label>New password<input name="password" type="password" minlength="8" autocomplete="new-password" required></label>
      <button class="btn primary" type="submit">Save new password</button><p class="msg" id="msg" hidden></p></form></section>`;
    wireForm('pw-form', async (d) => {
      const res = await setNewPassword(d.password);
      return res.ok ? { done: true } : res;
    }, () => { location.hash = '#/account'; route(); });
    return;
  }

  if (!account.user) {
    const mode = ui.authMode || 'login';
    const titles = { login: 'Log in', signup: 'Create your account', reset: 'Reset your password' };
    app.innerHTML = `<section class="account">
      <h1>${titles[mode]}</h1>
      ${ui.unsubMessage ? `<p class="note">${esc(ui.unsubMessage)}</p>` : ''}
      ${ui.upgrading ? '<p class="note">Thanks for upgrading. Log in with the email you paid with to see Premium.</p>' : ''}
      ${ui.promo ? `<p class="note">Log in or create a free account to use promo code <b>${esc(ui.promo)}</b>.</p>` : ''}
      <p class="muted">${mode === 'signup' ? 'Free to join. Upgrade to Premium any time.' : mode === 'reset' ? 'We’ll email you a link to set a new password.' : 'Welcome back.'}</p>
      <form class="form" id="auth-form" novalidate>
        <label>Email<input name="email" type="email" autocomplete="email" inputmode="email" required></label>
        ${mode !== 'reset' ? `<label>Password<input name="password" type="password" minlength="8" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" required></label>` : ''}
        ${mode === 'signup' ? `<label>Referral code (optional)<input name="ref" autocomplete="off" autocapitalize="characters" spellcheck="false" value="${esc(ui.ref || '')}"></label>
        <label class="check"><input type="checkbox" name="age" value="yes" required> <span>I'm 21 or older and I agree to the <a href="terms.html" target="_blank" rel="noopener">Terms</a> and <a href="privacy.html" target="_blank" rel="noopener">Privacy Policy</a>.</span></label>` : ''}
        <button class="btn primary" type="submit">${mode === 'login' ? 'Log in' : mode === 'signup' ? 'Create account' : 'Send reset link'}</button>
        <p class="msg" id="msg" hidden></p>
        ${mode === 'login' ? '<button class="linkish" type="button" data-mode="reset">Forgot your password?</button>' : ''}
        <button class="linkish" type="button" data-mode="${mode === 'login' ? 'signup' : 'login'}">${mode === 'login' ? 'New here? Create an account' : 'Already have an account? Log in'}</button>
      </form>
    </section>`;
    app.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => { ui.authMode = b.dataset.mode; renderAccountPage(params); }));
    wireForm('auth-form', async (d) => {
      if (!/^\S+@\S+\.\S+$/.test(d.email || '')) return { ok: false, message: 'Enter a valid email address.' };
      if (mode !== 'reset' && (d.password || '').length < 8) return { ok: false, message: 'Use a password with at least 8 characters.' };
      if (mode === 'reset') {
        const res = await sendPasswordReset(d.email);
        return res.ok ? { ok: true, message: 'Check your email for a link to reset your password.' } : res;
      }
      if (mode === 'signup') {
        if (d.age !== 'yes') return { ok: false, message: 'Please confirm you’re 21 or older to create an account.' };
        const res = await signUp(d.email, d.password, { ageConfirmed: true, referredBy: (d.ref || '').trim().toUpperCase() });
        if (!res.ok) return res;
        return res.needsConfirmation ? { ok: true, message: 'Almost done. Check your email and tap the link to confirm your account.' } : { done: true };
      }
      const res = await signIn(d.email, d.password);
      return res.ok ? { done: true } : res;
    }, () => { location.hash = next || '#/account'; route(); });
    return;
  }

  const premium = isPremium();
  if (premium && ui.upgrading) Object.assign(ui, { upgrading: false, justUpgraded: true });
  const planCard = (key, title, price) => `<div class="plan ${account.plan === key ? 'current' : ''}">
      <h2>${title}${account.plan === key ? '<span class="badge">Your plan</span>' : ''}</h2>
      ${price ? `<p class="price">${esc(price)}</p>` : ''}
      <ul>${PLANS[key].map((f) => `<li>${esc(f)}</li>`).join('')}</ul>
    </div>`;
  const sub = account.subscription || {};
  const until = sub.periodEnd ? new Intl.DateTimeFormat(undefined, { month: 'long', day: 'numeric' }).format(new Date(sub.periodEnd)) : '';
  const longDate = (d) => new Intl.DateTimeFormat(undefined, { month: 'long', day: 'numeric', year: 'numeric' }).format(new Date(d));
  const compLine = account.comp && !account.paid
    ? `<p class="note">${new Date(account.comp.until).getFullYear() >= 2090 ? 'You have complimentary Premium.' : `You have free Premium access until ${esc(longDate(account.comp.until))}${account.comp.note ? ` (${esc(account.comp.note)})` : ''}.`}</p>`
    : '';
  const statusLine = compLine ? compLine : !premium ? ''
    : sub.status === 'past_due' ? '<p class="msg err">Your last payment didn’t go through. Update your card under Manage subscription to keep Premium.</p>'
    : sub.status === 'canceling' ? `<p class="note">Your subscription is canceled and Premium stays on${until ? ` until ${esc(until)}` : ' until the end of this billing period'}.</p>`
    : sub.status === 'trialing' ? `<p class="note">You’re on a free trial${until ? ` until ${esc(until)}` : ''}.</p>`
    : until ? `<p class="muted">Renews ${esc(until)}.</p>` : '';

  let upgrade = '';
  if (!premium && ui.upgrading) {
    upgrade = '<p class="note" id="upgrading">Payment received. Turning on Premium, this takes a few seconds…</p>';
  } else if ((!premium || (account.comp && !account.paid)) && payments.enabled) {
    upgrade = `<div class="upgrade">
      ${account.comp ? '<p class="muted" style="font-size:14px">Subscribe any time to keep Premium after your free access ends.</p>' : ''}
      ${payments.monthly ? `<a class="btn primary" href="${esc(checkoutUrl(payments.monthly))}">Go Premium${payments.monthlyPrice ? `, ${esc(payments.monthlyPrice)}` : ' monthly'}</a>` : ''}
      ${payments.yearly ? `<a class="btn" href="${esc(checkoutUrl(payments.yearly))}">Yearly${payments.yearlyPrice ? `, ${esc(payments.yearlyPrice)}` : ''}</a>` : ''}
      <p class="muted">Secure checkout by Stripe. Cancel any time.</p>
    </div>`;
  } else if (!premium) {
    upgrade = '<p class="note">Premium sign-up opens soon. Already upgraded? <button class="linkish" type="button" id="refresh-plan">Refresh your plan</button></p>';
  }

  const promoForm = account.paid ? '' : `<details class="promo" ${ui.promo ? 'open' : ''}>
      <summary>Have a promo code?</summary>
      <form class="form promo-form" id="promo-form">
        <label class="visually-hidden" for="promo-code">Promo code</label>
        <div class="promo-row"><input id="promo-code" name="code" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Enter code" value="${esc(ui.promo || '')}">
        <button class="btn primary" type="submit">Apply</button></div>
        <p class="msg" id="promo-msg" hidden></p>
      </form>
    </details>`;

  app.innerHTML = `<section class="account">
    <h1>${(ui.justUpgraded || ui.promoWelcome) && premium ? 'You’re Premium' : 'Your account'}</h1>
    ${ui.unsubMessage ? `<p class="note">${esc(ui.unsubMessage)}</p>` : ''}
    <p class="muted">${esc(account.user.email)} <span class="badge ${premium ? '' : 'free'}">${premium ? 'Premium' : 'Free'}</span></p>
    ${statusLine}
    ${upgrade}
    ${promoForm}
    <div class="plans">${planCard('free', 'Free', '')}${planCard('premium', 'Premium', [payments.monthlyPrice, payments.yearlyPrice && `or ${payments.yearlyPrice}`].filter(Boolean).join(' '))}</div>
    ${premium ? alertsBox() : ''}
    <section class="invite" id="invite" hidden></section>
    <div class="account-actions">
      ${premium ? '<a class="btn" href="#/saved" style="display:inline-flex;align-items:center;text-decoration:none">Saved props</a>' : ''}
      ${premium && portalUrl() ? `<a class="btn" href="${esc(portalUrl())}" style="display:inline-flex;align-items:center;text-decoration:none">Manage subscription</a>` : ''}
      <button class="btn" type="button" id="logout">Log out</button>
      <button class="btn danger" type="button" id="delete-account">Delete account</button>
    </div>
    ${premium && sub.status && !['canceled', 'lifetime'].includes(sub.status) ? '<p class="muted" style="font-size:13px">Deleting your account doesn’t cancel billing. Cancel under Manage subscription first.</p>' : ''}
    <p class="msg err" id="msg" hidden></p>
  </section>`;

  if (!premium && ui.upgrading) waitForPremium();

  myReferrals().then((r) => {
    const box = document.getElementById('invite');
    if (!box || !r?.code) return;
    const link = `${location.origin}${location.pathname}?ref=${r.code}`;
    box.innerHTML = `<h2>Invite friends, get a free month</h2>
      <p class="muted">When someone signs up with your link and starts a paid subscription, you get 30 days of Premium free.</p>
      <div class="invite-row"><input readonly value="${esc(link)}" aria-label="Your invite link"><button class="btn" type="button" id="copy-invite">Copy</button></div>
      <p class="muted invite-stats">Your code: <b>${esc(r.code)}</b>. ${r.joined} joined${r.rewarded ? `, ${r.rewarded} free month${r.rewarded === 1 ? '' : 's'} earned` : ''}.</p>`;
    box.hidden = false;
    document.getElementById('copy-invite').addEventListener('click', async (e) => {
      try {
        if (navigator.share) await navigator.share({ title: 'Propbook', text: 'Player prop hit rates, lines and injury news', url: link });
        else await navigator.clipboard.writeText(link);
        e.target.textContent = navigator.share ? 'Shared' : 'Copied';
      } catch {
        /* share sheet closed */
      }
    });
  });

  app.querySelectorAll('[data-alert]').forEach((box) => box.addEventListener('change', async () => {
    const next = {
      enabled: app.querySelector('[data-alert="enabled"]').checked,
      injury: app.querySelector('[data-alert="injury"]').checked,
      line: app.querySelector('[data-alert="line"]').checked,
    };
    const res = await saveAlertPrefs(next);
    ui.alertMsg = res.ok ? 'Saved.' : res.message;
    ui.alertMsgError = !res.ok;
    renderAccountPage(params);
  }));

  document.getElementById('promo-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const msg = document.getElementById('promo-msg');
    const button = form.querySelector('button');
    button.disabled = true;
    const res = await redeemPromo(new FormData(form).get('code'));
    button.disabled = false;
    if (res.ok) {
      ui.promo = '';
      ui.promoWelcome = res.until;
      renderAccountPage(params);
      return;
    }
    msg.textContent = res.message;
    msg.className = 'msg err';
    msg.hidden = false;
  });

  document.getElementById('logout').addEventListener('click', async () => { await signOut(); route(); });
  document.getElementById('refresh-plan')?.addEventListener('click', () => refreshPlan());
  document.getElementById('delete-account').addEventListener('click', async () => {
    if (!confirm('Delete your account and everything saved to it? This can’t be undone.')) return;
    const res = await deleteAccount();
    if (!res.ok) {
      const msg = document.getElementById('msg');
      msg.textContent = res.message;
      msg.hidden = false;
    } else route();
  });
}

function alertsBox() {
  const a = account.alerts || {};
  const row = (key, label, hint) => `<label class="switch">
    <input type="checkbox" data-alert="${key}" ${a[key] ? 'checked' : ''} ${key !== 'enabled' && !a.enabled ? 'disabled' : ''}>
    <span><b>${label}</b><small>${hint}</small></span>
  </label>`;
  return `<section class="alerts">
    <h2>Email alerts</h2>
    <p class="muted">About props you've saved, sent when the daily or hourly update runs.</p>
    ${row('enabled', 'Send me alerts', 'Turn everything off with one switch')}
    ${row('injury', 'Injury and roster news', 'Your player is out, questionable, waived or back')}
    ${row('line', 'Line moves', 'The line moves half a point or more from what you saved')}
    <p class="msg ${ui.alertMsgError ? 'err' : ''}" id="alert-msg" ${ui.alertMsg ? '' : 'hidden'}>${esc(ui.alertMsg || '')}</p>
  </section>`;
}

/** After Stripe sends people back, poll until the webhook has switched them to Premium. */
let polling = false;
async function waitForPremium() {
  if (polling) return;
  polling = true;
  for (let i = 0; i < 20 && !isPremium(); i++) {
    await new Promise((r) => setTimeout(r, 3000));
    await refreshPlan();
  }
  polling = false;
  if (!isPremium()) {
    ui.upgrading = false;
    const el = document.getElementById('upgrading');
    if (el) el.innerHTML = 'Your payment went through, but Premium hasn’t switched on yet. Refresh this page in a minute. If it still says Free, contact support with the email you paid with.';
  }
}

function wireForm(id, submit, onDone) {
  const form = document.getElementById(id);
  const msg = document.getElementById('msg');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    msg.hidden = true;
    const res = await submit(Object.fromEntries(new FormData(form)));
    button.disabled = false;
    if (res.done) return onDone();
    msg.textContent = res.message || '';
    msg.className = `msg ${res.ok ? '' : 'err'}`;
    msg.hidden = !res.message;
  });
}

// ---------- saved props ----------
/** Closing line value: did the line move toward the side you took after you saved it? */
function clvText(sv) {
  if (sv.close_line === null || sv.close_line === undefined) return '';
  const saved = Number(sv.line);
  const close = Number(sv.close_line);
  const edge = Math.round((sv.side === 'under' ? saved - close : close - saved) * 10) / 10;
  if (edge === 0) return `, closed ${fmtNum(close)}`;
  return `, closed ${fmtNum(close)} <span class="clv ${edge > 0 ? 'good' : 'bad'}">${edge > 0 ? 'beat the close by' : 'behind the close by'} ${fmtNum(Math.abs(edge))}</span>`;
}

async function renderSavedPage() {
  if (!account.ready) {
    app.innerHTML = '<p class="muted">Loading…</p>';
    return;
  }
  if (!account.user || !isPremium()) {
    app.innerHTML = `<section class="empty"><h1>Saved props are a Premium feature</h1>
      <p class="muted">Save any prop from a player page. We score it once the game ends and keep your running record.</p>
      <a class="btn primary" href="#/account" style="display:inline-flex;align-items:center;text-decoration:none;margin-top:12px">${account.user ? 'See plans' : 'Log in'}</a></section>`;
    return;
  }
  if (!account.saved.length) {
    app.innerHTML = `<section class="empty"><h1>No saved props yet</h1>
      <p class="muted">Open any player, set the stat and line you like, and tap Save prop.</p></section>`;
    return;
  }

  const settled = account.saved.filter((s) => s.result === 'hit' || s.result === 'miss');
  const hits = settled.filter((s) => s.result === 'hit').length;
  const pct = settled.length ? Math.round((hits / settled.length) * 100) : null;
  const f = (ui.savedFilter ||= 'all');
  const list = account.saved.filter((s) => (f === 'all' ? true : f === 'open' ? !s.result : Boolean(s.result)));

  const rows = await Promise.all(list.map(async (sv) => {
    if (sv.result) return { sv, live: null };
    let live = null;
    try {
      const slate = await loadSlate(sv.sport);
      if (slate.games.some((g) => g.id === sv.game_id)) {
        const game = await loadGame(sv.sport, sv.game_id, slate);
        const p = game.players.find((x) => x.id === sv.player_id);
        const idx = p ? p.cols.indexOf(sv.stat) : -1;
        if (idx >= 0) {
          const wins = windowsFor(p, slate.season, p.oppId);
          live = { p, rates: WINDOWS.filter(([w]) => windowOpen(w)).map(([w, label]) => [label, ...rateRows(wins[w], idx, Number(sv.line), sv.side)]) };
        }
      }
    } catch {
      /* sport data missing: show the saved details only */
    }
    return { sv, live };
  }));

  const chip = (value, label) => `<button class="chip" type="button" data-saved="${value}" aria-pressed="${f === value}">${label}</button>`;
  const badge = (sv) => {
    if (!sv.result) return '';
    const label = { hit: 'Hit', miss: 'Miss', push: 'Push', dnp: 'Did not play' }[sv.result];
    return `<span class="result ${sv.result}">${label}${sv.actual !== null && sv.actual !== undefined ? ` ${fmtNum(Number(sv.actual))}` : ''}</span>`;
  };

  const withClose = account.saved.filter((x) => x.close_line !== null && x.close_line !== undefined);
  const beat = withClose.filter((x) => (x.side === 'under' ? Number(x.line) > Number(x.close_line) : Number(x.close_line) > Number(x.line))).length;
  app.innerHTML = `<div class="subnav"><h1>Saved props</h1><p class="updated">${account.saved.length} saved</p></div>
    ${withClose.length >= 3 ? `<p class="muted legend">You beat the closing line on ${beat} of ${withClose.length} props (${Math.round((beat / withClose.length) * 100)}%). Beating the close consistently is the best sign of a sharp bettor.</p>` : ''}
    ${settled.length
      ? `<div class="record"><span class="big">${hits}-${settled.length - hits}</span><span class="muted">your record on settled props${pct === null ? '' : `, ${pct}% hits`}</span></div>`
      : '<p class="muted legend">Props are scored automatically the morning after each game.</p>'}
    <div class="chips">${chip('all', 'All')}${chip('open', 'Not settled')}${chip('done', 'Settled')}</div>
    <div class="saved-list">${rows.map(({ sv, live }) => {
      const label = `${sv.side === 'under' ? 'Under' : 'Over'} ${fmtNum(Number(sv.line))} ${sv.stat_label || sv.stat}`;
      const href = `#/${sv.sport}/p/${sv.game_id}/${encodeURIComponent(sv.player_id)}?s=${sv.stat}&l=${sv.line}&side=${sv.side}`;
      const sportName = meta.sports[sv.sport]?.short || sv.sport;
      return `<article class="saved-item ${sv.result || ''}">
        <div>
          <h3>${live ? `<a href="${href}">${esc(sv.player_name)}</a>` : esc(sv.player_name)} ${badge(sv)}</h3>
          <div class="meta">${esc(label)}${clvText(sv)}</div>
          <div class="meta">${esc(sportName)} ${esc(sv.team || '')} vs ${esc(sv.opp || '')}${live?.p.inj ? ` <span class="inj">${esc(live.p.inj)}</span>` : ''}${live || sv.result ? '' : ', waiting to be scored'}</div>
        </div>
        <button class="btn" type="button" data-remove="${sv.id}" aria-label="Remove ${esc(sv.player_name)} ${esc(label)}">Remove</button>
        ${live ? `<div class="rates">${live.rates.map(([l, hits2, n]) => {
          const p2 = pctOf([hits2, n]);
          return `<span style="${heat(p2)}"><small>${l}</small>${p2 === null ? '–' : `${p2}%`}</span>`;
        }).join('')}</div>` : ''}
      </article>`;
    }).join('')}</div>`;

  app.querySelectorAll('[data-saved]').forEach((b) => b.addEventListener('click', () => {
    ui.savedFilter = b.dataset.saved;
    renderSavedPage();
  }));
  app.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    await removeSaved(Number(b.dataset.remove));
  }));
}

// ---------- router ----------
async function route() {
  try {
    if (!meta) [meta, index] = await Promise.all([load('data/meta.json'), load('data/index.json').catch(() => null)]);
  } catch {
    app.innerHTML = `<section class="empty"><h1>No data yet</h1><p class="muted">The daily refresh hasn't produced any files. Run <code>npm run refresh</code> locally, or start the "Refresh slate" workflow in GitHub Actions.</p></section>`;
    return;
  }
  const { parts, params } = parseHash();
  if (parts[0] === 'account' || parts[0] === 'saved') {
    renderHeader(parts[0]);
    return parts[0] === 'account' ? renderAccountPage(params) : renderSavedPage();
  }
  const firstWithGames = meta.order.find((k) => index?.sports?.[k]?.games) || meta.order[0];
  const sport = meta.sports[parts[0]] ? parts[0] : firstWithGames;
  renderHeader(sport);

  try {
    if (parts[1] === 'p' && parts[2] && parts[3]) {
      await renderPlayer(sport, parts[2], parts[3], params);
    } else if (parts[1] === 'injuries') {
      await renderInjuries(sport, parts[2] === 'g' ? parts[3] : undefined);
    } else {
      const gameId = parts[1] === 'g' ? parts[2] : undefined;
      if (ui.sport !== sport) Object.assign(ui, { sport, market: '', q: '', shown: PAGE, view: 'lines' });
      ui.lastGame = gameId;
      await renderBoard(sport, gameId);
    }
  } catch (err) {
    console.error(err);
    const info = index?.sports?.[sport];
    app.innerHTML = `<section class="empty"><h1>Couldn't load ${esc(meta.sports[sport].short)}</h1>
      <p class="muted">${info?.error ? `The last refresh failed: ${esc(info.error)}` : esc(err.message)}. Try another sport, or rerun the refresh.</p></section>`;
  }
}

let lastPath = '';
window.addEventListener('hashchange', () => {
  const path = location.hash.split('?')[0];
  if (path !== lastPath) window.scrollTo(0, 0);
  lastPath = path;
  route();
});

// One-click unsubscribe from an alert email.
const unsubToken = new URLSearchParams(location.search).get('unsub');
if (unsubToken) {
  history.replaceState(null, '', `${location.pathname}#/account`);
  unsubscribeWithToken(unsubToken).then((res) => {
    ui.unsubMessage = res.ok ? 'Email alerts are off. You can turn them back on any time below.' : res.message;
    if (meta) route();
  });
}

// Invite links: ?ref=CODE opens sign-up with the code filled in.
const refParam = new URLSearchParams(location.search).get('ref');
if (refParam) {
  ui.ref = refParam.trim().toUpperCase().slice(0, 12);
  ui.authMode = 'signup';
  history.replaceState(null, '', `${location.pathname}#/account`);
}

// Shareable promo links: https://your-site/?promo=CODE opens the account page with the code filled in.
const promoParam = new URLSearchParams(location.search).get('promo');
if (promoParam) {
  ui.promo = promoParam.trim().toUpperCase().slice(0, 40);
  history.replaceState(null, '', `${location.pathname}#/account`);
}

// Stripe sends people back to ?upgraded=1 after checkout.
if (new URLSearchParams(location.search).get('upgraded') === '1') {
  ui.upgrading = true;
  history.replaceState(null, '', `${location.pathname}#/account`);
}

// Shrink the header once you start scrolling, so the list gets the screen.
let lastY = 0;
addEventListener('scroll', () => {
  const y = window.scrollY;
  if (Math.abs(y - lastY) < 12) return;
  document.body.classList.toggle('scrolled', y > 90);
  lastY = y;
}, { passive: true });

// Cloudflare Web Analytics: no cookies, no personal data. Off unless a token is set.
if (analyticsToken) {
  const beacon = document.createElement('script');
  beacon.defer = true;
  beacon.src = 'https://static.cloudflareinsights.com/beacon.min.js';
  beacon.dataset.cfBeacon = JSON.stringify({ token: analyticsToken });
  document.head.appendChild(beacon);
}

applyTheme();
document.getElementById('theme-toggle')?.addEventListener('click', toggleTheme);

// Screens that depend on who's logged in redraw when that changes.
let lastPlan = null;
onAccountChange(() => {
  const plan = isPremium() ? 'premium' : 'free';
  if (lastPlan !== null && plan !== lastPlan) {
    for (const k of [...cache.keys()]) if (k.startsWith('private:')) cache.delete(k);
    defenseCache.clear();
  }
  lastPlan = plan;
  renderAccountLink();
  if (meta) route();
});
route();
initAccount().then(() => {
  renderAccountLink();
  if (meta) route();
});
