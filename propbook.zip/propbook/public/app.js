// Propbook client. Reads the static JSON written by scripts/refresh.mjs.

const META_LEN = 6; // [date, season, opp, oppId, homeAway, result, ...values]
const WINDOWS = [
  ['l5', 'L5'],
  ['l10', 'L10'],
  ['l20', 'L20'],
  ['h2h', 'H2H'],
  ['szn', 'Season'],
];
const MAX_RECENT = 40;
const PAGE = 150;

const app = document.getElementById('app');
const cache = new Map();
let meta = null;
let index = null;
const ui = { side: 'over', sort: 'l10', market: '', q: '', shown: PAGE, win: 'l10' };

// ---------- utilities ----------
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtOdds = (p) => (p === null || p === undefined ? '' : p > 0 ? `+${p}` : `${p}`.replace('-', '−'));
const fmtNum = (v) => (v === null || v === undefined ? '–' : Number.isInteger(v) ? String(v) : v.toFixed(1));
const pctOf = ([hits, n]) => (n ? Math.round((hits / n) * 100) : null);

async function load(url) {
  if (cache.has(url)) return cache.get(url);
  const p = fetch(url, { cache: 'no-cache' }).then((r) => {
    if (!r.ok) throw new Error(`${r.status} loading ${url}`);
    return r.json();
  });
  cache.set(url, p);
  p.catch(() => cache.delete(url));
  return p;
}

function parseHash() {
  const [pathPart, query = ''] = location.hash.replace(/^#\/?/, '').split('?');
  const parts = pathPart.split('/').filter(Boolean).map(decodeURIComponent);
  const params = new URLSearchParams(query);
  return { parts, params };
}

function gameLabel(g) {
  return `${g.away.abbr} @ ${g.home.abbr}`;
}
function gameTime(g, multiDay) {
  const d = new Date(g.start);
  if (g.state === 'in') return 'Live';
  const opts = multiDay ? { weekday: 'short', hour: 'numeric', minute: '2-digit' } : { hour: 'numeric', minute: '2-digit' };
  return new Intl.DateTimeFormat(undefined, opts).format(d);
}
function heat(pct) {
  if (pct === null) return '';
  const strength = Math.min(60, Math.abs(pct - 50) * 1.2);
  const color = pct >= 50 ? 'var(--hit)' : 'var(--miss)';
  return `background: color-mix(in srgb, ${color} ${strength}%, transparent)`;
}
function photo(p, cls = '') {
  return p.img
    ? `<img class="${cls}" src="${esc(p.img)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'ph'}))">`
    : '<span class="ph"></span>';
}

// ---------- hit rates (mirrors scripts/lib/common.mjs) ----------
function windowsFor(player, season, oppId) {
  const recent = player.rows.slice(0, MAX_RECENT);
  return {
    l5: recent.slice(0, 5),
    l10: recent.slice(0, 10),
    l20: recent.slice(0, 20),
    h2h: player.rows.filter((r) => r[3] === String(oppId)),
    szn: recent.filter((r) => r[1] === season),
  };
}
function rateRows(rows, idx, line, side) {
  const vals = rows.map((r) => r[META_LEN + idx]).filter((v) => v !== null);
  const hits = vals.filter((v) => (side === 'under' ? v < line : v > line)).length;
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  return [hits, vals.length, avg];
}

// ---------- header ----------
function renderHeader(sport) {
  const nav = document.getElementById('sports');
  nav.innerHTML = meta.order
    .map((key) => {
      const s = meta.sports[key];
      const info = index?.sports?.[key];
      const count = info && !info.error ? `<span class="count">${info.games}</span>` : '';
      return `<a href="#/${key}" ${key === sport ? 'aria-current="page"' : ''}>${esc(s.short)}${count}</a>`;
    })
    .join('');
  const info = index?.sports?.[sport];
  document.getElementById('updated').textContent = info?.generatedAt
    ? `Updated ${new Intl.DateTimeFormat(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' }).format(new Date(info.generatedAt))}`
    : '';
}

// ---------- board ----------
async function renderBoard(sport, gameId) {
  const slate = await load(`data/${sport}/slate.json`);
  const s = meta.sports[sport];
  const multiDay = slate.from !== slate.until;
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  const players = new Map(slate.players.map((p) => [p.id, p]));
  const gamesById = new Map(slate.games.map((g) => [g.id, g]));

  if (!slate.games.length) {
    app.innerHTML = `<section class="empty"><h1>No ${esc(s.short)} games coming up</h1>
      <p class="muted">Nothing is on the schedule ${multiDay ? 'this week' : 'today'}. The slate rebuilds every morning, so check back tomorrow or pick another sport.</p></section>`;
    return;
  }

  const strip = `<nav class="games" aria-label="Games">
      <a class="game" href="#/${sport}" aria-current="${!gameId}"><strong>All games</strong><span>${slate.games.length} on the slate</span></a>
      ${slate.games
        .map(
          (g) => `<a class="game" href="#/${sport}/g/${g.id}" aria-current="${g.id === gameId}">
            <strong>${esc(gameLabel(g))}</strong><span>${esc(gameTime(g, multiDay))}</span></a>`,
        )
        .join('')}
    </nav>`;

  if (!slate.props.length) {
    renderRoster(slate, s, gameId, strip, players, gamesById, sport);
    return;
  }

  const markets = [...new Set(slate.props.map((p) => p.stat))];
  const q = ui.q.trim().toLowerCase();
  const sortKey = ui.sort;

  let rows = slate.props
    .filter((pr) => (!gameId || pr.gameId === gameId) && (!ui.market || pr.stat === ui.market))
    .map((pr) => {
      const p = players.get(pr.pid);
      if (!p) return null;
      const rates = {};
      for (const [w] of WINDOWS) {
        const [hits, n, avg] = pr.hr?.[w] || [0, 0, null];
        const h = ui.side === 'under' ? n - hits - pushes(pr, w) : hits;
        rates[w] = { hits: h, n, avg, pct: n ? Math.round((h / n) * 100) : null };
      }
      return { pr, p, rates };
    })
    .filter((r) => r && (!q || r.p.name.toLowerCase().includes(q) || r.p.team.toLowerCase() === q));

  rows.sort((a, b) => {
    if (sortKey === 'edge') {
      const ea = ((a.rates.l10.avg ?? a.pr.line) - a.pr.line) * (ui.side === 'under' ? -1 : 1);
      const eb = ((b.rates.l10.avg ?? b.pr.line) - b.pr.line) * (ui.side === 'under' ? -1 : 1);
      return eb - ea;
    }
    const pa = a.rates[sortKey].pct ?? -1;
    const pb = b.rates[sortKey].pct ?? -1;
    return pb - pa || b.rates[sortKey].n - a.rates[sortKey].n;
  });

  const total = rows.length;
  rows = rows.slice(0, ui.shown);
  const sortHead = (key, label) =>
    `<th class="num" ${sortKey === key ? 'aria-sort="descending"' : ''}><button data-sort="${key}">${label}</button></th>`;

  app.innerHTML = `
    ${strip}
    <div class="toolbar">
      <label class="visually-hidden" for="q">Search players</label>
      <input id="q" type="search" placeholder="Search player or team" value="${esc(ui.q)}" autocomplete="off">
      <label class="visually-hidden" for="market">Market</label>
      <select id="market">
        <option value="">All markets</option>
        ${markets.map((m) => `<option value="${m}" ${m === ui.market ? 'selected' : ''}>${esc(statLabel[m] || m)}</option>`).join('')}
      </select>
      <label class="visually-hidden" for="sort">Sort by</label>
      <select id="sort" class="narrow-only">
        ${[...WINDOWS, ['edge', 'L10 avg']].map(([k, l]) => `<option value="${k}" ${k === sortKey ? 'selected' : ''}>Sort: ${k === 'edge' ? 'avg vs line' : `${l} hit %`}</option>`).join('')}
      </select>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${ui.side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${ui.side === 'under'}">Under</button>
      </div>
    </div>
    ${total ? '' : '<p class="note">No lines match. Clear the search or pick another market.</p>'}
    <div class="board-wrap">
      <table class="board">
        <thead><tr>
          <th scope="col">Player</th><th scope="col">Market</th><th scope="col" class="num">Line</th>
          ${sortHead('l5', 'L5')}${sortHead('l10', 'L10')}${sortHead('l20', 'L20')}${sortHead('h2h', 'H2H')}${sortHead('szn', 'Season')}
          ${sortHead('edge', 'L10 avg')}
        </tr></thead>
        <tbody>
          ${rows
            .map(({ pr, p, rates }) => {
              const g = gamesById.get(pr.gameId);
              const href = `#/${sport}/p/${pr.gameId}/${encodeURIComponent(p.id)}?s=${pr.stat}&l=${pr.line}&side=${ui.side}`;
              const best = bestPrice(pr, ui.side);
              return `<tr data-href="${href}">
                <td><div class="who">${photo(p)}<div><a href="${href}">${esc(p.name)}</a>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}
                  <small>${esc(p.pos)} ${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}${g && multiDay ? `, ${esc(gameTime(g, true))}` : ''}</small></div></div></td>
                <td>${esc(statLabel[pr.stat] || pr.stat)}</td>
                <td class="num"><span class="line-cell">${ui.side === 'over' ? 'O' : 'U'} ${fmtNum(pr.line)}</span>${best ? `<small class="muted" style="display:block">${esc(best)}</small>` : ''}</td>
                ${WINDOWS.map(([w]) => {
                  const r = rates[w];
                  return `<td class="num" data-w="${WINDOWS.find((x) => x[0] === w)[1]}"><span class="rate" style="${heat(r.pct)}">${r.pct === null ? '–' : `${r.pct}%`}<small>${r.n ? `${r.hits}/${r.n}` : 'no games'}</small></span></td>`;
                }).join('')}
                <td class="num" data-w="L10 avg"><span class="line-cell">${fmtNum(rates.l10.avg)}</span></td>
              </tr>`;
            })
            .join('')}
        </tbody>
      </table>
    </div>
    ${total > rows.length ? `<button class="btn more" id="more">Show ${Math.min(PAGE, total - rows.length)} more of ${total - rows.length}</button>` : ''}
    ${slate.oddsNote ? `<p class="note">${esc(slate.oddsNote)}</p>` : ''}
  `;

  const q$ = document.getElementById('q');
  q$.addEventListener('input', () => {
    ui.q = q$.value;
    ui.shown = PAGE;
    const pos = q$.selectionStart;
    renderBoard(sport, gameId).then(() => {
      const el = document.getElementById('q');
      el.focus();
      el.setSelectionRange(pos, pos);
    });
  });
  document.getElementById('market').addEventListener('change', (e) => {
    ui.market = e.target.value;
    ui.shown = PAGE;
    renderBoard(sport, gameId);
  });
  document.getElementById('sort').addEventListener('change', (e) => {
    ui.sort = e.target.value;
    renderBoard(sport, gameId);
  });
  app.querySelectorAll('[data-side]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.side = b.dataset.side;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('[data-sort]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.sort = b.dataset.sort;
      renderBoard(sport, gameId);
    }),
  );
  app.querySelectorAll('tr[data-href]').forEach((tr) =>
    tr.addEventListener('click', (e) => {
      if (e.target.closest('a')) return;
      location.hash = tr.dataset.href;
    }),
  );
  document.getElementById('more')?.addEventListener('click', () => {
    ui.shown += PAGE;
    renderBoard(sport, gameId);
  });
}

// Precomputed rates count over hits; under hits exclude games that landed exactly on the line.
function pushes(pr, w) {
  return pr.hr?.[w]?.[3] ?? 0;
}

function bestPrice(pr, side) {
  const key = side === 'under' ? 'under' : 'over';
  const same = pr.books.filter((b) => b.line === pr.line && b[key] !== null);
  if (!same.length) return '';
  const best = same.reduce((a, b) => (b[key] > a[key] ? b : a));
  return `${fmtOdds(best[key])} ${best.book}`;
}

function renderRoster(slate, s, gameId, strip, players, gamesById, sport) {
  const list = slate.players.filter((p) => !gameId || p.gameId === gameId);
  const byTeam = new Map();
  for (const p of list) {
    const k = `${p.gameId}|${p.team}`;
    if (!byTeam.has(k)) byTeam.set(k, []);
    byTeam.get(k).push(p);
  }
  const statLabel = Object.fromEntries(s.stats.map((x) => [x.key, x.label]));
  app.innerHTML = `
    ${strip}
    <p class="note">No sportsbook lines in this refresh${slate.oddsNote ? ` (${esc(slate.oddsNote)})` : ''}. Numbers are last-10-game averages. Open a player to set your own line.</p>
    ${[...byTeam.entries()]
      .map(([k, ps]) => {
        const [gid, team] = k.split('|');
        const g = gamesById.get(gid);
        ps.sort((a, b) => b.gp - a.gp);
        return `<div class="team-head"><h2>${esc(team)}</h2><span class="muted">${g ? esc(gameLabel(g)) : ''}</span></div>
          <div class="roster">${ps
            .map(
              (p) => `<a href="#/${sport}/p/${p.gameId}/${encodeURIComponent(p.id)}">
                <div class="who">${photo(p)}<div><b>${esc(p.name)}</b>${p.inj ? `<span class="inj">${esc(p.inj)}</span>` : ''}<small>${esc(p.pos)}</small></div></div>
                <div class="avgs">${Object.entries(p.avg)
                  .map(([k2, v]) => `<div><b>${fmtNum(v)}</b><span>${esc(shortLabel(statLabel[k2] || k2))}</span></div>`)
                  .join('')}</div></a>`,
            )
            .join('')}</div>`;
      })
      .join('')}`;
}
const shortLabel = (label) => label.replace('Passing yards', 'Pass yds').replace('Rushing yards', 'Rush yds').replace('Receiving yards', 'Rec yds').replace('Total bases', 'TB').replace('Hits + Runs + RBIs', 'H+R+RBI');

// ---------- player ----------
async function renderPlayer(sport, gameId, pid, params) {
  const [slate, game] = await Promise.all([load(`data/${sport}/slate.json`), load(`data/${sport}/games/${gameId}.json`)]);
  const s = meta.sports[sport];
  const p = game.players.find((x) => x.id === pid);
  const back = `<a class="back" href="#/${sport}${ui.lastGame ? `/g/${ui.lastGame}` : ''}">← Back to ${esc(s.short)} board</a>`;
  if (!p) {
    app.innerHTML = `${back}<section class="empty"><h1>Player not on this slate</h1><p class="muted">The slate has been rebuilt since this link was made. Go back to the board to find them.</p></section>`;
    return;
  }
  const g = slate.games.find((x) => x.id === gameId);
  const statDefs = s.stats.filter((x) => p.cols.includes(x.key));
  const props = slate.props.filter((x) => x.pid === pid);
  const stat = p.cols.includes(params.get('s')) ? params.get('s') : props[0]?.stat || (s.headline[p.role] || s.headline.all || [p.cols[0]])[0];
  const idx = p.cols.indexOf(stat);
  const prop = props.find((x) => x.stat === stat);
  const side = params.get('side') === 'under' ? 'under' : 'over';
  const wins = windowsFor(p, slate.season, p.oppId);

  let line = Number(params.get('l'));
  if (!params.has('l') || Number.isNaN(line)) {
    if (prop) line = prop.line;
    else {
      const avg = rateRows(wins.l10, idx, 0, 'over')[2];
      line = avg === null ? 0.5 : Math.max(0.5, Math.round(avg) - 0.5);
    }
  }
  const win = ui.win;

  const setParams = (changes) => {
    const next = new URLSearchParams({ s: stat, l: String(line), side, ...changes });
    history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
    renderPlayer(sport, gameId, pid, next);
  };

  const tiles = WINDOWS.map(([w, label]) => {
    const [hits, n, avg] = rateRows(wins[w], idx, line, side);
    const pct = pctOf([hits, n]);
    const cls = pct === null ? '' : pct >= 60 ? 'good' : pct < 40 ? 'bad' : '';
    return `<button class="tile ${cls}" data-win="${w}" aria-pressed="${w === win}">
      <span class="w">${label}</span><span class="pct">${pct === null ? '–' : `${pct}%`}</span>
      <span class="sub">${n ? `${hits} of ${n}` : 'No games'}</span><span class="sub">${avg === null ? '' : `avg ${fmtNum(Math.round(avg * 10) / 10)}`}</span>
    </button>`;
  }).join('');

  const chartRows = [...wins[win]].reverse().filter((r) => r[META_LEN + idx] !== null);
  const statLabel = statDefs.find((x) => x.key === stat)?.label || stat;

  const cols = (s.logCols[p.role] || s.logCols.all || p.cols).filter((c) => p.cols.includes(c));
  if (!cols.includes(stat)) cols.unshift(stat);
  const labelFor = (k) => abbrev(k, s.stats);

  app.innerHTML = `
    ${back}
    <header class="player-head">
      ${photo(p)}
      <div>
        <h1>${esc(p.name)}${p.inj ? ` <span class="inj">${esc(p.inj)}</span>` : ''}</h1>
        <p><span>${esc(p.pos)}</span> <span class="matchup">${esc(p.team)} ${p.home ? 'vs' : '@'} ${esc(p.opp)}</span>
        ${g ? `<span>${esc(gameTime(g, slate.from !== slate.until))}</span>` : ''}</p>
      </div>
    </header>

    <div class="stat-tabs" role="group" aria-label="Stat">
      ${statDefs
        .map((d) => `<button data-stat="${d.key}" aria-pressed="${d.key === stat}" class="${props.some((x) => x.stat === d.key) ? 'has-line' : ''}">${esc(d.label)}</button>`)
        .join('')}
    </div>

    <div class="line-row">
      <div class="line-ctl">
        <button data-step="-0.5" aria-label="Lower line">−</button>
        <label><span>${esc(statLabel)}</span><input id="line" type="number" inputmode="decimal" step="0.5" min="0" value="${line}"></label>
        <button data-step="0.5" aria-label="Raise line">+</button>
      </div>
      <div class="seg" role="group" aria-label="Side">
        <button data-side="over" aria-pressed="${side === 'over'}">Over</button>
        <button data-side="under" aria-pressed="${side === 'under'}">Under</button>
      </div>
      ${
        prop
          ? `<div class="books">${prop.books
              .map(
                (b) => `<button class="book" data-line="${b.line}" aria-pressed="${b.line === line}">
                  <b>${esc(b.book)} ${fmtNum(b.line)}</b><span>O ${fmtOdds(b.over) || '–'} U ${fmtOdds(b.under) || '–'}</span></button>`,
              )
              .join('')}</div>`
          : '<span class="muted">No sportsbook line for this stat. Set your own.</span>'
      }
    </div>

    <div class="tiles">${tiles}</div>

    <figure class="chart" style="margin:0">
      <figcaption class="caption"><span>${esc(statLabel)}, ${WINDOWS.find((w) => w[0] === win)[1]} ${win === 'h2h' ? `vs ${esc(p.opp)}` : 'games'}</span>
        <span class="muted">${side === 'over' ? 'Over' : 'Under'} ${fmtNum(line)}</span></figcaption>
      ${chartRows.length ? barChart(chartRows, idx, line, side) : `<p class="muted" style="padding:0 8px">No ${win === 'h2h' ? `games against ${esc(p.opp)}` : 'games'} in the last two seasons.</p>`}
    </figure>

    ${p.bvp ? `<section class="bvp"><h3>Career vs ${esc(p.bvp.pitcher)}</h3>
      <div><b>${p.bvp.h}-${p.bvp.ab}</b>hits</div><div><b>${esc(p.bvp.avg)}</b>avg</div><div><b>${p.bvp.hr}</b>HR</div>
      <div><b>${p.bvp.bb}</b>BB</div><div><b>${p.bvp.so}</b>K</div><div><b>${esc(p.bvp.ops)}</b>OPS</div></section>` : ''}

    <section class="log">
      <h2>Game log</h2>
      <div class="log-wrap"><table class="gl">
        <thead><tr><th>Date</th><th>Opp</th><th>Result</th>${cols.map((c) => `<th ${c === stat ? 'class="sel"' : ''} title="${esc(s.stats.find((x) => x.key === c)?.label || c)}">${esc(labelFor(c))}</th>`).join('')}</tr></thead>
        <tbody>${p.rows
          .slice(0, ui.fullLog ? p.rows.length : 20)
          .map((r) => {
            const v = r[META_LEN + idx];
            const hit = v === null || v === line ? '' : (side === 'under' ? v < line : v > line) ? 'h' : 'm';
            return `<tr class="${r[3] === String(p.oppId) ? 'h2h' : ''}"><td>${esc(shortDate(r[0]))}</td><td>${esc(r[4])} ${esc(r[2])}</td><td>${esc(r[5])}</td>
              ${cols.map((c) => {
                const val = r[META_LEN + p.cols.indexOf(c)];
                return `<td class="${c === stat ? `sel ${hit}` : ''}">${fmtNum(val)}</td>`;
              }).join('')}</tr>`;
          })
          .join('')}</tbody>
      </table></div>
      ${p.rows.length > 20 ? `<button class="btn more" id="full-log">${ui.fullLog ? 'Show last 20 games' : `Show all ${p.rows.length} games`}</button>` : ''}
    </section>
  `;

  app.querySelectorAll('[data-stat]').forEach((b) =>
    b.addEventListener('click', () => {
      const pr = props.find((x) => x.stat === b.dataset.stat);
      const next = new URLSearchParams({ s: b.dataset.stat, side });
      if (pr) next.set('l', pr.line);
      history.replaceState(null, '', `#/${sport}/p/${gameId}/${encodeURIComponent(pid)}?${next}`);
      renderPlayer(sport, gameId, pid, next);
    }),
  );
  app.querySelectorAll('[data-step]').forEach((b) =>
    b.addEventListener('click', () => setParams({ l: String(Math.max(0, line + Number(b.dataset.step))) })),
  );
  const input = document.getElementById('line');
  input.addEventListener('change', () => {
    const v = Number(input.value);
    if (!Number.isNaN(v) && v >= 0) setParams({ l: String(v) });
  });
  app.querySelectorAll('[data-side]').forEach((b) => b.addEventListener('click', () => setParams({ side: b.dataset.side })));
  app.querySelectorAll('[data-line]').forEach((b) => b.addEventListener('click', () => setParams({ l: b.dataset.line })));
  document.getElementById('full-log')?.addEventListener('click', () => {
    ui.fullLog = !ui.fullLog;
    setParams({});
  });
  app.querySelectorAll('[data-win]').forEach((b) =>
    b.addEventListener('click', () => {
      ui.win = b.dataset.win;
      setParams({});
    }),
  );
}

function abbrev(key, stats) {
  const map = {
    min: 'MIN', pts: 'PTS', reb: 'REB', ast: 'AST', fg3m: '3PM', stl: 'STL', blk: 'BLK', tov: 'TO', pra: 'PRA', pr: 'PR', pa: 'PA', ra: 'RA',
    stocks: 'STK', fgm: 'FGM', fga: 'FGA', fg3a: '3PA', ftm: 'FTM',
    cmp: 'CMP', passAtt: 'ATT', passYds: 'PYDS', passTd: 'PTD', int: 'INT', passLng: 'LNG', rushAtt: 'CAR', rushYds: 'RYDS', rushLng: 'RLNG',
    rec: 'REC', tgt: 'TGT', recYds: 'RECYDS', recLng: 'RECLNG', rushRecYds: 'R+R', passRushYds: 'P+R', tds: 'TD', tkl: 'TKL', solo: 'SOLO',
    sacks: 'SACK', defInt: 'INT', pd: 'PD', xpm: 'XP', kpts: 'KPTS',
    h: 'H', tb: 'TB', hrr: 'H+R+RBI', hr: 'HR', rbi: 'RBI', r: 'R', singles: '1B', doubles: '2B', bb: 'BB', so: 'K', sb: 'SB', ab: 'AB',
    pK: 'K', pOuts: 'OUTS', pH: 'H', pER: 'ER', pBB: 'BB', pitches: 'PC',
  };
  return map[key] || stats.find((s) => s.key === key)?.label || key;
}

function shortDate(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  const thisYear = new Date().getFullYear();
  return `${m}/${d}${y !== thisYear ? `/${String(y).slice(2)}` : ''}`;
}

function barChart(rows, idx, line, side) {
  const available = Math.max(320, (app.clientWidth || 700) - 20);
  const W = Math.max(available, rows.length * 30 + 48);
  const H = 230;
  const top = 22;
  const bottom = 34;
  const left = 8;
  const right = 40;
  const vals = rows.map((r) => r[META_LEN + idx]);
  const max = Math.max(line, ...vals, 1) * 1.15;
  const plotH = H - top - bottom;
  const y = (v) => top + plotH - (v / max) * plotH;
  const slot = (W - left - right) / rows.length;
  const bw = Math.min(38, slot * 0.66);

  const bars = rows
    .map((r, i) => {
      const v = r[META_LEN + idx];
      const hit = side === 'under' ? v < line : v > line;
      const cls = v === line ? 'bar-push' : hit ? 'bar-hit' : 'bar-miss';
      const x = left + i * slot + (slot - bw) / 2;
      const h = Math.max(2, top + plotH - y(v));
      const cx = x + bw / 2;
      return `<g><title>${esc(r[0])} ${esc(r[4])} ${esc(r[2])}: ${fmtNum(v)}</title>
        <rect class="bar ${cls}" x="${x.toFixed(1)}" y="${(top + plotH - h).toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="2"/>
        <text class="bar-val" x="${cx.toFixed(1)}" y="${(top + plotH - h - 5).toFixed(1)}">${fmtNum(v)}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 15}">${esc(r[2])}</text>
        <text class="bar-lbl" x="${cx.toFixed(1)}" y="${H - bottom + 28}">${esc(shortDate(r[0]))}</text></g>`;
    })
    .join('');
  const ly = y(line).toFixed(1);
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Game by game results against the line">
    <line class="axis" x1="${left}" x2="${W - right}" y1="${top + plotH}" y2="${top + plotH}"/>
    ${bars}
    <line class="line-rule" x1="${left}" x2="${W - right + 4}" y1="${ly}" y2="${ly}"/>
    <text class="line-tag" x="${W - right + 8}" y="${Number(ly) + 5}">${fmtNum(line)}</text>
  </svg>`;
}

// ---------- router ----------
async function route() {
  try {
    if (!meta) [meta, index] = await Promise.all([load('data/meta.json'), load('data/index.json').catch(() => null)]);
  } catch {
    app.innerHTML = `<section class="empty"><h1>No data yet</h1><p class="muted">The daily refresh hasn't produced any files. Run <code>npm run refresh</code> locally, or start the "Refresh slate" workflow in GitHub Actions.</p></section>`;
    return;
  }
  const { parts, params } = parseHash();
  const firstWithGames = meta.order.find((k) => index?.sports?.[k]?.games) || meta.order[0];
  const sport = meta.sports[parts[0]] ? parts[0] : firstWithGames;
  renderHeader(sport);

  try {
    if (parts[1] === 'p' && parts[2] && parts[3]) {
      await renderPlayer(sport, parts[2], parts[3], params);
    } else {
      const gameId = parts[1] === 'g' ? parts[2] : undefined;
      if (ui.sport !== sport) Object.assign(ui, { sport, market: '', q: '', shown: PAGE });
      ui.lastGame = gameId;
      await renderBoard(sport, gameId);
    }
  } catch (err) {
    console.error(err);
    const info = index?.sports?.[sport];
    app.innerHTML = `<section class="empty"><h1>Couldn't load ${esc(meta.sports[sport].short)}</h1>
      <p class="muted">${info?.error ? `The last refresh failed: ${esc(info.error)}` : esc(err.message)}. Try another sport, or rerun the refresh.</p></section>`;
  }
}

let lastPath = '';
window.addEventListener('hashchange', () => {
  const path = location.hash.split('?')[0];
  if (path !== lastPath) window.scrollTo(0, 0);
  lastPath = path;
  route();
});
route();
