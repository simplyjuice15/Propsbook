// Accounts and saved props, backed by Supabase. Everything here is optional:
// when public/config.js has no Supabase settings, the site runs without accounts.
import config from './config.js';

const SUPABASE_ESM = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const configured = Boolean(config.supabaseUrl && config.supabaseAnonKey);

export const account = {
  // Set once accounts are connected; stays true even if the login service fails to load,
  // so Premium content can't be unlocked by blocking that service.
  configured,
  enabled: configured,
  ready: false,
  user: null,
  plan: 'free',
  subscription: { status: '', periodEnd: '' },
  paid: false, // premium through Stripe (or set by hand in the plan column)
  comp: null, // { until, note } when premium comes from a promo code or a complimentary grant
  alerts: { supported: false, enabled: true, injury: true, line: true },
  saved: [],
  recovering: false,
  error: '',
};

let client = null;
const listeners = new Set();
export const onAccountChange = (fn) => listeners.add(fn);
const emit = () => listeners.forEach((fn) => fn(account));

const siteUrl = () => `${location.origin}${location.pathname}`;
export const isPremium = () => Boolean(account.user) && account.plan === 'premium';

export async function initAccount() {
  if (!account.enabled) {
    account.ready = true;
    return account;
  }
  try {
    const { createClient } = await import(SUPABASE_ESM);
    client = createClient(config.supabaseUrl, config.supabaseAnonKey, {
      auth: { flowType: 'pkce', persistSession: true, detectSessionInUrl: true, autoRefreshToken: true },
    });
    const { data } = await client.auth.getSession();
    await setUser(data?.session?.user || null);
    client.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY') account.recovering = true;
      // Supabase asks us not to await other Supabase calls inside this callback.
      setTimeout(async () => {
        await setUser(session?.user || null);
        emit();
      }, 0);
    });
  } catch (err) {
    console.error(err);
    account.enabled = false;
    account.error = 'Accounts are unavailable right now.';
  }
  // Remove the one-time login code from the address bar after email links.
  if (/[?&]code=/.test(location.search)) history.replaceState(null, '', `${location.pathname}${location.hash}`);
  account.ready = true;
  return account;
}

async function setUser(user) {
  account.user = user;
  account.plan = 'free';
  account.subscription = { status: '', periodEnd: '' };
  account.paid = false;
  account.comp = null;
  account.alerts = { supported: false, enabled: true, injury: true, line: true };
  account.saved = [];
  if (!user || !client) return;
  // Newer columns first; fall back if the matching SQL hasn't been run yet.
  let profile = null;
  for (const cols of [
    'plan, subscription_status, current_period_end, comp_until, comp_note, alerts_enabled, alerts_injury, alerts_line',
    'plan, subscription_status, current_period_end, comp_until, comp_note',
    'plan, subscription_status, current_period_end',
    'plan',
  ]) {
    const { data, error } = await client.from('profiles').select(cols).eq('id', user.id).maybeSingle();
    if (!error) {
      profile = data;
      break;
    }
  }
  const compActive = Boolean(profile?.comp_until) && Date.parse(profile.comp_until) > Date.now();
  account.paid = profile?.plan === 'premium';
  account.plan = account.paid || compActive ? 'premium' : 'free';
  account.comp = compActive ? { until: profile.comp_until, note: profile.comp_note || '' } : null;
  account.subscription = { status: profile?.subscription_status || '', periodEnd: profile?.current_period_end || '' };
  account.alerts = {
    supported: profile ? 'alerts_enabled' in profile : false,
    enabled: profile?.alerts_enabled !== false,
    injury: profile?.alerts_injury !== false,
    line: profile?.alerts_line !== false,
  };
  if (account.plan === 'premium') await loadSaved();
}

async function loadSaved() {
  const { data, error } = await client.from('saved_props').select('*').order('created_at', { ascending: false });
  if (!error) account.saved = data || [];
}

const friendly = (error) => {
  const msg = error?.message || String(error || 'Something went wrong');
  if (/row-level security|violates/i.test(msg)) return 'Saving props is a Premium feature.';
  if (/Invalid login credentials/i.test(msg)) return 'That email and password don’t match an account.';
  if (/Email not confirmed/i.test(msg)) return 'Confirm your email first. Check your inbox for the link.';
  if (/already registered/i.test(msg)) return 'An account with that email already exists. Log in instead.';
  return msg;
};
const result = (error, extra = {}) => (error ? { ok: false, message: friendly(error) } : { ok: true, ...extra });

export async function signUp(email, password, { ageConfirmed = false, referredBy = '' } = {}) {
  const { data, error } = await client.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: siteUrl(),
      data: { age_confirmed: ageConfirmed ? 'true' : 'false', referred_by: referredBy || '' },
    },
  });
  return result(error, { needsConfirmation: !data?.session });
}
export async function signIn(email, password) {
  const { error } = await client.auth.signInWithPassword({ email, password });
  return result(error);
}
export async function signOut() {
  await client.auth.signOut();
  await setUser(null);
  emit();
}
export async function sendPasswordReset(email) {
  const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo: siteUrl() });
  return result(error);
}
export async function setNewPassword(password) {
  const { error } = await client.auth.updateUser({ password });
  if (!error) account.recovering = false;
  return result(error);
}
export async function deleteAccount() {
  const { error } = await client.rpc('delete_my_account');
  if (error) return result(error);
  await signOut();
  return { ok: true };
}
export async function refreshPlan() {
  if (account.user) await setUser(account.user);
  emit();
}

// ---------- email alerts ----------
export async function saveAlertPrefs(next) {
  if (!account.user) return { ok: false, message: 'Log in first.' };
  const { error } = await client.rpc('set_alert_prefs', { enabled: next.enabled, injury: next.injury, line: next.line });
  if (error) return { ok: false, message: /function .*set_alert_prefs|does not exist/i.test(error.message) ? 'Alerts aren’t turned on for this site yet.' : friendly(error) };
  account.alerts = { ...account.alerts, ...next, supported: true };
  emit();
  return { ok: true };
}

/** Called from the one-click link in every alert email; no login needed. */
export async function unsubscribeWithToken(token) {
  if (!account.enabled) return { ok: false, message: 'Accounts aren’t available.' };
  if (!client) {
    const { createClient } = await import(SUPABASE_ESM);
    client = createClient(config.supabaseUrl, config.supabaseAnonKey, { auth: { persistSession: false } });
  }
  const { data, error } = await client.rpc('unsubscribe_alerts', { token });
  if (error) return { ok: false, message: friendly(error) };
  return data ? { ok: true } : { ok: false, message: 'That link has already been used, or it isn’t valid.' };
}

// ---------- promo codes ----------
export async function redeemPromo(code) {
  const clean = String(code || '').trim();
  if (!clean) return { ok: false, message: 'Enter a promo code.' };
  if (!account.user) return { ok: false, message: 'Log in to use a promo code.' };
  const { data, error } = await client.rpc('redeem_promo', { promo: clean });
  if (error) return { ok: false, message: /function .*redeem_promo|does not exist/i.test(error.message) ? 'Promo codes aren’t turned on yet.' : friendly(error) };
  if (!data?.ok) return { ok: false, message: data?.message || 'That code isn’t valid.' };
  await setUser(account.user);
  emit();
  return { ok: true, until: data.until, days: data.days };
}

// ---------- saved props ----------
export const savedKey = (p) => [p.sport, p.game_id, p.player_id, p.stat, Number(p.line), p.side].join('|');
export const findSaved = (p) => account.saved.find((s) => savedKey(s) === savedKey(p)) || null;

export async function saveProp(prop) {
  if (!account.user) return { ok: false, message: 'Log in to save props.' };
  if (!isPremium()) return { ok: false, message: 'Saving props is a Premium feature.' };
  const { data, error } = await client.from('saved_props').insert(prop).select().single();
  if (error && /duplicate/i.test(error.message)) return { ok: true };
  if (error) return result(error);
  account.saved.unshift(data);
  emit();
  return { ok: true };
}
export async function removeSaved(id) {
  const { error } = await client.from('saved_props').delete().eq('id', id);
  if (error) return result(error);
  account.saved = account.saved.filter((s) => s.id !== id);
  emit();
  return { ok: true };
}

// ---------- payments (Stripe Payment Links) ----------
export const payments = {
  monthly: config.stripeMonthlyLink || '',
  yearly: config.stripeYearlyLink || '',
  portal: config.stripePortalLink || '',
  monthlyPrice: config.monthlyPrice || '',
  yearlyPrice: config.yearlyPrice || '',
};
payments.enabled = Boolean(payments.monthly || payments.yearly);

/** Stripe checkout link tagged with this account, so the payment finds the right person. */
export function checkoutUrl(link) {
  if (!link || !account.user) return '';
  const u = new URL(link);
  u.searchParams.set('client_reference_id', account.user.id);
  if (account.user.email) u.searchParams.set('prefilled_email', account.user.email);
  return u.toString();
}
export function portalUrl() {
  if (!payments.portal) return '';
  const u = new URL(payments.portal);
  if (account.user?.email) u.searchParams.set('prefilled_email', account.user.email);
  return u.toString();
}

// ---------- Premium data, served privately ----------
/** Read a file from the private Premium bucket. Only Premium accounts are allowed. */
export async function premiumDownload(path) {
  if (!client || !account.user) throw new Error('not signed in');
  const { data, error } = await client.storage.from('premium').download(path);
  if (error) throw new Error(error.message || 'download failed');
  return JSON.parse(await data.text());
}

// ---------- referrals ----------
export async function myReferrals() {
  if (!client || !account.user) return null;
  const { data, error } = await client.rpc('my_referrals');
  return error ? null : data;
}

export const analyticsToken = config.cfAnalyticsToken || '';
