// Accounts and saved props, backed by Supabase. Everything here is optional:
// when public/config.js has no Supabase settings, the site runs without accounts.
import config from './config.js';

const SUPABASE_ESM = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const configured = Boolean(config.supabaseUrl && config.supabaseAnonKey);

export const account = {
  // Set once accounts are connected; stays true even if the login service fails to load,
  // so Premium content can't be unlocked by blocking that service.
  configured,
  enabled: configured,
  ready: false,
  user: null,
  plan: 'free',
  subscription: { status: '', periodEnd: '' },
  saved: [],
  recovering: false,
  error: '',
};

let client = null;
const listeners = new Set();
export const onAccountChange = (fn) => listeners.add(fn);
const emit = () => listeners.forEach((fn) => fn(account));

const siteUrl = () => `${location.origin}${location.pathname}`;
export const isPremium = () => Boolean(account.user) && account.plan === 'premium';

export async function initAccount() {
  if (!account.enabled) {
    account.ready = true;
    return account;
  }
  try {
    const { createClient } = await import(SUPABASE_ESM);
    client = createClient(config.supabaseUrl, config.supabaseAnonKey, {
      auth: { flowType: 'pkce', persistSession: true, detectSessionInUrl: true, autoRefreshToken: true },
    });
    const { data } = await client.auth.getSession();
    await setUser(data?.session?.user || null);
    client.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY') account.recovering = true;
      // Supabase asks us not to await other Supabase calls inside this callback.
      setTimeout(async () => {
        await setUser(session?.user || null);
        emit();
      }, 0);
    });
  } catch (err) {
    console.error(err);
    account.enabled = false;
    account.error = 'Accounts are unavailable right now.';
  }
  // Remove the one-time login code from the address bar after email links.
  if (/[?&]code=/.test(location.search)) history.replaceState(null, '', `${location.pathname}${location.hash}`);
  account.ready = true;
  return account;
}

async function setUser(user) {
  account.user = user;
  account.plan = 'free';
  account.subscription = { status: '', periodEnd: '' };
  account.saved = [];
  if (!user || !client) return;
  let { data: profile, error } = await client.from('profiles').select('plan, subscription_status, current_period_end').eq('id', user.id).maybeSingle();
  if (error) ({ data: profile } = await client.from('profiles').select('plan').eq('id', user.id).maybeSingle()); // payments.sql not run yet
  account.plan = profile?.plan === 'premium' ? 'premium' : 'free';
  account.subscription = { status: profile?.subscription_status || '', periodEnd: profile?.current_period_end || '' };
  if (account.plan === 'premium') await loadSaved();
}

async function loadSaved() {
  const { data, error } = await client.from('saved_props').select('*').order('created_at', { ascending: false });
  if (!error) account.saved = data || [];
}

const friendly = (error) => {
  const msg = error?.message || String(error || 'Something went wrong');
  if (/row-level security|violates/i.test(msg)) return 'Saving props is a Premium feature.';
  if (/Invalid login credentials/i.test(msg)) return 'That email and password don’t match an account.';
  if (/Email not confirmed/i.test(msg)) return 'Confirm your email first. Check your inbox for the link.';
  if (/already registered/i.test(msg)) return 'An account with that email already exists. Log in instead.';
  return msg;
};
const result = (error, extra = {}) => (error ? { ok: false, message: friendly(error) } : { ok: true, ...extra });

export async function signUp(email, password) {
  const { data, error } = await client.auth.signUp({ email, password, options: { emailRedirectTo: siteUrl() } });
  return result(error, { needsConfirmation: !data?.session });
}
export async function signIn(email, password) {
  const { error } = await client.auth.signInWithPassword({ email, password });
  return result(error);
}
export async function signOut() {
  await client.auth.signOut();
  await setUser(null);
  emit();
}
export async function sendPasswordReset(email) {
  const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo: siteUrl() });
  return result(error);
}
export async function setNewPassword(password) {
  const { error } = await client.auth.updateUser({ password });
  if (!error) account.recovering = false;
  return result(error);
}
export async function deleteAccount() {
  const { error } = await client.rpc('delete_my_account');
  if (error) return result(error);
  await signOut();
  return { ok: true };
}
export async function refreshPlan() {
  if (account.user) await setUser(account.user);
  emit();
}

// ---------- saved props ----------
export const savedKey = (p) => [p.sport, p.game_id, p.player_id, p.stat, Number(p.line), p.side].join('|');
export const findSaved = (p) => account.saved.find((s) => savedKey(s) === savedKey(p)) || null;

export async function saveProp(prop) {
  if (!account.user) return { ok: false, message: 'Log in to save props.' };
  if (!isPremium()) return { ok: false, message: 'Saving props is a Premium feature.' };
  const { data, error } = await client.from('saved_props').insert(prop).select().single();
  if (error && /duplicate/i.test(error.message)) return { ok: true };
  if (error) return result(error);
  account.saved.unshift(data);
  emit();
  return { ok: true };
}
export async function removeSaved(id) {
  const { error } = await client.from('saved_props').delete().eq('id', id);
  if (error) return result(error);
  account.saved = account.saved.filter((s) => s.id !== id);
  emit();
  return { ok: true };
}

// ---------- payments (Stripe Payment Links) ----------
export const payments = {
  monthly: config.stripeMonthlyLink || '',
  yearly: config.stripeYearlyLink || '',
  portal: config.stripePortalLink || '',
  monthlyPrice: config.monthlyPrice || '',
  yearlyPrice: config.yearlyPrice || '',
};
payments.enabled = Boolean(payments.monthly || payments.yearly);

/** Stripe checkout link tagged with this account, so the payment finds the right person. */
export function checkoutUrl(link) {
  if (!link || !account.user) return '';
  const u = new URL(link);
  u.searchParams.set('client_reference_id', account.user.id);
  if (account.user.email) u.searchParams.set('prefilled_email', account.user.email);
  return u.toString();
}
export function portalUrl() {
  if (!payments.portal) return '';
  const u = new URL(payments.portal);
  if (account.user?.email) u.searchParams.set('prefilled_email', account.user.email);
  return u.toString();
}
