// Sets the theme before anything paints, so there's no flash of the wrong colours.
try {
  var t = localStorage.getItem('propbook-theme');
  if (t !== 'dark' && t !== 'light') t = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  document.documentElement.dataset.theme = t;
} catch (e) {
  document.documentElement.dataset.theme = 'dark';
}
