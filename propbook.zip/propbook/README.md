# Propbook

Player prop research for **MLB, WNBA, NBA, NFL and college football**, rebuilt every day from that day's games.

For every player on the slate you get hit rates over the last 5, 10 and 20 games, head-to-head against tonight's opponent, and the current season, against the sportsbook line or any line you type in. MLB hitters also get their career line against the opposing probable starter.

## How it works

```
GitHub Actions (daily)
  └─ scripts/refresh.mjs
       ├─ ESPN public endpoints ─ NBA, WNBA, NFL, college football: schedule, rosters, game logs
       ├─ MLB Stats API ───────── schedule, probable pitchers, rosters, game logs, batter vs pitcher
       └─ PropLine (free key) ──── player prop lines (DraftKings, FanDuel, Bovada, BetMGM, Hard Rock, and more)
  └─ writes public/data/*.json
  └─ publishes /public to GitHub Pages
```

The site is plain HTML, CSS and JavaScript with no build step. Your odds key is only used inside the scheduled job and never reaches the browser.

**Which games are included**

| Sport | Slate | Players | History pulled |
| --- | --- | --- | --- |
| MLB | Today | Every active hitter, plus both probable starters | This season and last |
| WNBA, NBA | Today | Full rosters | This season and last |
| NFL | Next 7 days | QB, RB, WR, TE, K and defenders | This season and 2 prior |
| College football | Next 7 days, FBS only | QB, RB, WR, TE, K | This season and last |

Pre-season games are skipped. Games that have finished drop off the slate.

## Set it up (about 10 minutes)

1. **Create a GitHub repo** and push this folder to it. A public repo gets GitHub Pages for free.
2. **Turn on Pages:** Settings → Pages → Build and deployment → Source: **GitHub Actions**.
3. **Add your PropLine key:** Settings → Secrets and variables → Actions → New repository secret. Name it `PROPLINE_API_KEY`.
4. **Run it once:** Actions tab → Refresh slate → Run workflow. A full run takes roughly 10–25 minutes depending on how many games are on.
5. Your site is live at `https://<your-username>.github.io/<repo-name>/`. It rebuilds every day at 11am Eastern.

Without a key everything still works. You just set lines yourself on each player page.

## Sportsbook lines

Lines come from [PropLine](https://prop-line.com). Its free key allows 1,000 requests a day, and a daily run uses roughly two requests per game starting in the next 36 hours, well under that limit. The job log prints how many requests you have left.

Daily-fantasy apps (PrizePicks, Underdog and similar) are skipped because their prices aren't real sportsbook odds. When a book posts a ladder of alternate lines, the app uses that book's main line, the one priced closest to even.

If you'd rather use a paid key from The Odds API, add it as `ODDS_API_KEY` instead. When both are set, PropLine is used.

Optional repository **variables** (Settings → Secrets and variables → Actions → Variables):

| Variable | Default | What it does |
| --- | --- | --- |
| `ODDS_BOOKMAKERS` | `draftkings,fanduel,bovada,betmgm,betrivers,fanatics,hardrock,pinnacle` | Books to pull |
| `ODDS_SPORTS` | all | Comma list, e.g. `mlb,nfl`, to only pull lines for some sports |
| `ODDS_WINDOW_HOURS` | `36` | Only pull lines for games starting within this many hours |
| `ODDS_MARKETS_MLB` (or `_NFL`, `_NBA`, `_WNBA`, `_NCAAF`) | every market in `scripts/config.mjs` | Comma list of market keys to request |

## Accounts, Premium and saved props

Accounts run on [Supabase](https://supabase.com) (free plan). Until it's connected, the site works exactly as before with no log-in button.

1. Create a free Supabase project.
2. In the project, open **SQL Editor → New query**, paste all of `supabase/setup.sql`, and tap **Run**.
3. Open **Authentication → URL Configuration** and set **Site URL** to your site's address, for example `https://your-username.github.io/propbook/`.
4. Open **Project Settings → API** and copy the **Project URL** and the **anon public** key.
5. In GitHub, go to **Settings → Secrets and variables → Actions → Variables** and add `SUPABASE_URL` and `SUPABASE_ANON_KEY` with those values. The anon key is meant to be public; the database rules in `setup.sql` protect everyone's data.
6. Run the **Refresh slate** workflow.

**What's Premium.** Free: every player, L5 and L10 hit rates, the consensus sportsbook line, injury reports and the last 10 games of each log. Premium adds L20, head-to-head and season hit rates, odds from each sportsbook, batter vs pitcher, full game logs and saved props. Without accounts connected, the site shows everything to everyone.

These locks are in the site's display; the underlying daily data files are still public, so a technical visitor could read them directly. Moving Premium data behind the database is a later hardening step.

**Plans.** Everyone who signs up starts on Free. To make an account Premium, open **Table Editor → profiles** in Supabase and change that person's `plan` to `premium`. People can't change their own plan, and only Premium accounts can save props; the database enforces both. Payments can plug into this same `plan` field later.

**Deleting accounts.** Each account page has a Delete account button, which the App Store requires for apps with sign-up.

## Payments (Stripe)

Premium is sold with Stripe Payment Links. When someone pays, Stripe notifies a small Supabase Edge Function (`supabase/functions/stripe-webhook`), which verifies Stripe's signature and sets that account's plan. Cancellations, failed renewals and ended subscriptions switch it back to Free automatically.

1. Run `supabase/payments.sql` in the Supabase SQL Editor.
2. In Supabase, **Edge Functions → Deploy a new function → Via Editor**, name it `stripe-webhook`, paste `supabase/functions/stripe-webhook/index.ts`, deploy, then turn **Verify JWT** off in the function's settings.
3. In Stripe, create the Premium product with a monthly and a yearly price, and a Payment Link for each. Under **After payment**, redirect to your site with `?upgraded=1` on the end.
4. In Stripe, add a webhook endpoint pointing at the function URL, listening for `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated` and `customer.subscription.deleted`. Copy its signing secret into Supabase **Edge Functions → Secrets** as `STRIPE_WEBHOOK_SECRET`.
5. In Stripe, turn on the **Customer portal** and copy its login link.
6. Add GitHub repository variables: `STRIPE_MONTHLY_LINK`, `STRIPE_YEARLY_LINK`, `STRIPE_PORTAL_LINK`, `PREMIUM_MONTHLY_PRICE` (e.g. `$7.99/month`) and `PREMIUM_YEARLY_PRICE` (e.g. `$59.99/year`), then run the workflow.

Start in Stripe's test mode (test card `4242 4242 4242 4242`). Going live means repeating steps 3–6 with live-mode links and a live webhook secret.

## Free Premium: complimentary access and promo codes

Run `supabase/promos.sql` once in the Supabase SQL Editor. Complimentary time lives in its own `comp_until` column, so Stripe never overwrites it, and it switches itself off when the date passes.

Give someone Premium (change the email and length):

```sql
update public.profiles set comp_until = now() + interval '90 days', comp_note = 'Friend'
where id = (select id from auth.users where email = 'person@example.com');
```

For no end date use `comp_until = '2099-01-01'`. To remove it, set `comp_until = null`.

Create a promo code (30 days of Premium, first 100 people, redeemable through Dec 31):

```sql
insert into public.promo_codes (code, days, max_uses, expires_at, note)
values ('LAUNCH30', 30, 100, '2026-12-31', 'Launch promo');
```

People enter codes under **Have a promo code?** on their account page, or you can share a link that fills it in: `https://your-site/?promo=LAUNCH30`. Each account can use a code once. Turn a code off with `update public.promo_codes set active = false where code = 'LAUNCH30';` and see who used it with `select * from public.promo_redemptions where code = 'LAUNCH30';`.

Use codes that are hard to guess for anything long-lasting.

## Fantasy points

Every sport carries a **Fantasy points** stat using standard daily-fantasy scoring: PPR with yardage bonuses for football, points/rebounds/assists weighting with double-double bonuses for basketball, and DraftKings hitter and pitcher scoring for baseball. It works like any other stat, so people can set their own line even when no book posts one. Daily-fantasy apps such as PrizePicks and Underdog are ignored for normal markets, where their prices are boosted, but they do supply fantasy-score lines, since that's where those lines live.

## Betting context

- **Break-even shading.** Hit-rate colours compare each percentage with the win rate the current price needs, not a flat 50%.
- **Line shopping in dollars.** Each prop shows the book paying most and how much more it pays per $100 than the worst book on the slate.
- **Small-sample flags.** Any window with fewer than 5 games is greyed out and labelled, instead of showing a confident-looking percentage.
- **Splits.** Player pages filter to home or road games (matching the upcoming game) and to the last 30 days.
- **Share cards.** The Share button draws the current prop as an image and opens the phone's share sheet, falling back to a download on desktop.

## Refresh schedule

- **11am Eastern:** full rebuild of every sport.
- **Every hour:** a top-up that rebuilds a sport only when one of its games starts within about 4 hours, and not more often than every 75 minutes. Everything else is carried over from the last build through the Actions cache.

Tune with repository variables `REFRESH_LEAD_HOURS`, `MIN_REBUILD_MINUTES` and `MAX_DATA_AGE_HOURS` (add them to the workflow's `env:` block first). The header on the site turns red and says "Stale" if a sport's data is over 36 hours old.

## Legal pages

`public/terms.html` and `public/privacy.html` are drafts. Replace `[YOUR LLC NAME]`, `[YOUR STATE]`, `[YOUR COUNTY, STATE]` and `[YOUR BUSINESS ADDRESS]` before launch, and have a lawyer review them. They're linked from the site footer.

## Grading saved props

Run `supabase/grading.sql` once, then add a repository **secret** named `SUPABASE_SERVICE_ROLE_KEY` with your Supabase service role key (**Project Settings → API**). Keep it in Secrets, never Variables: it can read and write everything in your database.

Each daily run then looks up every saved prop whose game has finished, reads what the player actually did from the same game logs the app uses, and records `hit`, `miss`, `push` or `dnp`. Games with no published log yet are left alone and retried the next day, up to 30 hours after kickoff. Members see the result on each saved prop plus their running record.

## Injuries and news

Tap a game on the board and an **Injuries in this game** panel appears above the props, worst status first, with a link to that game's full report at `#/<sport>/injuries/g/<gameId>`. The Injuries & news tab carries the same game strip, so the whole report can be filtered to one matchup.

Each sport has an **Injuries & news** tab built daily from ESPN's league injury report, transactions (waived, released, retired, suspended, injured list and so on) and injury-related headlines. Items are tied to players on the slate when possible, and a player's status also shows on their page and on the props board.

## Run it on your computer

Requires Node 20 or newer. No packages to install.

```bash
npm test                          # parser tests
npm run mock && npm run serve     # preview the site with invented sample data (includes an injury report)
npm run refresh                   # build the real slate (all sports)
PLAYER_LIMIT=15 npm run refresh wnba   # fast test: one sport, 15 players
PROPLINE_API_KEY=xxxx npm run refresh mlb  # include lines
npm run serve                     # open http://localhost:5173
```

## If a stat comes back blank

ESPN's endpoints are unofficial and occasionally rename fields. To see exactly what ESPN sends for a player and how it maps:

```bash
npm run inspect nfl <espnAthleteId> 2025
npm run inspect mlb <mlbPlayerId> 2026 pitching
```

The athlete id is the number in a player's ESPN URL. Then fix the field names for that stat in `scripts/config.mjs` (each stat lists the names it looks for).

## Customizing

Everything sport-specific is in `scripts/config.mjs`:

- **Add a stat:** add an entry to that sport's stats list with a `key`, `label` and `from` function.
- **Map a new sportsbook market:** add `market_key: 'statKey'` to that sport's markets.
- **Include more positions** (like college defenders): edit `positions`.
- **Pull more history:** raise `seasonsBack`.
- **Change what "today" means:** `SETTINGS.timeZone`.

## Things to know

- GitHub pauses scheduled workflows in repos with no commits for 60 days. Push any small change, or click "Run workflow", to restart it.
- MLB game logs cover the regular season.
- A published GitHub Pages site is public. The data is all public stats and lines, but anyone with the link can view it.
- Hit rates count a game as a hit when the stat is strictly over the line (or strictly under, for unders). Games landing exactly on a whole-number line count as pushes and show with a dashed bar.
