# Propbook

Player prop research for **MLB, WNBA, NBA, NFL and college football**, rebuilt every day from that day's games.

For every player on the slate you get hit rates over the last 5, 10 and 20 games, head-to-head against tonight's opponent, and the current season, against the sportsbook line or any line you type in. MLB hitters also get their career line against the opposing probable starter.

## How it works

```
GitHub Actions (daily)
  └─ scripts/refresh.mjs
       ├─ ESPN public endpoints ─ NBA, WNBA, NFL, college football: schedule, rosters, game logs
       ├─ MLB Stats API ───────── schedule, probable pitchers, rosters, game logs, batter vs pitcher
       └─ PropLine (free key) ──── player prop lines (DraftKings, FanDuel, Bovada, BetMGM, Hard Rock, and more)
  └─ writes public/data/*.json
  └─ publishes /public to GitHub Pages
```

The site is plain HTML, CSS and JavaScript with no build step. Your odds key is only used inside the scheduled job and never reaches the browser.

**Which games are included**

| Sport | Slate | Players | History pulled |
| --- | --- | --- | --- |
| MLB | Today | Every active hitter, plus both probable starters | This season and last |
| WNBA, NBA | Today | Full rosters | This season and last |
| NFL | Next 7 days | QB, RB, WR, TE, K and defenders | This season and 2 prior |
| College football | Next 7 days, FBS only | QB, RB, WR, TE, K | This season and last |

Pre-season games are skipped. Games that have finished drop off the slate.

## Set it up (about 10 minutes)

1. **Create a GitHub repo** and push this folder to it. A public repo gets GitHub Pages for free.
2. **Turn on Pages:** Settings → Pages → Build and deployment → Source: **GitHub Actions**.
3. **Add your PropLine key:** Settings → Secrets and variables → Actions → New repository secret. Name it `PROPLINE_API_KEY`.
4. **Run it once:** Actions tab → Refresh slate → Run workflow. A full run takes roughly 10–25 minutes depending on how many games are on.
5. Your site is live at `https://<your-username>.github.io/<repo-name>/`. It rebuilds every day at 11am Eastern.

Without a key everything still works. You just set lines yourself on each player page.

## Sportsbook lines

Lines come from [PropLine](https://prop-line.com). Its free key allows 1,000 requests a day, and a daily run uses roughly two requests per game starting in the next 36 hours, well under that limit. The job log prints how many requests you have left.

Daily-fantasy apps (PrizePicks, Underdog and similar) are skipped because their prices aren't real sportsbook odds. When a book posts a ladder of alternate lines, the app uses that book's main line, the one priced closest to even.

If you'd rather use a paid key from The Odds API, add it as `ODDS_API_KEY` instead. When both are set, PropLine is used.

Optional repository **variables** (Settings → Secrets and variables → Actions → Variables):

| Variable | Default | What it does |
| --- | --- | --- |
| `ODDS_BOOKMAKERS` | `draftkings,fanduel,bovada,betmgm,betrivers,fanatics,hardrock,pinnacle` | Books to pull |
| `ODDS_SPORTS` | all | Comma list, e.g. `mlb,nfl`, to only pull lines for some sports |
| `ODDS_WINDOW_HOURS` | `36` | Only pull lines for games starting within this many hours |
| `ODDS_MARKETS_MLB` (or `_NFL`, `_NBA`, `_WNBA`, `_NCAAF`) | every market in `scripts/config.mjs` | Comma list of market keys to request |

## Run it on your computer

Requires Node 20 or newer. No packages to install.

```bash
npm test                          # parser tests
npm run mock && npm run serve     # preview the site with invented sample data
npm run refresh                   # build the real slate (all sports)
PLAYER_LIMIT=15 npm run refresh wnba   # fast test: one sport, 15 players
PROPLINE_API_KEY=xxxx npm run refresh mlb  # include lines
npm run serve                     # open http://localhost:5173
```

## If a stat comes back blank

ESPN's endpoints are unofficial and occasionally rename fields. To see exactly what ESPN sends for a player and how it maps:

```bash
npm run inspect nfl <espnAthleteId> 2025
npm run inspect mlb <mlbPlayerId> 2026 pitching
```

The athlete id is the number in a player's ESPN URL. Then fix the field names for that stat in `scripts/config.mjs` (each stat lists the names it looks for).

## Customizing

Everything sport-specific is in `scripts/config.mjs`:

- **Add a stat:** add an entry to that sport's stats list with a `key`, `label` and `from` function.
- **Map a new sportsbook market:** add `market_key: 'statKey'` to that sport's markets.
- **Include more positions** (like college defenders): edit `positions`.
- **Pull more history:** raise `seasonsBack`.
- **Change what "today" means:** `SETTINGS.timeZone`.

## Things to know

- GitHub pauses scheduled workflows in repos with no commits for 60 days. Push any small change, or click "Run workflow", to restart it.
- MLB game logs cover the regular season.
- A published GitHub Pages site is public. The data is all public stats and lines, but anyone with the link can view it.
- Hit rates count a game as a hit when the stat is strictly over the line (or strictly under, for unders). Games landing exactly on a whole-number line count as pushes and show with a dashed bar.
