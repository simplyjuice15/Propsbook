import test from 'node:test';
import assert from 'node:assert/strict';
import { refreshDecision } from '../scripts/lib/schedule.mjs';

const now = new Date('2026-09-19T18:00:00Z'); // 2pm Eastern
const today = '2026-09-19';
const slate = (over, games) => ({ generatedAt: new Date(now.getTime() - over * 60000).toISOString(), from: today, games });
const gameAt = (hoursFromNow) => ({ id: 'g', start: new Date(now.getTime() + hoursFromNow * 3600e3).toISOString() });

test('rebuilds when a game is coming up soon', () => {
  const d = refreshDecision('mlb', slate(120, [gameAt(3)]), now);
  assert.equal(d.refresh, true);
});

test('leaves sports alone when nothing starts for a while', () => {
  assert.equal(refreshDecision('mlb', slate(120, [gameAt(9)]), now).refresh, false);
});

test('never rebuilds the same sport twice in an hour', () => {
  assert.equal(refreshDecision('mlb', slate(20, [gameAt(2)]), now).refresh, false);
});

test('always rebuilds with no data, a new day, or stale data', () => {
  assert.equal(refreshDecision('mlb', null, now).refresh, true);
  assert.equal(refreshDecision('mlb', { ...slate(120, [gameAt(9)]), from: '2026-09-18' }, now).refresh, true);
  assert.equal(refreshDecision('mlb', slate(13 * 60, [gameAt(9)]), now).refresh, true);
});

test('ignores games already under way', () => {
  assert.equal(refreshDecision('mlb', slate(120, [gameAt(-2)]), now).refresh, false);
});
