import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHmac } from 'node:crypto';
const dir = await mkdtemp(join(tmpdir(), 'propbook-webhook-'));
await writeFile(join(dir, 'webhook.mjs'), await readFile(new URL('../supabase/functions/stripe-webhook/index.ts', import.meta.url), 'utf8'));
const wh = await import(pathToFileURL(join(dir, 'webhook.mjs')).href);
const secret = 'whsec_test123';
const now = 1_800_000_000;
const sign = (body, t = now) => `t=${t},v1=${createHmac('sha256', secret).update(`${t}.${body}`).digest('hex')}`;
const req = (body, sig) => new Request('https://x/functions/v1/stripe-webhook', { method: 'POST', body, headers: { 'stripe-signature': sig } });
function fakeDb() {
  const calls = [];
  return { calls, fetchImpl: async (url, init) => { calls.push({ url, init }); return new Response(JSON.stringify([{ id: 'u1' }]), { status: 200 }); } };
}
test('signature: accepts real Stripe-style signature, rejects tampering and old timestamps', async () => {
  const body = '{"type":"ping"}';
  assert.equal(await wh.verifyStripeSignature(body, sign(body), secret, now), true);
  assert.equal(await wh.verifyStripeSignature(body + ' ', sign(body), secret, now), false);
  assert.equal(await wh.verifyStripeSignature(body, sign(body, now - 1000), secret, now), false);
  assert.equal(await wh.verifyStripeSignature(body, sign(body), 'whsec_wrong', now), false);
});
test('checkout completed makes the logged-in account premium', async () => {
  const body = JSON.stringify({ type: 'checkout.session.completed', data: { object: { mode: 'subscription', client_reference_id: 'u1', customer: 'cus_1', subscription: 'sub_1', payment_status: 'no_payment_required' } } });
  const db = fakeDb();
  const res = await wh.handleRequest(req(body, sign(body)), { secret, nowSec: now, url: 'https://p.supabase.co', key: 'eyJlegacy', fetchImpl: db.fetchImpl });
  assert.equal(res.status, 200);
  assert.match(db.calls[0].url, /profiles\?id=eq\.u1$/);
  assert.equal(JSON.parse(db.calls[0].init.body).plan, 'premium');
  assert.equal(db.calls[0].init.headers.Authorization, 'Bearer eyJlegacy');
});
test('checkout without a login id falls back to email; new-style keys skip the Bearer header', async () => {
  const body = JSON.stringify({ type: 'checkout.session.completed', data: { object: { mode: 'payment', payment_status: 'paid', customer_details: { email: 'Nevin@Example.com' } } } });
  const db = fakeDb();
  await wh.handleRequest(req(body, sign(body)), { secret, nowSec: now, url: 'https://p.supabase.co', key: 'sb_secret_abc', fetchImpl: db.fetchImpl });
  assert.match(db.calls[0].url, /email=eq\.nevin%40example\.com$/);
  assert.equal(db.calls[0].init.headers.Authorization, undefined);
});
test('subscription ending or failing returns the account to free; past_due keeps premium', () => {
  const up = (status, extra = {}) => wh.planUpdateFor({ type: 'customer.subscription.updated', data: { object: { id: 'sub_1', customer: 'cus_1', status, ...extra } } });
  assert.equal(up('past_due').patch.plan, 'premium');
  assert.equal(up('unpaid').patch.plan, 'free');
  assert.equal(up('active', { cancel_at_period_end: true }).patch.subscription_status, 'canceling');
  assert.equal(up('active', { items: { data: [{ current_period_end: 1800000000 }] } }).patch.current_period_end, '2027-01-15T08:00:00.000Z');
  const del = wh.planUpdateFor({ type: 'customer.subscription.deleted', data: { object: { customer: 'cus_1' } } });
  assert.deepEqual(del.match, { customer: 'cus_1' });
  assert.equal(del.patch.plan, 'free');
});
test('bad signature is rejected before touching the database; unknown events are ignored', async () => {
  const body = JSON.stringify({ type: 'checkout.session.completed', data: { object: { mode: 'subscription', client_reference_id: 'u1' } } });
  const db = fakeDb();
  const bad = await wh.handleRequest(req(body, 't=1,v1=deadbeef'), { secret, nowSec: now, url: 'x', key: 'k', fetchImpl: db.fetchImpl });
  assert.equal(bad.status, 400);
  assert.equal(db.calls.length, 0);
  const other = JSON.stringify({ type: 'invoice.created', data: { object: {} } });
  const ig = await wh.handleRequest(req(other, sign(other)), { secret, nowSec: now, url: 'x', key: 'k', fetchImpl: db.fetchImpl });
  assert.equal((await ig.json()).ignored, 'invoice.created');
});
