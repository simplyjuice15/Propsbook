import test from 'node:test';
import assert from 'node:assert/strict';
import { recordClosingLines, rewardReferrals } from '../scripts/lib/members.mjs';
import { publicPlayer, publicProp, uploadPremium } from '../scripts/lib/premium.mjs';

const json = (d) => new Response(JSON.stringify(d), { status: 200 });

test('closing lines track the latest line before kickoff', async () => {
  const writes = [];
  const fetchImpl = async (url, init) => {
    if (init?.method === 'PATCH') { writes.push({ url, body: JSON.parse(init.body) }); return json([]); }
    return json([
      { id: 1, sport: 'nba', player_id: '9', stat: 'pts', close_line: null },
      { id: 2, sport: 'nba', player_id: '9', stat: 'reb', close_line: 8.5 }, // unchanged
      { id: 3, sport: 'nba', player_id: '7', stat: 'pts', close_line: null }, // no line now
    ]);
  };
  const slates = { nba: { props: [{ pid: '9', stat: 'pts', line: 24.5 }, { pid: '9', stat: 'reb', line: 8.5 }] } };
  const res = await recordClosingLines({ url: 'https://p.supabase.co', key: 'eyJx', slates, fetchImpl });
  assert.equal(res.updated, 1);
  assert.match(writes[0].url, /id=eq\.1$/);
  assert.equal(writes[0].body.close_line, 24.5);
});

test('referrers get 30 days once, stacked on top of existing free time', async () => {
  const now = new Date('2026-10-01T12:00:00Z');
  const writes = [];
  const fetchImpl = async (url, init) => {
    if (init?.method === 'PATCH') { writes.push({ url, body: JSON.parse(init.body) }); return json([]); }
    if (url.includes('referral_code=eq.ABC1234')) return json([{ id: 'ref', comp_until: '2026-10-11T12:00:00Z' }]);
    return json([{ id: 'friend', referred_by: 'ABC1234' }]);
  };
  const res = await rewardReferrals({ url: 'https://p.supabase.co', key: 'eyJx', now, fetchImpl });
  assert.equal(res.rewarded, 1);
  assert.equal(writes[0].body.comp_until, '2026-11-10T12:00:00.000Z'); // 10 days left + 30
  assert.deepEqual(writes[1].body, { referral_rewarded: true });
});

test('public files keep Premium numbers out', () => {
  const p = { id: '1', name: 'A', rows: Array.from({ length: 40 }, (_, i) => [String(i)]), matchup: { x: 1 }, seasons: [1], bvp: {} };
  const pub = publicPlayer(p);
  assert.equal(pub.rows.length, 10);
  assert.equal(pub.matchup, undefined);
  assert.equal(pub.seasons, undefined);
  const pr = publicProp({ pid: '1', gameId: 'g', stat: 'pts', line: 20.5, books: [{ book: 'DK' }], hr: { l5: [1], l10: [2], l20: [3], h2h: [4], szn: [5] } });
  assert.deepEqual(Object.keys(pr.hr), ['l5', 'l10']);
  assert.equal(pr.books.length, 0);
});

test('premium upload goes to the private bucket and replaces old copies', async () => {
  let seen;
  await uploadPremium('https://p.supabase.co', 'sb_secret_x', 'nba/games/g1.json', { a: 1 }, async (url, init) => {
    seen = { url, init };
    return new Response('{}', { status: 200 });
  });
  assert.equal(seen.url, 'https://p.supabase.co/storage/v1/object/premium/nba/games/g1.json');
  assert.equal(seen.init.headers['x-upsert'], 'true');
  assert.equal(seen.init.headers.Authorization, undefined);
});

test('a failed private upload never leaves a game without a public file', async () => {
  const { publishGames } = await import('../scripts/lib/premium.mjs');
  const slate = {
    season: 2027,
    games: [{ id: 'a' }, { id: 'b' }, { id: 'c' }],
    players: ['a', 'b', 'c'].map((g, i) => ({ id: String(i), gameId: g, rows: Array.from({ length: 30 }, () => ['x']), matchup: {} })),
  };
  const written = {};
  const writeGame = async (id, data) => { written[id] = data; };

  let calls = 0;
  const failing = async () => { if (++calls === 2) throw new Error('bucket not found'); };
  const bad = await publishGames({ sport: 'nhl', slate, props: [], premium: { url: 'u', key: 'k' }, writeGame, upload: failing });
  assert.equal(bad.privateOk, false);
  assert.deepEqual(Object.keys(written).sort(), ['a', 'b', 'c']); // every game still published
  assert.equal(written.c.players[0].rows.length, 30); // full data, since Premium couldn't be served privately

  const ok = await publishGames({ sport: 'nhl', slate, props: [], premium: { url: 'u', key: 'k' }, writeGame, upload: async () => {} });
  assert.equal(ok.privateOk, true);
  assert.equal(written.b.players[0].rows.length, 10); // trimmed public copy
  assert.equal(written.b.players[0].matchup, undefined);
});
