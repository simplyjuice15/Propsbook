import test from 'node:test';
import assert from 'node:assert/strict';
import { PassThrough } from 'node:stream';
import { buildEmail, changesFor, sendAlerts } from '../scripts/lib/alerts.mjs';
import { buildMessage, dotStuff, sendMail } from '../scripts/lib/smtp.mjs';

const prefs = { alerts_injury: true, alerts_line: true };

test('what counts as worth an email', () => {
  const saved = { player_name: 'Josh Allen', stat: 'passYds', stat_label: 'Passing yards', line: 249.5 };
  assert.equal(changesFor(saved, { inj: 'Out' }, null, prefs)[0].kind, 'injury');
  assert.equal(changesFor(saved, { inj: 'Probable' }, null, prefs).length, 1);
  assert.equal(changesFor(saved, { inj: '' }, null, prefs).length, 0);
  const moved = changesFor(saved, { inj: '' }, { line: 244.5 }, prefs);
  assert.match(moved[0].text, /moved from 249.5 to 244.5 \(-5\)/);
  assert.equal(changesFor(saved, { inj: '' }, { line: 249.5 }, prefs).length, 0); // unchanged
  assert.equal(changesFor(saved, { inj: 'Out' }, { line: 244.5 }, { alerts_injury: false, alerts_line: false }).length, 0);
  assert.equal(changesFor(saved, null, { line: 200 }, prefs).length, 0); // player not on the slate
});

test('email carries an unsubscribe link and both formats', () => {
  const mail = buildEmail('fan@example.com', [{ text: 'A is Out' }, { text: 'B moved' }], 'tok-123');
  assert.match(mail.subject, /2 updates/);
  assert.match(mail.text, /unsub=tok-123/);
  assert.match(mail.html, /Turn these emails off/);
  const raw = buildMessage({ from: 'me@gmail.com', to: 'fan@example.com', subject: 'x', text: 'hi', html: '<b>hi</b>', listUnsubscribe: 'https://x/?unsub=1' });
  assert.match(raw, /List-Unsubscribe: </);
  assert.match(raw, /multipart\/alternative/);
  assert.equal(dotStuff('.hidden\nline'), '..hidden\r\nline');
});

test('sends one email per member, only once per change', async () => {
  const db = { log: [] };
  const slates = {
    nfl: {
      players: [{ id: '1', inj: 'Out' }, { id: '2', inj: '' }],
      props: [{ pid: '2', stat: 'recYds', line: 51.5 }],
    },
  };
  const saved = [
    { id: 11, user_id: 'u1', sport: 'nfl', player_id: '1', stat: 'passYds', stat_label: 'Passing yards', line: 249.5, player_name: 'A' },
    { id: 12, user_id: 'u1', sport: 'nfl', player_id: '2', stat: 'recYds', stat_label: 'Receiving yards', line: 57.5, player_name: 'B' },
    { id: 13, user_id: 'u2', sport: 'nfl', player_id: '1', stat: 'passYds', line: 249.5, player_name: 'A' },
  ];
  const profiles = [
    { id: 'u1', email: 'one@example.com', plan: 'premium', alerts_enabled: true, alerts_injury: true, alerts_line: true, unsubscribe_token: 't1' },
    { id: 'u2', email: 'two@example.com', plan: 'free', alerts_enabled: true, alerts_injury: true, alerts_line: true, unsubscribe_token: 't2' },
  ];
  const fetchImpl = async (url, init) => {
    if (init?.method === 'POST') {
      db.log.push(...JSON.parse(init.body));
      return new Response('[]', { status: 201 });
    }
    if (url.includes('saved_props')) return new Response(JSON.stringify(saved), { status: 200 });
    if (url.includes('profiles')) return new Response(JSON.stringify(profiles), { status: 200 });
    return new Response(JSON.stringify(db.log.map((l) => ({ ...l }))), { status: 200 });
  };
  const outbox = [];
  const mail = async (msg) => { outbox.push(msg); };
  const opts = { url: 'https://p.supabase.co', key: 'eyJx', slates, fetchImpl, mail, mailer: { user: 'me@gmail.com', pass: 'app-pass' } };

  const first = await sendAlerts(opts);
  assert.equal(first.sent, 1); // only the premium member
  assert.equal(outbox[0].to, 'one@example.com');
  assert.match(outbox[0].text, /A is Out/);
  assert.match(outbox[0].text, /moved from 57.5 to 51.5/);

  const second = await sendAlerts(opts); // nothing new
  assert.equal(second.sent, 0);
});

test('smtp conversation speaks the right commands', async () => {
  const toServer = new PassThrough(); // client → server
  const toClient = new PassThrough(); // server → client
  const socket = {
    on: (ev, fn) => toClient.on(ev, fn),
    once: (ev, fn) => toClient.once(ev, fn),
    setEncoding: (enc) => toClient.setEncoding(enc),
    write: (chunk) => toServer.write(chunk),
    end: () => toServer.end(),
  };
  const said = [];
  let authLines = 0;
  let inBody = false;
  let body = '';
  const reply = (line) => toClient.write(`${line}\r\n`);
  toServer.on('data', (chunk) => {
    const text = chunk.toString();
    said.push(text.trim());
    if (inBody) {
      body += text;
      if (body.endsWith('\r\n.\r\n')) {
        inBody = false;
        reply('250 queued');
      }
      return;
    }
    if (/^EHLO/.test(text)) return reply('250 ok');
    if (/^AUTH LOGIN/.test(text)) return reply('334 VXNlcm5hbWU6');
    if (/^MAIL FROM/.test(text)) return reply('250 ok');
    if (/^RCPT TO/.test(text)) return reply('250 ok');
    if (/^DATA/.test(text)) {
      inBody = true;
      return reply('354 go ahead');
    }
    if (/^QUIT/.test(text)) return reply('221 bye');
    authLines += 1;
    return reply(authLines === 1 ? '334 UGFzc3dvcmQ6' : '235 accepted');
  });
  setTimeout(() => reply('220 smtp.gmail.com ready'), 5);

  const res = await sendMail(
    { from: 'me@gmail.com', to: 'fan@example.com', subject: 'Hi', text: 'hello', html: '<b>hello</b>' },
    { user: 'me@gmail.com', pass: 'app-pass', connect: () => socket },
  );
  assert.equal(res.sent, true);
  assert.ok(said.some((s) => s.startsWith('EHLO')));
  assert.ok(said.some((s) => s.startsWith('RCPT TO:<fan@example.com>')));
  assert.ok(said.some((s) => s.includes('Subject: Hi')));
  assert.ok(body.includes('<b>hello</b>'));
});
