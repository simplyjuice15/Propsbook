import test from 'node:test';
import assert from 'node:assert/strict';
import { gradeSavedProps, gradeValue, statsForGame } from '../scripts/lib/grade.mjs';
import { SPORTS } from '../scripts/config.mjs';

test('hit, miss and push', () => {
  assert.equal(gradeValue({ line: 24.5, side: 'over' }, 27), 'hit');
  assert.equal(gradeValue({ line: 24.5, side: 'over' }, 21), 'miss');
  assert.equal(gradeValue({ line: 24.5, side: 'under' }, 21), 'hit');
  assert.equal(gradeValue({ line: 7, side: 'over' }, 7), 'push');
  assert.equal(gradeValue({ line: 7, side: 'over' }, null), null);
});

const nflLog = {
  names: ['completions', 'passingAttempts', 'passingYards', 'passingTouchdowns'],
  events: { 401: { gameDate: '2026-09-14T00:15Z', atVs: 'vs', opponent: { id: '9', abbreviation: 'MIA' }, gameResult: 'W' } },
  seasonTypes: [{ displayName: '2026 Regular Season', categories: [{ events: [{ eventId: '401', stats: ['24', '38', '281', '2'] }] }] }],
};

test('reads the finished game out of a player game log', async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify(nflLog), { status: 200 });
  try {
    const stats = await statsForGame('nfl', SPORTS.nfl, '3918298', '401', '2026-09-14T00:15:00Z');
    assert.equal(stats.passYds, 281);
    assert.equal(stats.cmp, 24);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('scores saved props and leaves fresh games alone until the log appears', async () => {
  const now = new Date('2026-09-15T15:00:00Z');
  const saved = [
    { id: 1, sport: 'nfl', player_id: '3918298', game_id: '401', game_start: '2026-09-14T00:15:00Z', stat: 'passYds', line: 249.5, side: 'over' },
    { id: 2, sport: 'nfl', player_id: '3918298', game_id: '401', game_start: '2026-09-14T00:15:00Z', stat: 'passTd', line: 2.5, side: 'over' },
    { id: 3, sport: 'nfl', player_id: '999', game_id: '402', game_start: '2026-09-15T00:15:00Z', stat: 'recYds', line: 44.5, side: 'over' }, // no log yet
    { id: 4, sport: 'nfl', player_id: '999', game_id: '300', game_start: '2026-09-10T00:15:00Z', stat: 'recYds', line: 44.5, side: 'over' }, // old, never played
  ];
  const writes = [];
  const fetchImpl = async (url, init) => {
    if (!init || init.method !== 'PATCH') return new Response(JSON.stringify(saved), { status: 200 });
    writes.push({ id: Number(url.match(/id=eq\.(\d+)/)[1]), body: JSON.parse(init.body) });
    return new Response('[]', { status: 200 });
  };
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url) => new Response(JSON.stringify(String(url).includes('/999/') ? {} : nflLog), { status: 200 });
  try {
    const res = await gradeSavedProps({ url: 'https://p.supabase.co', key: 'eyJlegacy', now, fetchImpl });
    assert.equal(res.graded, 3);
    assert.equal(res.skipped, 1);
    const byId = Object.fromEntries(writes.map((w) => [w.id, w.body]));
    assert.deepEqual([byId[1].result, byId[1].actual], ['hit', 281]);
    assert.equal(byId[2].result, 'miss');
    assert.equal(byId[4].result, 'dnp');
    assert.equal(byId[3], undefined);
  } finally {
    globalThis.fetch = realFetch;
  }
});
