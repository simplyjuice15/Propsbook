import test from 'node:test';
import assert from 'node:assert/strict';
import { footballGroups, parseFootballBox, parseReboundSplit } from '../scripts/lib/boxscore.mjs';
import { SPORTS } from '../scripts/config.mjs';
import { META_LEN, buildRows } from '../scripts/lib/common.mjs';

test('basketball box scores split rebounds into offensive and defensive', () => {
  const box = {
    boxscore: { players: [{ team: { id: '6' }, statistics: [{
      keys: ['minutes', 'points', 'offensiveRebounds', 'defensiveRebounds', 'rebounds'],
      labels: ['MIN', 'PTS', 'OREB', 'DREB', 'REB'],
      athletes: [
        { athlete: { id: '3945274' }, stats: ['36', '31', '3', '9', '12'] },
        { athlete: { id: '111' }, stats: [] }, // did not play
      ],
    }] }] },
  };
  const out = parseReboundSplit(box);
  assert.deepEqual(out['3945274'], { offensiveRebounds: 3, defensiveRebounds: 9 });
  assert.equal(out['111'], undefined);

  // labels alone (older feeds) work too
  const older = { boxscore: { players: [{ statistics: [{ labels: ['OREB', 'DREB'], athletes: [{ athlete: { id: '5' }, stats: ['1', '4'] }] }] }] } };
  assert.equal(parseReboundSplit(older)['5'].defensiveRebounds, 4);
});

test('rebound splits become stats and markets', () => {
  const entries = [{ date: '2026-10-25T00:00Z', season: 2027, oppId: '1', oppAbbr: 'BOS', ha: 'vs', result: 'W',
    raw: { totalRebounds: 12, offensiveRebounds: 3, defensiveRebounds: 9, fieldGoalsAttempted: 20, threePointFieldGoalsAttempted: 7 } }];
  const { cols, rows } = buildRows(entries, SPORTS.nba.stats, '1');
  const v = (k) => rows[0][META_LEN + cols.indexOf(k)];
  assert.equal(v('oreb'), 3);
  assert.equal(v('dreb'), 9);
  assert.equal(v('fg2a'), 13);
  assert.equal(v('fg3a'), 7);
  const marketStats = new Set(Object.values(SPORTS.nba.markets));
  for (const k of ['oreb', 'dreb', 'fg2a', 'fg3a']) assert.ok(marketStats.has(k), `${k} is a market`);
});

test('college football defense comes from what the other offense produced', () => {
  const block = (name, labels, totals) => ({ name, labels, totals });
  const box = { boxscore: { players: [
    { team: { id: '251' }, statistics: [
      block('passing', ['C/ATT', 'YDS', 'AVG', 'TD', 'INT'], ['22/31', '287', '9.3', '2', '1']),
      block('rushing', ['CAR', 'YDS', 'AVG', 'TD'], ['34', '161', '4.7', '1']),
      block('receiving', ['REC', 'YDS', 'AVG', 'TD'], ['22', '287', '13.0', '2']),
    ] },
    { team: { id: '2' }, statistics: [block('passing', ['C/ATT', 'YDS', 'AVG', 'TD', 'INT'], ['15/30', '180', '6.0', '1', '0'])] },
  ] } };
  const out = parseFootballBox(box);
  assert.equal(out.allowedBy['2'].passYds, 287); // team 2's defense gave up team 251's passing
  assert.equal(out.allowedBy['2'].cmp, 22);
  assert.equal(out.allowedBy['251'].passYds, 180);
  const groups = footballGroups(out.allowedBy['2']);
  assert.equal(groups.QB.passYds, 287);
  assert.equal(groups.RB.rushYds, 161);
  assert.equal(groups.RB.tds, 3);
  assert.equal(groups.REC.recYds, 287);
  assert.equal(SPORTS.ncaaf.defenseGroup('TE'), 'REC');
});
