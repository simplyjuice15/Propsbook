import test from 'node:test';
import assert from 'node:assert/strict';
import { SPORTS } from '../scripts/config.mjs';
import { parseGamelog, parseRoster, parseScoreboard } from '../scripts/lib/espn.mjs';
import { parseGameLog, parseSchedule } from '../scripts/lib/mlb.mjs';
import { activeProvider, consensusLine, mainLine, matchEvents, parseEventOdds } from '../scripts/lib/odds.mjs';
import { buildRows, hitRates, normName, seasonOf } from '../scripts/lib/common.mjs';

const nbaGamelog = {
  names: ['minutes', 'fieldGoalsMade-fieldGoalsAttempted', 'fieldGoalPct', 'threePointFieldGoalsMade-threePointFieldGoalsAttempted', 'threePointFieldGoalPct', 'freeThrowsMade-freeThrowsAttempted', 'freeThrowPct', 'totalRebounds', 'assists', 'blocks', 'steals', 'fouls', 'turnovers', 'points'],
  labels: ['MIN', 'FG', 'FG%', '3PT', '3P%', 'FT', 'FT%', 'REB', 'AST', 'BLK', 'STL', 'PF', 'TO', 'PTS'],
  events: {
    e1: { gameDate: '2026-09-10T23:30:00.000+00:00', atVs: '@', opponent: { id: '5', abbreviation: 'NY' }, gameResult: 'W' },
    e2: { gameDate: '2026-09-12T23:30:00.000+00:00', atVs: 'vs', opponent: { id: '9', abbreviation: 'LV' }, gameResult: 'L' },
    e3: { gameDate: '2026-05-01T23:30:00.000+00:00', atVs: 'vs', opponent: { id: '5', abbreviation: 'NY' }, gameResult: 'L' },
  },
  seasonTypes: [
    { displayName: '2026 Postseason', categories: [{ type: 'event', events: [{ eventId: 'e2', stats: ['35', '9-18', '50', '3-7', '42.9', '4-4', '100', '8', '6', '1', '2', '3', '2', '25'] }] }] },
    { displayName: '2026 Regular Season', categories: [
      { type: 'event', events: [{ eventId: 'e1', stats: ['32', '7-15', '46.7', '2-5', '40', '2-2', '100', '5', '4', '0', '1', '2', '3', '18'] }] },
      { type: 'total', totals: ['x'] },
    ] },
    { displayName: '2026 Preseason', categories: [{ type: 'event', events: [{ eventId: 'e3', stats: ['10', '1-2', '', '0-0', '', '0-0', '', '1', '1', '0', '0', '0', '0', '2'] }] }] },
  ],
};

test('ESPN basketball game log parses pairs, skips preseason and computes combos', () => {
  const entries = parseGamelog(nbaGamelog, 2026);
  assert.equal(entries.length, 2);
  const { cols, rows } = buildRows(entries, SPORTS.wnba.stats, '5');
  const row = (key, r) => r[6 + cols.indexOf(key)];
  assert.equal(rows[0][0], '2026-09-12'); // newest first
  assert.equal(row('pts', rows[0]), 25);
  assert.equal(row('fg3m', rows[0]), 3);
  assert.equal(row('fga', rows[0]), 18);
  assert.equal(row('pra', rows[0]), 39);
  assert.equal(rows[1][4], '@');
});

test('ESPN football roster groups are flattened and positions kept', () => {
  const roster = parseRoster({ athletes: [
    { position: 'offense', items: [{ id: 1, displayName: 'A QB', position: { abbreviation: 'QB' }, injuries: [{ status: 'Questionable' }] }] },
    { position: 'defense', items: [{ id: 2, displayName: 'B LB', position: { abbreviation: 'LB' } }] },
  ] });
  assert.equal(roster.length, 2);
  assert.equal(roster[0].inj, 'Questionable');
  assert.equal(SPORTS.nfl.role(roster[1].pos), 'def');
});

test('ESPN football game log maps yards, TDs and combos', () => {
  const gl = {
    names: ['completions', 'passingAttempts', 'passingYards', 'passingTouchdowns', 'interceptions', 'rushingAttempts', 'rushingYards', 'rushingTouchdowns', 'receptions', 'receivingTargets', 'receivingYards', 'receivingTouchdowns'],
    events: { g1: { gameDate: '2025-12-01T18:00Z', atVs: 'vs', opponent: { id: '12', abbreviation: 'KC' }, gameResult: 'W' } },
    seasonTypes: [{ displayName: '2025 Regular Season', categories: [{ events: [{ eventId: 'g1', stats: ['0', '0', '0', '0', '0', '12', '64', '1', '4', '5', '31', '1'] }] }] }],
  };
  const defs = SPORTS.nfl.stats.filter((s) => s.role === 'off');
  const { cols, rows } = buildRows(parseGamelog(gl, 2025), defs, '12');
  const v = (k) => rows[0][6 + cols.indexOf(k)];
  assert.equal(v('rushRecYds'), 95);
  assert.equal(v('tds'), 2);
});

test('ESPN scoreboard parses teams and state', () => {
  const games = parseScoreboard({ events: [{ id: '401', date: '2026-09-20T17:00Z', status: { type: { state: 'pre', shortDetail: '9/20 - 1:00 PM' } },
    competitions: [{ competitors: [
      { homeAway: 'home', team: { id: '1', abbreviation: 'ATL', displayName: 'Atlanta Falcons', shortDisplayName: 'Falcons' } },
      { homeAway: 'away', team: { id: '2', abbreviation: 'BUF', displayName: 'Buffalo Bills', shortDisplayName: 'Bills' } },
    ] }] }] });
  assert.equal(games[0].home.abbr, 'ATL');
  assert.equal(games[0].state, 'pre');
});

test('MLB schedule and game log parse', () => {
  const abbr = new Map([[147, 'NYY'], [111, 'BOS']]);
  const games = parseSchedule({ dates: [{ games: [{ gamePk: 7, gameDate: '2026-09-16T23:05:00Z', status: { abstractGameState: 'Preview', detailedState: 'Scheduled' },
    teams: { home: { team: { id: 111, name: 'Boston Red Sox', teamName: 'Red Sox' }, probablePitcher: { id: 1, fullName: 'P One' } }, away: { team: { id: 147, name: 'New York Yankees', teamName: 'Yankees' } } } }] }] }, abbr);
  assert.equal(games[0].home.abbr, 'BOS');
  assert.equal(games[0].home.probable.name, 'P One');

  const entries = parseGameLog({ stats: [{ splits: [
    { date: '2026-09-14', isHome: false, isWin: true, opponent: { id: 111 }, game: { gamePk: 1 }, stat: { hits: 2, doubles: 1, homeRuns: 1, runs: 1, rbi: 3, totalBases: 7, atBats: 4 } },
  ] }] }, 2026, abbr);
  const defs = SPORTS.mlb.stats.filter((s) => s.role === 'hitter');
  const { cols, rows } = buildRows(entries, defs, '111');
  const v = (k) => rows[0][6 + cols.indexOf(k)];
  assert.equal(v('hrr'), 6);
  assert.equal(v('singles'), 0);
  assert.equal(rows[0][2], 'BOS');

  const pdefs = SPORTS.mlb.stats.filter((s) => s.role === 'pitcher');
  const p = buildRows(parseGameLog({ stats: [{ splits: [{ date: '2026-09-10', opponent: { id: 147 }, stat: { inningsPitched: '5.2', strikeOuts: 7 } }] }] }, 2026, abbr), pdefs, '147');
  assert.equal(p.rows[0][6 + p.cols.indexOf('pOuts')], 17);
});

test('odds: events match games and outcomes match players', () => {
  const games = [{ id: 'g1', start: '2026-09-16T23:05:00Z', home: { name: 'Boston Red Sox', short: 'Red Sox' }, away: { name: 'New York Yankees', short: 'Yankees' } }];
  const pairs = matchEvents([{ id: 'ev', home_team: 'Boston Red Sox', away_team: 'New York Yankees', commence_time: '2026-09-16T23:05:00Z' }], games);
  assert.equal(pairs.length, 1);

  const players = [
    { id: '10', name: 'Aaron Judge', role: 'hitter', cols: ['h', 'tb'] },
    { id: 'p1', name: 'Garrett Crochet', role: 'pitcher', cols: ['pK'] },
  ];
  const props = parseEventOdds({ bookmakers: [
    { key: 'draftkings', title: 'DraftKings', markets: [
      { key: 'batter_total_bases', outcomes: [{ name: 'Over', description: 'Aaron Judge', price: -120, point: 1.5 }, { name: 'Under', description: 'Aaron Judge', price: 100, point: 1.5 }] },
      { key: 'pitcher_strikeouts', outcomes: [{ name: 'Over', description: 'Garrett Crochet', price: -110, point: 7.5 }] },
    ] },
    { key: 'fanduel', title: 'FanDuel', markets: [
      { key: 'batter_total_bases', outcomes: [{ name: 'Over', description: 'Aaron Judge Jr.', price: -115, point: 1.5 }] },
    ] },
  ] }, games[0], players, SPORTS.mlb.markets);
  const tb = props.find((p) => p.stat === 'tb');
  assert.equal(tb.pid, '10');
  assert.equal(tb.line, 1.5);
  assert.equal(tb.books.length, 2);
  assert.equal(tb.books[0].under, 100);
  assert.equal(props.find((p) => p.stat === 'pK').pid, 'p1');
  assert.equal(consensusLine([0.5, 1.5, 1.5, 0.5, 2.5]), 0.5);
});

test('hit rates by window, including head-to-head and season', () => {
  const cols = ['pts'];
  const rows = [
    ['2026-09-12', 2026, 'LV', '9', 'vs', 'L', 25],
    ['2026-09-10', 2026, 'NY', '5', '@', 'W', 18],
    ['2025-08-01', 2025, 'NY', '5', 'vs', 'W', 30],
  ];
  const hr = hitRates({ cols, rows, oppId: '5' }, 'pts', 19.5, 2026);
  assert.deepEqual(hr.l5, [2, 3, 24.3, 0]);
  assert.deepEqual(hr.h2h, [1, 2, 24, 0]);
  assert.deepEqual(hr.szn, [1, 2, 21.5, 0]);
});

test('seasons and names', () => {
  assert.equal(seasonOf(SPORTS.nba, '2026-09-16'), 2027);
  assert.equal(seasonOf(SPORTS.nfl, '2027-01-10'), 2026);
  assert.equal(seasonOf(SPORTS.mlb, '2026-09-16'), 2026);
  assert.equal(normName('Kenneth Walker III'), 'kenneth walker');
  assert.equal(normName('Luka Dončić'), 'luka doncic');
});

test('PropLine: alt ladders collapse to the main line, DFS apps are ignored, team tags stripped', () => {
  const game = { id: 'g9' };
  const players = [
    { id: '21', name: 'Tarik Skubal', role: 'pitcher', cols: ['pK'] },
    { id: '22', name: 'Riley Greene', role: 'hitter', cols: ['r', 'h'] },
  ];
  const props = parseEventOdds({ bookmakers: [
    { key: 'hardrock', title: 'Hard Rock Bet', markets: [{ key: 'pitcher_strikeouts', outcomes: [
      { name: 'Over', description: 'Tarik Skubal (DET)', price: -320, point: 4.5 },
      { name: 'Under', description: 'Tarik Skubal (DET)', price: 250, point: 4.5 },
      { name: 'Over', description: 'Tarik Skubal (DET)', price: -115, point: 6.5 },
      { name: 'Under', description: 'Tarik Skubal (DET)', price: -105, point: 6.5 },
      { name: 'Over', description: 'Tarik Skubal (DET)', price: 210, point: 8.5 },
      { name: 'Under', description: 'Tarik Skubal (DET)', price: -270, point: 8.5 },
    ] }] },
    { key: 'prizepicks', title: 'PrizePicks', markets: [{ key: 'pitcher_strikeouts', outcomes: [
      { name: 'Over', description: 'Tarik Skubal', price: 100, point: 7.5, dfs_odds_type: 'standard' },
    ] }] },
    { key: 'bovada', title: 'Bovada', markets: [{ key: 'batter_runs', outcomes: [
      { name: 'Over', description: 'Riley Greene', price: 120, point: 0.5 },
      { name: 'Under', description: 'Riley Greene', price: -150, point: 0.5 },
    ] }] },
  ] }, game, players, SPORTS.mlb.markets);
  const k = props.find((p) => p.stat === 'pK');
  assert.equal(k.books.length, 1);
  assert.equal(k.line, 6.5);
  assert.equal(props.find((p) => p.stat === 'r').pid, '22');
  assert.equal(mainLine([{ line: 0.5, over: 150, under: null }]).line, 0.5);
});

test('provider choice follows which key is set', () => {
  assert.equal(activeProvider({ PROPLINE_API_KEY: 'x', ODDS_API_KEY: 'y' }).name, 'PropLine');
  assert.equal(activeProvider({ ODDS_API_KEY: 'y' }).name, 'The Odds API');
  assert.equal(activeProvider({}), null);
});

test('football schedule survives ESPN refusing date ranges and limit', async () => {
  const { fetchSchedule } = await import('../scripts/lib/espn.mjs');
  const realFetch = globalThis.fetch;
  const ev = (id) => ({ id, date: '2026-09-20T17:00Z', status: { type: { state: 'pre' } }, competitions: [{ competitors: [
    { homeAway: 'home', team: { id: '1', abbreviation: 'AAA', displayName: 'A' } },
    { homeAway: 'away', team: { id: '2', abbreviation: 'BBB', displayName: 'B' } }] }] });
  globalThis.fetch = async (url) => {
    const u = new URL(url);
    const dates = u.searchParams.get('dates');
    if (!dates || dates.includes('-') || u.searchParams.has('limit')) return new Response('{"code":400}', { status: 400 });
    return new Response(JSON.stringify({ events: dates === '20260920' ? [ev('402'), ev('403')] : [] }), { status: 200 });
  };
  try {
    const games = await fetchSchedule(SPORTS.nfl, '2026-09-16', '2026-09-22');
    assert.deepEqual(games.map((g) => g.id), ['402', '403']);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('injury report: parses injuries, moves and headlines, ties them to slate players', async () => {
  const { parseInjuries, parseTransactions, parseNews, buildReport, severity } = await import('../scripts/lib/news.mjs');
  const inj = parseInjuries({ injuries: [{ displayName: 'Buffalo Bills', abbreviation: 'BUF', injuries: [
    { status: 'Questionable', date: '2026-09-15T20:00Z', shortComment: 'Limited in practice.',
      athlete: { displayName: 'Josh Allen', position: { abbreviation: 'QB' }, links: [{ href: 'https://www.espn.com/nfl/player/_/id/3918298/josh-allen' }] },
      details: { type: 'Shoulder', detail: 'Soreness', side: 'Right', returnDate: '2026-09-21' } },
  ] }] });
  assert.equal(inj[0].espnId, '3918298');
  assert.equal(inj[0].injury, 'Shoulder, Soreness');

  const moves = parseTransactions({ transactions: [
    { date: '2026-09-14', description: 'Waived WR Sam Example.', team: { abbreviation: 'MIA' } },
    { date: '2026-09-14', description: 'Signed a practice squad contract extension.', team: { abbreviation: 'MIA' } },
  ] });
  assert.equal(moves.length, 1);
  assert.equal(moves[0].status, 'Waived');

  const news = parseNews({ articles: [
    { headline: 'Star receiver ruled out for Sunday', published: '2026-09-15', links: { web: { href: 'https://example.com/a' } } },
    { headline: 'Ranking every uniform', published: '2026-09-15' },
  ] });
  assert.equal(news.length, 1);
  assert.equal(severity('Out'), 3);
  assert.equal(severity('Questionable'), 2);

  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    const body = url.endsWith('/injuries')
      ? { injuries: [{ displayName: 'Buffalo Bills', abbreviation: 'BUF', injuries: [{ status: 'Out', date: '2026-09-15', athlete: { id: '3918298', displayName: 'Josh Allen' }, details: { type: 'Ankle' } }] }] }
      : url.includes('/transactions') ? { transactions: [{ date: '2026-09-14', description: 'Placed RB Casey Runner on injured reserve.', team: { abbreviation: 'MIA' } }] }
      : { articles: [] };
    return new Response(JSON.stringify(body), { status: 200 });
  };
  try {
    const slate = {
      games: [{ id: 'g1', home: { id: '2', abbr: 'BUF', name: 'Buffalo Bills' }, away: { id: '15', abbr: 'MIA', name: 'Miami Dolphins' } }],
      players: [
        { id: '3918298', name: 'Josh Allen', team: 'BUF', gameId: 'g1' },
        { id: '555', name: 'Casey Runner', team: 'MIA', gameId: 'g1' },
      ],
    };
    const { items, byPlayer } = await buildReport('nfl', SPORTS.nfl, slate);
    assert.equal(byPlayer.get('3918298').status, 'Out');
    assert.equal(byPlayer.get('555').status, 'Injured reserve');
    assert.ok(items.every((i) => i.onSlate));
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('fantasy scoring, and daily-fantasy apps only count for fantasy lines', async () => {
  const { parseEventOdds } = await import('../scripts/lib/odds.mjs');
  const game = { id: 'g5' };
  const players = [{ id: '77', name: 'Owen Stroud', role: 'off', cols: ['fantasy', 'recYds'] }];
  const props = parseEventOdds({ bookmakers: [
    { key: 'prizepicks', title: 'PrizePicks', markets: [
      { key: 'player_fantasy_points', outcomes: [{ name: 'Over', description: 'Owen Stroud', point: 14.5, price: 100 }] },
      { key: 'player_reception_yds', outcomes: [{ name: 'Over', description: 'Owen Stroud', point: 60.5, price: 100 }] },
    ] },
    { key: 'draftkings', title: 'DraftKings', markets: [
      { key: 'player_reception_yds', outcomes: [
        { name: 'Over', description: 'Owen Stroud', point: 54.5, price: -115 },
        { name: 'Under', description: 'Owen Stroud', point: 54.5, price: -105 }] },
    ] },
  ] }, game, players, SPORTS.nfl.markets);
  const fantasy = props.find((p) => p.stat === 'fantasy');
  assert.equal(fantasy.line, 14.5);
  assert.equal(fantasy.books[0].book, 'PrizePicks');
  const yards = props.find((p) => p.stat === 'recYds');
  assert.equal(yards.books.length, 1); // PrizePicks ignored for a normal market
  assert.equal(yards.line, 54.5);
});
